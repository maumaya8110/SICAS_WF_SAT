﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SICASBot.Sync
{
    public class Syncronization
    {
        public class SyncApto
        {
            private void DoLog(string entry)
            {
                entry = String.Format("{0:yyyy-MM-dd HH:mm:ss}\t{1}", DateTime.Now, entry);
                Console.WriteLine(entry);
                System.IO.StreamWriter sw = new System.IO.StreamWriter("log.txt", true);
                sw.WriteLine(entry);
                sw.Flush();
                sw.Close();
            }

            public void DoSync()
            {
                while (true)
                {
                    try
                    {

                        SyncUsuarios();
                        SyncModelosUnidades();
                        SyncConductores();
                        SyncUnidades();
                        SyncContratos();
                        SyncSesiones();
                        SyncCuentaCajas();
                        SyncCuentaConductores();
                        SyncZonas();
                        SyncServicios();
                        SyncTarifas();
                        SyncUnidades_Kilometrajes();
                        SyncUnidades_Locaciones();
                    }
                    catch (Exception ex)
                    {
                        DoLog(ex.Message);
                        DoLog(ex.StackTrace);
                        //Console.ReadLine();
                        AppHelper.SendEmail("sicas@casco.com.mx", "lespino@prosyss.com", "Error en sincronización de SICAS",
                            DateTime.Now.ToString() + "\r\n\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace, false);
                    }
                }                        
            }

            private int Estacion = 5; // LA
            private int Empresa = 3; // CAT

            private KeyValuePair<string, object> Param(string key, object value)
            {
                return new KeyValuePair<string, object>(key, value);
            }

            public void SyncConductores()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Conductores WHERE Estacion_ID = @Estacion";

                Apto.Entities.Conductores ConductoresApto;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.Conductores.Read(out ConductoresApto, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = ConductoresApto.Folio;

                    Central.Entities.Conductores centralConductores = new Central.Entities.Conductores();
                    centralConductores.Conductor_ID = 0;
                    centralConductores.Nombre = ConductoresApto.Nombre;
                    centralConductores.Apellidos = ConductoresApto.ApellidoPaterno + " " + ConductoresApto.ApellidoMaterno;
                    centralConductores.Domicilio = ConductoresApto.Calle + " No. " + ConductoresApto.NumeroCasa + ", Col. " + ConductoresApto.Colonia; ;
                    centralConductores.Ciudad = ConductoresApto.Municipio;
                    centralConductores.Entidad = ConductoresApto.Estado;
                    centralConductores.Telefono = ConductoresApto.Telefono;
                    centralConductores.Telefono2 = "";
                    centralConductores.Movil = "";
                    centralConductores.Email = ConductoresApto.CorreoElectronico;
                    centralConductores.RFC = "";
                    centralConductores.Estacion_ID = Estacion;
                    centralConductores.CURP = "";
                    centralConductores.CodigoPostal = "";
                    centralConductores.Fotografia = "";
                    centralConductores.EstatusConductor_ID = 1;
                    centralConductores.MedioPublicitario_ID = null;
                    centralConductores.CumplioPerfil = null;
                    centralConductores.Interesado = null;
                    centralConductores.Mercado_ID = 2; // Aeropuerto
                    centralConductores.Comentarios = "";
                    centralConductores.Edad = null;
                    centralConductores.EstadoCivil = null;
                    centralConductores.AñosExperiencia = null;
                    centralConductores.Genero = "M";
                    centralConductores.TipoLicencia_ID = null;
                    centralConductores.FolioLicencia = null;
                    centralConductores.VenceLicencia = null;
                    centralConductores.Rfc_Aval = null;
                    centralConductores.Apellidos_Aval = null;
                    centralConductores.Nombre_Aval = null;
                    centralConductores.Curp_Aval = null;
                    centralConductores.Domicilio_Aval = null;
                    centralConductores.Ciudad_Aval = null;
                    centralConductores.Estado_Aval = null;
                    centralConductores.CodigoPostal_Aval = null;
                    centralConductores.Telefono_Aval = null;
                    centralConductores.Email_Aval = null;
                    centralConductores.Solicitud = null;
                    centralConductores.ActaNacimiento = null;
                    centralConductores.CredencialElector = null;
                    centralConductores.CartaNoAntecedentes = null;
                    centralConductores.ComprobanteDomicilio = null;
                    centralConductores.CredencialElector_Aval = null;
                    centralConductores.ComprobanteDomicilio_Aval = null;
                    centralConductores.SaldoATratar = 0;
                    centralConductores.Cronocasco = false;
                    centralConductores.TerminalDatos = false;
                    centralConductores.BloquearConductor = false;
                    centralConductores.MensajeACaja = null;
                    centralConductores.Fecha = LA.DB.GetDate();
                    centralConductores.Usuario_ID = null;
                    centralConductores.Referencia_ID = ConductoresApto.Folio;


                    if (Central.DB.Exists("Conductores", Param("Conductor_ID", centralConductores.Conductor_ID)))
                    {
                        centralConductores.Update();
                    }
                    else
                    {
                        centralConductores.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Conductor_ID: {0}", centralConductores.Conductor_ID));
                }
            }	//	End Method SyncConductores

            public void SyncContratos()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Contratos WHERE Estacion_ID = @Estacion";

                Apto.Entities.Contratos ContratosApto;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.Contratos.Read(out ContratosApto, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = ContratosApto.Folio;

                    Central.Entities.Contratos centralContratos = new Central.Entities.Contratos();
                    centralContratos.Contrato_ID = 0;
                    centralContratos.Empresa_ID = Empresa; // CAT
                    centralContratos.Estacion_ID = Estacion;
                    centralContratos.TipoContrato_ID = 1; // Renta venta
                    centralContratos.Descripcion = ContratosApto.Folio.ToString();

                    int modeloLocal = Apto.Entities.Unidades.Read((int)ContratosApto.Unidad).Modelo;
                    int modelounidad_id =
                        Central.Entities.ModelosUnidades.Read(
                            Param("Referencia_ID", modeloLocal),
                                Param("EmpresaReferencia", Estacion)).ModeloUnidad_ID;
                    centralContratos.ModeloUnidad_ID = modelounidad_id;

                    //  Obtener plan
                    Apto.Entities.ConductoresPlanesDeRenta cpr = Apto.Entities.ConductoresPlanesDeRenta.Read((int)ContratosApto.Conductor);
                    if (cpr == null) continue;
                    decimal montodiario = Apto.Entities.PlanesDeRenta.Read(cpr.PlanDeRenta).CuotaRenta;
                    centralContratos.MontoDiario = montodiario;

                    int diasdecobro_id = (
                        Apto.Entities.PlanesDeRenta.Read(
                            Apto.Entities.ConductoresPlanesDeRenta.Read(
                                (int)ContratosApto.Conductor).PlanDeRenta).Domingo) ? 2 : 1;
                    centralContratos.DiasDeCobro_ID = diasdecobro_id; // Obtener del plan

                    centralContratos.FondoResidual = 0;

                    int conductor_id =
                        Central.Entities.Conductores.Read(
                            Param("Referencia_ID", ContratosApto.Conductor),
                                Param("Estacion_ID", Estacion)).Conductor_ID;
                    centralContratos.Conductor_ID = conductor_id;

                    int unidad_id = Central.Entities.Unidades.Read(Param("Referencia_ID", ContratosApto.Unidad),
                        Param("Estacion_ID", Estacion)).Unidad_ID;
                    centralContratos.Unidad_ID = unidad_id;

                    int numeroeconomico = Central.Entities.Unidades.Read(unidad_id).NumeroEconomico;
                    centralContratos.NumeroEconomico = numeroeconomico;

                    centralContratos.Cuenta_ID = 1; // Todos son de renta
                    centralContratos.Concepto_ID = 1; // Todos son de renta
                    centralContratos.FechaInicial = (DateTime)ContratosApto.FechaInicio;
                    centralContratos.FechaFinal = ContratosApto.FechaTerminacion;
                    centralContratos.EstatusContrato_ID = 1; // Todos estan activos
                    centralContratos.Comentarios = null;
                    centralContratos.ConductorCopia_ID = null;
                    centralContratos.CobroPermanente = (ContratosApto.FechaTerminacion == null) ? true : false;

                    if (Central.DB.Exists("Contratos", Param("Contrato_ID", centralContratos.Contrato_ID)))
                    {
                        centralContratos.Update();
                    }
                    else
                    {
                        centralContratos.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Contrato_ID: {0}", centralContratos.Contrato_ID));
                }
            }	//	End Method SyncContratos

            private int GetConcepto(int conceptolocal)
            {
                int concepto = 0;
                switch (conceptolocal)
                {
                    case 1: concepto = 92; break;
                    case 2: concepto = 93; break;
                    case 3: concepto = 94; break;
                    case 4: concepto = 95; break;
                    case 5: concepto = 96; break;
                    case 6: concepto = 97; break;
                    case 7: concepto = 98; break;
                    case 8: concepto = 99; break;
                    case 9: concepto = 100; break;
                    case 10: concepto = 101; break;
                    case 11: concepto = 102; break;
                    case 12: concepto = 103; break;
                    case 13: concepto = 104; break;
                    case 14: concepto = 105; break;
                    case 15: concepto = 106; break;
                    case 16: concepto = 107; break;
                    case 17: concepto = 108; break;
                    case 18: concepto = 109; break;
                    case 19: concepto = 110; break;
                    case 20: concepto = 111; break;
                    case 21: concepto = 112; break;
                    case 22: concepto = 113; break;
                    case 23: concepto = 114; break;
                    case 24: concepto = 115; break;
                    case 25: concepto = 116; break;
                    case 26: concepto = 117; break;
                    case 27: concepto = 118; break;
                    case 28: concepto = 119; break;
                    case 29: concepto = 120; break;
                    case 30: concepto = 121; break;
                    case 31: concepto = 122; break;
                    case 32: concepto = 123; break;
                    case 33: concepto = 124; break;
                    case 34: concepto = 125; break;
                    case 35: concepto = 126; break;
                    case 36: concepto = 127; break;
                    case 37: concepto = 128; break;
                    case 38: concepto = 129; break;
                    case 39: concepto = 130; break;
                    case 40: concepto = 131; break;
                    case 41: concepto = 132; break;
                    case 42: concepto = 133; break;
                    case 43: concepto = 134; break;
                    case 44: concepto = 135; break;
                    case 45: concepto = 136; break;
                    case 46: concepto = 137; break;
                }
                return concepto;
            }
            private int GetCuenta(int fondocaja)
            {
                int cuenta = 0;
                switch (fondocaja)
                {
                    case 1: cuenta = 9; break;
                    case 2: cuenta = 11; break;
                    case 3: cuenta = 20; break;
                    case 4: cuenta = 12; break;
                    case 5: cuenta = 10; break;
                    case 6: cuenta = 13; break;
                    case 7: cuenta = 4; break;
                    case 8: cuenta = 21; break;
                    case 9: cuenta = 22; break;
                    case 10: cuenta = 23; break;
                    case 11: cuenta = 24; break;
                    case 12: cuenta = 25; break;
                    case 13: cuenta = 26; break;
                    case 14: cuenta = 27; break;
                    case 15: cuenta = 28; break;
                    case 16: cuenta = 29; break;
                    case 17: cuenta = 30; break;
                    case 18: cuenta = 1; break;
                    case 19: cuenta = 14; break;
                    case 20: cuenta = 15; break;
                    case 21: cuenta = 16; break;
                    case 22: cuenta = 17; break;
                    case 23: cuenta = 18; break;
                    case 24: cuenta = 19; break;
                }
                return cuenta;
            }
            private int GetCuentaFromCuenta(int cta)
            {
                int cuenta = 0;
                switch (cta)
                {
                    case 1: cuenta = 9; break;
                    case 2: cuenta = 10; break;
                    case 3: cuenta = 11; break;
                    case 4: cuenta = 4; break;
                    case 5: cuenta = 12; break;
                    case 6: cuenta = 13; break;
                    case 7: cuenta = 14; break;
                    case 8: cuenta = 14; break;
                    case 10: cuenta = 1; break;
                    case 11: cuenta = 15; break;
                    case 12: cuenta = 16; break;
                    case 13: cuenta = 17; break;
                    case 14: cuenta = 18; break;
                    case 15: cuenta = 19; break;

                }
                return cuenta;
            }
            private int? ConceptoDeOperacion(int operacion)
            {
                int? concepto = null;
                switch (operacion)
                {
                    case 15: concepto = 92; break;
                    case 16: concepto = 100; break;
                    case 17: concepto = 95; break;
                    case 19: concepto = 97; break;
                    case 20: concepto = 102; break;
                    case 21: concepto = 103; break;
                    case 22: concepto = 105; break;
                    case 23: concepto = 92; break;
                    case 24: concepto = null; break;
                    case 26: concepto = 98; break;
                    case 27: concepto = 92; break;
                    case 28: concepto = null; break;
                    case 29: concepto = 92; break;
                    case 30: concepto = 92; break;
                    case 31: concepto = 92; break;
                    case 32: concepto = 92; break;
                    case 33: concepto = 92; break;
                    case 34: concepto = 92; break;
                    case 35: concepto = 92; break;
                    case 36: concepto = 124; break;
                    case 37: concepto = 123; break;
                    case 38: concepto = null; break;
                    case 39: concepto = 126; break;
                    case 41: concepto = 128; break;
                    case 42: concepto = 130; break;
                    case 43: concepto = 132; break;
                    case 44: concepto = 134; break;
                    case 45: concepto = 136; break;
                }

                return concepto;
            }

            public void SyncCuentaCajas()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM CuentaCajas WHERE Estacion_ID = @Estacion";

                Apto.Entities.MovimientosCaja CuentaCajasApto;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.MovimientosCaja.Read(out CuentaCajasApto, 1, filter, sort, Param("Folio", folio)))
                {                    
                    folio = CuentaCajasApto.Folio;
                    if (CuentaCajasApto.Caja != 1) { continue; }                    

                    Central.Entities.CuentaCajas centralCuentaCajas = new Central.Entities.CuentaCajas();
                    centralCuentaCajas.CuentaCaja_ID = 0;

                    int sesionLocal =
                        Apto.Entities.ControlCajas.Read("@Fecha BETWEEN FechaInicioCaja AND FechaCorteCaja",
                            Param("@Fecha", CuentaCajasApto.Fecha)).Folio;
                    
                    int? sesion_id =
                        Central.Entities.Sesiones.Read(
                            Param("Referencia_ID", sesionLocal),
                                Param("Estacion_ID", Estacion)).Sesion_ID;

                    centralCuentaCajas.Sesion_ID = sesion_id; // Revisar sea nullable
                    centralCuentaCajas.Empresa_ID = Empresa;
                    centralCuentaCajas.Estacion_ID = Estacion;
                    centralCuentaCajas.Caja_ID = 3; // CAJA APTO LA
                    centralCuentaCajas.Ticket_ID = null; // No esta supeditada a un ticket
                    centralCuentaCajas.Referencia_ID = folio;

                    //  La cuenta a partir del fondo
                    //  El concepto a partir de la operación de caja
                    centralCuentaCajas.Cuenta_ID = this.GetCuenta(CuentaCajasApto.FondoCaja); // Obtener de fondo caja

                    centralCuentaCajas.Concepto_ID = ConceptoDeOperacion(CuentaCajasApto.Operacion); // Obtener de fondo caja y operación

                    decimal cargo, abono;
                    if (CuentaCajasApto.Monto < 0)
                    {
                        cargo = Math.Abs(CuentaCajasApto.Monto);
                        abono = 0;
                    }
                    else
                    {
                        abono = Math.Abs(CuentaCajasApto.Monto);
                        cargo = 0;
                    }

                    centralCuentaCajas.Cargo = cargo;
                    centralCuentaCajas.Abono = abono;
                    centralCuentaCajas.Saldo = 0; // Es calculado, incluido en el calculo

                    centralCuentaCajas.Comentarios = CuentaCajasApto.Motivo;
                    centralCuentaCajas.Fecha = CuentaCajasApto.Fecha;
                    centralCuentaCajas.Usuario_ID = CuentaCajasApto.Usuario;


                    if (Central.DB.Exists("CuentaCajas", Param("CuentaCaja_ID", centralCuentaCajas.CuentaCaja_ID)))
                    {
                        centralCuentaCajas.Update();
                    }
                    else
                    {
                        centralCuentaCajas.Create();
                    }

                    //Console.WriteLine(String.Format("Registro actualizado CuentaCaja_ID: {0}", centralCuentaCajas.CuentaCaja_ID));
                    Console.Write(String.Format("RAC {0} ", folio));
                }
            }	//	End Method SyncCuentaCajas

            public void SyncCuentaConductores()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM CuentaConductores WHERE Estacion_ID = @Estacion";

                Apto.Entities.CuentaConductor CuentaConductoresApto;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.CuentaConductor.Read(out CuentaConductoresApto, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = CuentaConductoresApto.Folio;

                    Central.Entities.CuentaConductores centralCuentaConductores = new Central.Entities.CuentaConductores();
                    centralCuentaConductores.CuentaConductor_ID = 0;
                    centralCuentaConductores.Empresa_ID = Empresa; // CAT
                    centralCuentaConductores.Estacion_ID = Estacion; // CAT

                    int conductor_id =
                        Central.Entities.Conductores.Read(
                            Param("Referencia_ID", CuentaConductoresApto.Conductor),
                                Param("Estacion_ID", Estacion)).Conductor_ID;
                    centralCuentaConductores.Conductor_ID = conductor_id;

                    Central.Entities.Unidades uni = Central.Entities.Unidades.Read(Param("Referencia_ID", CuentaConductoresApto.Unidad),
                        Param("Estacion_ID", Estacion));
                    
                    if(uni != null)
                    {
                        int unidad_id = uni.Unidad_ID;
                        centralCuentaConductores.Unidad_ID = unidad_id;
                    }
                    else
                    {
                        centralCuentaConductores.Unidad_ID = null;
                    }                    

                    centralCuentaConductores.Caja_ID = (int?)AppHelper.Iif((CuentaConductoresApto.Caja == 1), 1, null);
                    centralCuentaConductores.Ticket_ID = null;

                    //  Obtener cuenta del concepto
                    int cuenta = Apto.Entities.Conceptos.Read(CuentaConductoresApto.Concepto).Cuenta;
                    int cuenta_id = GetCuentaFromCuenta(cuenta);
                    centralCuentaConductores.Cuenta_ID = cuenta_id;

                    //  Efectuar la traducción directa del concepto
                    int concepto_id = GetConcepto(CuentaConductoresApto.Concepto);
                    centralCuentaConductores.Concepto_ID = concepto_id;

                    //  Si es menor a 0 es Cargo, contrario es abono
                    decimal cargo, abono;
                    if (CuentaConductoresApto.Monto < 0)
                    {
                        cargo = Math.Abs(CuentaConductoresApto.Monto);
                        abono = 0;
                    }
                    else
                    {
                        abono = Math.Abs(CuentaConductoresApto.Monto);
                        cargo = 0;
                    }

                    centralCuentaConductores.Cargo = cargo;
                    centralCuentaConductores.Abono = abono;
                    centralCuentaConductores.Saldo = 0; // Es calculado

                    centralCuentaConductores.Comentarios = CuentaConductoresApto.Comentario;
                    centralCuentaConductores.Fecha = CuentaConductoresApto.Fecha;
                    centralCuentaConductores.Usuario_ID = CuentaConductoresApto.Usuario;
                    centralCuentaConductores.Referencia_ID = folio;


                    if (Central.DB.Exists("CuentaConductores", Param("CuentaConductor_ID", centralCuentaConductores.CuentaConductor_ID)))
                    {
                        centralCuentaConductores.Update();
                    }
                    else
                    {
                        centralCuentaConductores.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado CuentaConductor_ID: {0}", centralCuentaConductores.CuentaConductor_ID));
                }

            }	//	End Method SyncCuentaConductores

            public void SyncEstatusServicios()
            {
                List<Apto.Entities.StatusBoletos> estatusserviciosApto = Apto.Entities.StatusBoletos.Read();
                foreach (Apto.Entities.StatusBoletos EstatusServiciosApto in estatusserviciosApto)
                {
                    Central.Entities.EstatusServicios centralEstatusServicios = new Central.Entities.EstatusServicios();
                    centralEstatusServicios.EstatusServicio_ID = EstatusServiciosApto.Folio;
                    centralEstatusServicios.Nombre = EstatusServiciosApto.Descripcion;


                    if (Central.DB.Exists("EstatusServicios", Param("EstatusServicio_ID", centralEstatusServicios.EstatusServicio_ID)))
                    {
                        centralEstatusServicios.Update();
                    }
                    else
                    {
                        centralEstatusServicios.Create();
                    }
                }	//	End foreach

            }	//	End Method SyncEstatusServicios
            
            public void SyncModelosUnidades()
            {
                List<Apto.Entities.ModelosUnidades> modelosunidadesApto = Apto.Entities.ModelosUnidades.Read();
                foreach (Apto.Entities.ModelosUnidades ModelosUnidadesApto in modelosunidadesApto)
                {
                    Central.Entities.ModelosUnidades centralModelosUnidades = new Central.Entities.ModelosUnidades();
                    centralModelosUnidades.ModeloUnidad_ID = 0;
                    centralModelosUnidades.MarcaUnidad_ID = ModelosUnidadesApto.Marca; // Traducir la marca
                    centralModelosUnidades.Descripcion = ModelosUnidadesApto.Descripcion;
                    centralModelosUnidades.PrecioLista = ModelosUnidadesApto.PrecioLista;
                    centralModelosUnidades.Anio = ModelosUnidadesApto.Anyo;
                    centralModelosUnidades.Deposito = 0;
                    centralModelosUnidades.Activo = true;
                    centralModelosUnidades.referencia_id = ModelosUnidadesApto.Folio;
                    centralModelosUnidades.EmpresaReferencia = Estacion;


                    if (Central.DB.Exists("ModelosUnidades", Param("ModeloUnidad_ID", centralModelosUnidades.ModeloUnidad_ID)))
                    {
                        centralModelosUnidades.Update();
                    }
                    else
                    {
                        centralModelosUnidades.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado ModeloUnidad_ID: {0}", centralModelosUnidades.ModeloUnidad_ID));
                }	//	End foreach

            }	//	End Method SyncModelosUnidades

            private int EstatusUnidad(int status)
            {
                int estatusunidad = 2;
                switch (status)
                {
                    case 1: estatusunidad = 2; break;
                    case 2: estatusunidad = 5; break;
                    case 3: estatusunidad = 10; break;
                }

                return estatusunidad;
            }
                
            public void SyncUnidades()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Unidades WHERE Estacion_ID = @Estacion";

                Apto.Entities.Unidades UnidadesApto;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.Unidades.Read(out UnidadesApto, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = UnidadesApto.Folio;

                    Central.Entities.Unidades centralUnidades = new Central.Entities.Unidades();
                    centralUnidades.Unidad_ID = 0;
                    centralUnidades.Empresa_ID = Empresa; // CAT
                    centralUnidades.Estacion_ID = Estacion; // CAT
                    centralUnidades.NumeroEconomico = UnidadesApto.NumeroEconomico;

                    //  Obtener el equivalente en modelo
                    centralUnidades.ModeloUnidad_ID =
                        Central.Entities.ModelosUnidades.Read(
                            Param("Referencia_ID", UnidadesApto.Modelo), Param("EmpresaReferencia", Estacion)).ModeloUnidad_ID;

                    centralUnidades.PrecioLista = Apto.Entities.ModelosUnidades.Read(UnidadesApto.Modelo).PrecioLista;
                    centralUnidades.NumeroSerie = UnidadesApto.NumeroSerie;
                    centralUnidades.NumeroSerieMotor = UnidadesApto.NumeroSerieMotor;
                    centralUnidades.TarjetaCirculacion = UnidadesApto.TarjetaCirculacion;

                    //   Efectuar la conversión
                    centralUnidades.EstatusUnidad_ID = EstatusUnidad((int)UnidadesApto.Status);

                    //int locacion = Apto.Entities.RegistroLocacionesUnidades.Read()[0].Locacion;
                    //int locacion_id = Central.Entities.LocacionesUnidades.Read()[0].LocacionUnidad_ID;
                    centralUnidades.LocacionUnidad_ID = 1;

                    centralUnidades.Placas = UnidadesApto.Placas;

                    //int kilometraje = Apto.Entities.KilometrajesUnidades.Read(Param("Unidad", UnidadesApto.Folio)).Kilometraje;
                    centralUnidades.Kilometraje = 0;

                    centralUnidades.Propietario_ID = Empresa; // Todas son de cat
                    centralUnidades.Arrendamiento_ID = null;
                    centralUnidades.Concesion_ID = null;
                    centralUnidades.Referencia_ID = UnidadesApto.Folio;


                    if (Central.DB.Exists("Unidades", Param("Unidad_ID", centralUnidades.Unidad_ID)))
                    {
                        centralUnidades.Update();
                    }
                    else
                    {
                        centralUnidades.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_ID: {0}", centralUnidades.Unidad_ID));
                }

            }	//	End Method SyncUnidades

            public void SyncUnidades_Kilometrajes()
            {
                string filter = "Fecha > @Fecha";

                string sort = "Fecha ASC";

                string sqlQry = "SELECT ISNULL(MAX(Fecha),0) fecha FROM Unidades_Kilometrajes " +
                    "WHERE Unidad_ID IN ( SELECT Unidad_ID FROM Unidades WHERE Estacion_ID = @Estacion )";

                Apto.Entities.KilometrajesUnidades Unidades_KilometrajesApto;
                DateTime fecha;

                fecha = Convert.ToDateTime(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.KilometrajesUnidades.Read(out Unidades_KilometrajesApto, 1, filter, sort, Param("Fecha", fecha)))
                {
                    fecha = Unidades_KilometrajesApto.Fecha;

                    Central.Entities.Unidades_Kilometrajes centralUnidades_Kilometrajes = new Central.Entities.Unidades_Kilometrajes();
                    centralUnidades_Kilometrajes.Unidad_Kilometraje_ID = 0;                    

                    Central.Entities.Unidades unidad = Central.Entities.Unidades.Read(Param("Referencia_ID", Unidades_KilometrajesApto.Unidad),
                        Param("Estacion_ID", Estacion));

                    if (unidad == null) { continue; }

                    int unidad_id = unidad.Unidad_ID;

                    centralUnidades_Kilometrajes.Unidad_ID = unidad_id; // Obtener de unidades

                    centralUnidades_Kilometrajes.Conductor_ID = null; //    Debe poder ser null // Obtener de unidades conductores
                    centralUnidades_Kilometrajes.Kilometraje = Unidades_KilometrajesApto.Kilometraje;
                    centralUnidades_Kilometrajes.Fecha = Unidades_KilometrajesApto.Fecha;


                    if (Central.DB.Exists("Unidades_Kilometrajes", Param("Unidad_Kilometraje_ID", centralUnidades_Kilometrajes.Unidad_Kilometraje_ID)))
                    {
                        centralUnidades_Kilometrajes.Update();
                    }
                    else
                    {
                        centralUnidades_Kilometrajes.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_Kilometraje_ID: {0}", centralUnidades_Kilometrajes.Unidad_Kilometraje_ID));
                }                
            }	//	End Method SyncUnidades_Kilometrajes

            public void SyncUnidades_Locaciones()
            {
                string filter = "Fecha > @Fecha";

                string sort = "Fecha ASC";

                string sqlQry = "SELECT ISNULL(MAX(Fecha),0) fecha FROM Unidades_Locaciones " +
                    "WHERE Unidad_ID IN ( SELECT Unidad_ID FROM Unidades WHERE Estacion_ID = @Estacion )";

                Apto.Entities.UnidadesLocaciones Unidades_LocacionesApto;
                DateTime fecha;

                fecha = Convert.ToDateTime(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.UnidadesLocaciones.Read(out Unidades_LocacionesApto, 1, filter, sort, Param("Fecha", fecha)))
                {
                    fecha = (DateTime)Unidades_LocacionesApto.Fecha;

                    Central.Entities.Unidades_Locaciones centralUnidades_Locaciones = new Central.Entities.Unidades_Locaciones();
                    centralUnidades_Locaciones.Unidad_Locacion_ID = 0;
                    centralUnidades_Locaciones.Unidad_ID = Unidades_LocacionesApto.Unidad; // Obtener de unidad
                    centralUnidades_Locaciones.LocacionUnidad_ID = Unidades_LocacionesApto.Locacion; // Obtener de locacion
                    centralUnidades_Locaciones.Fecha = (DateTime)Unidades_LocacionesApto.Fecha;

                    if (Central.DB.Exists("Unidades_Locaciones", Param("Unidad_Locacion_ID", centralUnidades_Locaciones.Unidad_Locacion_ID)))
                    {
                        centralUnidades_Locaciones.Update();
                    }
                    else
                    {
                        centralUnidades_Locaciones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Fecha: {0}", centralUnidades_Locaciones.Fecha));
                }
            }	//	End Method SyncUnidades_Locaciones

            public void SyncUsuarios()
            {
                List<Apto.Entities.Usuarios> usuariosApto = Apto.Entities.Usuarios.Read();
                foreach (Apto.Entities.Usuarios UsuariosApto in usuariosApto)
                {
                    Central.Entities.Usuarios centralUsuarios = new Central.Entities.Usuarios();
                    centralUsuarios.Usuario_ID = UsuariosApto.Clave;
                    centralUsuarios.Nombre = UsuariosApto.Nombre;
                    centralUsuarios.Apellidos = UsuariosApto.ApellidoPaterno +  " " + UsuariosApto.ApellidoMaterno;
                    centralUsuarios.Email = "";
                    centralUsuarios.Activo = UsuariosApto.Status == 1 ? true : false;
                    centralUsuarios.pwd = Apto.DB.PwdEncrypt(UsuariosApto.Pwd);
                    centralUsuarios.Empresa_ID = Empresa;
                    centralUsuarios.Estacion_ID = Estacion;

                    if (Central.DB.Exists("Usuarios", Param("Usuario_ID", centralUsuarios.Usuario_ID)))
                    {
                        centralUsuarios.Update();
                    }
                    else
                    {
                        centralUsuarios.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Usuario_ID: {0}", centralUsuarios.Usuario_ID));
                }	//	End foreach

            }	//	End Method SyncUsuarios

            public void SyncTarifas()
            {
                List<Apto.Entities.Tarifas> tarifasApto = Apto.Entities.Tarifas.Read();
                foreach (Apto.Entities.Tarifas TarifasApto in tarifasApto)
                {
                    Central.Entities.Tarifas centralTarifas = new Central.Entities.Tarifas();
                    centralTarifas.Zona_ID = TarifasApto.Zona;
                    centralTarifas.TipoServicio_ID = TarifasApto.TipoServicio; // verificar referencia
                    centralTarifas.Tarifa = TarifasApto.Tarifa;

                    if (Central.DB.Exists("Tarifas", Param("Zona_ID", centralTarifas.Zona_ID)))
                    {
                        centralTarifas.Update();
                    }
                    else
                    {
                        centralTarifas.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Zona_ID: {0}", centralTarifas.Zona_ID));
                }	//	End foreach

            }	//	End Method SyncTarifas

            private int GetMoneda(int tipopago)
            {
                int moneda = 1;
                switch (tipopago)
                {
                    case 0: moneda = 1; break;
                    case 1: moneda = 7; break;
                    case 2: moneda = 8; break;
                    case 3: moneda = 9; break;
                    case 4: moneda = 10; break;
                    case 5: moneda = 11; break;
                    case 6: moneda = 12; break;
                    case 7: moneda = 13; break;
                    case 8: moneda = 14; break;
                    case 9: moneda = 15; break;
                    case 10: moneda = 16; break;
                    case 11: moneda = 17; break;
                    case 12: moneda = 18; break;
                    case 13: moneda = 4; break;
                    case 14: moneda = 20; break;
                    case 15: moneda = 21; break;
                    case 16: moneda = 3; break;
                }
                return moneda;
            }

            private int GetCaja(int caja)
            {
                int result = 0;
                switch (caja)
                {
                    case 1: result = 3; break;
                    case 3: result = 10; break;
                    case 4: result = 4; break;
                }
                return result;
            }

            public void SyncServicios()
            {
                string filter = "Codigo > @Codigo";

                string sort = "Codigo ASC";

                string sqlQry = "SELECT ISNULL(MAX(Servicio_ID),'') Codigo FROM Servicios";

                Apto.Entities.BoletosAeropuerto ServiciosApto;
                string codigo;

                codigo = Convert.ToString(Central.DB.QueryScalar(sqlQry));

                while (Apto.Entities.BoletosAeropuerto.Read(out ServiciosApto, 1, filter, sort, Param("@Codigo", codigo)))
                {
                    codigo = ServiciosApto.Codigo;

                    Central.Entities.Servicios centralServicios = new Central.Entities.Servicios();
                    centralServicios.Servicio_ID = ServiciosApto.Codigo;
                    centralServicios.Mercado_ID = 2; // Aeropuerto
                    centralServicios.Empresa_ID = Empresa; // CAT
                    centralServicios.Estacion_ID = Estacion; // Apto Mty
                    centralServicios.Caja_ID = (ServiciosApto.Caja == null) ? null : new Nullable<int>(GetCaja(ServiciosApto.Caja.Value)); // Verificar
                    centralServicios.Sesion_ID = null;
                    centralServicios.Zona_ID = ServiciosApto.Zona;
                    centralServicios.ClaseServicio_ID = ServiciosApto.ClaseServicio;
                    centralServicios.TipoServicio_ID = ServiciosApto.TipoServicio;
                    centralServicios.TipoServicioConductor_ID = null;
                    centralServicios.Moneda_ID = GetMoneda(ServiciosApto.TipoPago);
                    centralServicios.EstatusServicio_ID = ServiciosApto.Status;
                    centralServicios.Unidad_ID = (ServiciosApto.Carrera==null) ? null : new Nullable<int>(ServiciosApto.Carrera.Unidad);
                    centralServicios.Conductor_ID = (ServiciosApto.Carrera == null) ? null : new Nullable<int>(ServiciosApto.Carrera.Conductor);
                    centralServicios.Usuario_ID = (string.IsNullOrEmpty(ServiciosApto.Usuario)) ? "SICAS" : ServiciosApto.Usuario;
                    centralServicios.Cliente_ID = null;
                    centralServicios.Ticket_ID = null; // Verificar
                    centralServicios.TipoVenta_ID = null; // De acuerdo a codigo
                    centralServicios.Cuenta_ID = 1; // De acuerdo solo para tipo boletos especiales, caso contrario, siempre a la misma cuenta
                    centralServicios.FolioDiario = ServiciosApto.FolioDiario;
                    centralServicios.Precio = ServiciosApto.Precio;
                    centralServicios.Fecha = ServiciosApto.Fecha;
                    centralServicios.FechaServicio = (ServiciosApto.Carrera == null) ? null : (DateTime?)(ServiciosApto.Carrera.FechaCarreraLocal);
                    centralServicios.FechaExpiracion = null; 
                    centralServicios.FechaPago = (ServiciosApto.Pago == null) ? null : (DateTime?)ServiciosApto.Pago.Fecha;
                    centralServicios.Productividad = (ServiciosApto.Pago == null) ? null : (decimal?)ServiciosApto.Pago.CarrerasValidas;
                    centralServicios.PagoConductor = (ServiciosApto.Pago == null) ? null : (decimal?)ServiciosApto.Pago.PagoCasco;
                    centralServicios.PagoComisiones = (ServiciosApto.Pago == null) ? null : (decimal?)ServiciosApto.Pago.TotalCasco;

                    if (Central.DB.Exists("Servicios", Param("Servicio_ID", centralServicios.Servicio_ID)))
                    {
                        centralServicios.Update();
                    }
                    else
                    {
                        centralServicios.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Servicio_ID: {0}", centralServicios.Servicio_ID));
                }

            }	//	End Method SyncServicios

            public void SyncServicios_Comisiones()
            {
                //List<Apto.Entities.Servicios_Comisiones> servicios_comisionesApto = Apto.Entities.Servicios_Comisiones.Read();
                //foreach (Apto.Entities.Servicios_Comisiones Servicios_ComisionesApto in servicios_comisionesApto)
                //{
                //    Central.Entities.Servicios_Comisiones centralServicios_Comisiones = new Central.Entities.Servicios_Comisiones();
                //    centralServicios_Comisiones.Servicio_ID = Servicios_ComisionesApto.Servicio_ID;
                //    centralServicios_Comisiones.ComisionServicio_ID = Servicios_ComisionesApto.ComisionServicio_ID;
                //    centralServicios_Comisiones.Ticket_ID = Servicios_ComisionesApto.Ticket_ID;
                //    centralServicios_Comisiones.Monto = Servicios_ComisionesApto.Monto;

                //    if (Central.DB.Exists("Servicios_Comisiones", Param("Servicio_ID", centralServicios_Comisiones.Servicio_ID)))
                //    {
                //        centralServicios_Comisiones.Update();
                //    }
                //    else
                //    {
                //        centralServicios_Comisiones.Create();
                //    }
                //}	//	End foreach

            }	//	End Method SyncServicios_Comisiones            

            public void SyncSesiones()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Sesiones WHERE Estacion_ID = @Estacion";

                Apto.Entities.ControlCajas SesionesApto;
                int sesion;

                sesion = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (Apto.Entities.ControlCajas.Read(out SesionesApto, 1, filter, sort, Param("Folio", sesion)))
                {
                    sesion = SesionesApto.Folio;

                    Central.Entities.Sesiones centralSesiones = new Central.Entities.Sesiones();
                    centralSesiones.Sesion_ID = 0;
                    centralSesiones.Empresa_ID = Empresa;
                    centralSesiones.Estacion_ID = Estacion;
                    centralSesiones.Caja_ID = Central.Entities.Cajas.Read(Param("Estacion_ID", Estacion), Param("Referencia_ID", SesionesApto.Caja)).Caja_ID; 
                    centralSesiones.Usuario_ID = SesionesApto.Usuario;
                    centralSesiones.FechaInicial = SesionesApto.FechaInicioCaja;
                    centralSesiones.FechaFinal = SesionesApto.FechaCorteCaja;
                    centralSesiones.HostName = null;
                    centralSesiones.IPAddress = null;
                    centralSesiones.MACAddress = null;
                    centralSesiones.Activo = (SesionesApto.FechaCorteCaja == null) ? true : false;
                    centralSesiones.Referencia_ID = SesionesApto.Folio;

                    if (Central.DB.Exists("Sesiones", Param("Sesion_ID", centralSesiones.Sesion_ID)))
                    {
                        centralSesiones.Update();
                    }
                    else
                    {
                        centralSesiones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Sesion_ID: {0}", centralSesiones.Sesion_ID));
                }

            }	//	End Method SyncSesiones

            public void SyncZonas()
            {
                List<Apto.Entities.Zonas> zonasApto = Apto.Entities.Zonas.Read();
                foreach (Apto.Entities.Zonas ZonasApto in zonasApto)
                {
                    Central.Entities.Zonas centralZonas = new Central.Entities.Zonas();
                    centralZonas.Zona_ID = ZonasApto.Folio;
                    centralZonas.TipoZona_ID = ZonasApto.Tipo;  //  Verificar conversión
                    centralZonas.ComisionServicio_ID = ZonasApto.Comisionista;  // Hacer tabla de conversión
                    centralZonas.Nombre = ZonasApto.Descripcion;


                    if (Central.DB.Exists("Zonas", Param("Zona_ID", centralZonas.Zona_ID)))
                    {
                        centralZonas.Update();
                    }
                    else
                    {
                        centralZonas.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Zona_ID: {0}", centralZonas.Zona_ID));
                }	//	End foreach

            }	//	End Method SyncZonas
        }

        public class SyncLA
        {
            private void DoLog(string entry)
            {
                entry  =String.Format("{0:yyyy-MM-dd HH:mm:ss}\t{1}", DateTime.Now, entry);
                Console.WriteLine(entry);
                System.IO.StreamWriter sw = new System.IO.StreamWriter("log.txt", true);
                sw.WriteLine(entry);
                sw.Flush();
                sw.Close();
            }

            public void DoSyncMetro()
            {
                try
                {
                    //DateTime fechaInicial = DateTime.Now;

                    
                    //SyncUsuarios();
                    //SyncSesiones();
                    //SyncModelosUnidades();
                    //SyncConcesiones();
                    //SyncUnidades();
                    //SyncConductores();
                    ////SyncUnidadesInit();
                    //SyncContratos();
                    //SyncCuentaCajas();
                    //SyncTickets();
                    //SyncCuentaConductores();
                    //SyncTicketsCancelados();
                    SyncPlanillasFiscales();
                    SyncUnidades_Kilometrajes();
                    SyncUnidades_Locaciones();
                    SyncValesPrepagados();
                 

                //    DateTime fechaFinal = DateTime.Now;
                //    TimeSpan t = fechaFinal.Subtract(fechaInicial);
                //    DoLog(String.Format("Tiempo total: {0} dias, {1} horas, {2} minutos y {3} segundos.",
                //        t.Days, t.Hours, t.Minutes, t.Seconds));

                //    Console.Read();
                }
                catch (Exception ex)
                {
                    DoLog(ex.Message);
                    DoLog(ex.StackTrace);
                    AppHelper.SendEmail("sicas@casco.com.mx", "lespino@prosyss.com", "Error en sincronización de SICAS",
                        DateTime.Now.ToString() + "\r\n\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace, false);                    
                    //Console.ReadLine();                    
                }                                              
            }

            public void DoSyncTaller()
            {
                try
                {
                    //DateTime fechaInicial = DateTime.Now;
                    while (true)
                    {
                        //  Usuarios
                        SyncUsuarios();

                        //  Familias
                        SyncFamilias();

                        //  Tipos de refacciones
                        SyncTiposRefacciones();

                        //  Marcas de refacciones
                        SyncMarcasRefacciones();

                        //  Modelos
                        SyncModelos();

                        //  Refacciones
                        SyncRefacciones();

                        //  Servicios
                        SyncServiciosMantenimientos();

                        //  Servicios tipos de refacciones
                        SyncServiciosMantenimientos_TiposRefacciones();

                        //  Categorias de Mecánicos                
                        SyncCategoriasMecanicos();

                        //Estatus de Mecánicos
                        SyncEstatusMecanicos();

                        //  Mecanicos
                        SyncMecanicos();

                        // Estatus Ordenes Trabajo
                        SyncEstatusOrdenesTrabajos();

                        //  Tipos Mantenimientos
                        SyncTiposMantenimientos();

                        //  Ordenes de trabajo
                        SyncOrdenesTrabajos();

                        // Estatus ordenes compras
                        SyncEstatusOrdenesCompras();

                        // Estatus ordenes servicios
                        SyncEstatusOrdenesServicios();

                        //  Ordenes de servicio
                        SyncOrdenesServicios();

                        //  refacciones int
                        //SyncRefacciones(0);

                        //  Ordenes de servicio refacciones
                        SyncOrdenesServiciosRefacciones();

                        //  Cancelaciones de ordenes de trabajo
                        SyncCancelacionesOrdenesTrabajos();

                        //  Proveedores
                        //  donde proveedor sea 0, obtener el de mayor porcentaje y pasarlo al mismo
                        //  Ordenes de compras
                        SyncOrdenesCompras();

                        //  Compras
                        SyncCompras();

                        //  Cancelaciones de compras
                        SyncOrdenesComprasCanceladas();

                        //  Notas de almacen
                        SyncNotasAlmacen();

                        //  Ajustes de inventario
                        SyncAjustesInventario();

                        //  Movimientos de inventario
                        SyncMovimientosInventario();
                    }

                    //DateTime fechaFinal = DateTime.Now;
                    //TimeSpan t = fechaFinal.Subtract(fechaInicial);
                    //DoLog(String.Format("Tiempo total: {0} dias, {1} horas, {2} minutos y {3} segundos.", 
                    //    t.Days, t.Hours, t.Minutes, t.Seconds));

                    //Console.Read();

                }
                catch (Exception ex)
                {
                    DoLog(ex.Message);
                    DoLog(ex.StackTrace);
                    //Console.ReadLine();
                    AppHelper.SendEmail("sicas@casco.com.mx", "lespino@prosyss.com", "Error en sincronización de SICAS",
                        DateTime.Now.ToString() + "\r\n\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace, false);
                }      
            }

            private int Estacion = 1; // LA
            private int Empresa = 2; // CAM

            private KeyValuePair<string, object> Param(string key, object value)
            {
                return new KeyValuePair<string, object>(key, value);
            } 
           
            //  Estatus de ordenes de compras
            public void SyncEstatusOrdenesCompras()
            {
                List<LA.Entities.StatusOrdenesCompra> estatusordenescomprasLA = LA.Entities.StatusOrdenesCompra.Read();
                foreach (LA.Entities.StatusOrdenesCompra EstatusOrdenesComprasLA in estatusordenescomprasLA)
                {
                    Central.Entities.EstatusOrdenesCompras centralEstatusOrdenesCompras = new Central.Entities.EstatusOrdenesCompras();
                    centralEstatusOrdenesCompras.EstatusOrdenCompra_ID = EstatusOrdenesComprasLA.Folio;
                    centralEstatusOrdenesCompras.Nombre = EstatusOrdenesComprasLA.Descripcion;


                    if (Central.DB.Exists("EstatusOrdenesCompras", Param("EstatusOrdenCompra_ID", centralEstatusOrdenesCompras.EstatusOrdenCompra_ID)))
                    {
                        centralEstatusOrdenesCompras.Update();
                    }
                    else
                    {
                        centralEstatusOrdenesCompras.Create(true);
                    }
                }	//	End foreach

            }	//	End Method SyncEstatusOrdenesCompras

            public void SyncEstatusOrdenesServicios()
            {
                List<LA.Entities.StatusOrdenesServicio> estatusordenesserviciosLA = LA.Entities.StatusOrdenesServicio.Read();
                foreach (LA.Entities.StatusOrdenesServicio EstatusOrdenesServiciosLA in estatusordenesserviciosLA)
                {
                    Central.Entities.EstatusOrdenesServicios centralEstatusOrdenesServicios = new Central.Entities.EstatusOrdenesServicios();
                    centralEstatusOrdenesServicios.EstatusOrdenServicio_ID = EstatusOrdenesServiciosLA.Folio;
                    centralEstatusOrdenesServicios.Nombre = EstatusOrdenesServiciosLA.Descripcion;


                    if (Central.DB.Exists("EstatusOrdenesServicios", Param("EstatusOrdenServicio_ID", centralEstatusOrdenesServicios.EstatusOrdenServicio_ID)))
                    {
                        centralEstatusOrdenesServicios.Update();
                    }
                    else
                    {
                        centralEstatusOrdenesServicios.Create(true);
                    }
                }	//	End foreach

            }	//	End Method SyncEstatusOrdenesServicios

            //  AjustesInventario
            public void SyncAjustesInventario()
            {
                /*
                 * Tiene folio, pasar a read
                 */
                List<LA.Entities.MovimientosDirectosAInventario> movsInventario = new List<LA.Entities.MovimientosDirectosAInventario>();
                movsInventario = LA.Entities.MovimientosDirectosAInventario.Read();

                foreach (LA.Entities.MovimientosDirectosAInventario mov in movsInventario)
                {
                    Central.Entities.AjustesInventario ajuste = new Central.Entities.AjustesInventario();
                    ajuste.Cantidad = Convert.ToInt32(mov.Cantidad);
                    ajuste.Comentarios = mov.Comentarios;
                    ajuste.CostoUnitario = (decimal)mov.CostoUnitario;
                    ajuste.Fecha = (DateTime)mov.Fecha;
                    ajuste.Refaccion_ID = (int)mov.Refaccion;
                    ajuste.TipoMovimientoInventario_ID = (mov.TipoMovimiento == 'E') ? 1 : 2;
                    ajuste.Total = (decimal)mov.Total;
                    ajuste.Usuario_ID = mov.Usuario;
                    ajuste.AjusteInventario_ID = mov.Folio;

                    if (Central.DB.Exists("AjustesInventario", Param("AjusteInventario_ID", ajuste.AjusteInventario_ID)))
                    {
                        ajuste.Update();
                    }
                    else
                    {
                        ajuste.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado AjusteInventario_ID: {0}", ajuste.AjusteInventario_ID));
                }
            }
            
            //  CancelacionesOrdenesTrabajos
            public void SyncCancelacionesOrdenesTrabajos()
            {
                /*
                 * Tiene folio, pasar a read
                 */
                List<LA.Entities.OrdenesTrabajoCanceladas> ordenesCanceladas = LA.Entities.OrdenesTrabajoCanceladas.Read();

                foreach (LA.Entities.OrdenesTrabajoCanceladas ordenCancelada in ordenesCanceladas)
                {
                    Central.Entities.CancelacionesOrdenesTrabajos cancelacion = new Central.Entities.CancelacionesOrdenesTrabajos();
                    cancelacion.Comentarios = ordenCancelada.Motivos;
                    cancelacion.Fecha = ordenCancelada.Fecha;
                    cancelacion.OrdenTrabajo_ID = ordenCancelada.OrdenTrabajo;
                    cancelacion.Usuario_ID = ordenCancelada.Usuario;

                    if (Central.DB.Exists("CancelacionesOrdenesTrabajos", Param("OrdenTrabajo_ID", cancelacion.OrdenTrabajo_ID)))
                    {
                        cancelacion.Update();
                    }
                    else
                    {
                        cancelacion.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenTrabajo_ID Cancelacion: {0}", cancelacion.OrdenTrabajo_ID));
                }                
            }

            //  CategoriasMecanicos
            public void SyncCategoriasMecanicos()
            {
                List<LA.Entities.CategoriasMecanicos> categoriasLA = LA.Entities.CategoriasMecanicos.Read();

                foreach (LA.Entities.CategoriasMecanicos LAcategoria in categoriasLA)
                {
                    Central.Entities.CategoriasMecanicos centralCategoria = new Central.Entities.CategoriasMecanicos();
                    centralCategoria.CategoriaMecanico_ID = LAcategoria.Folio;
                    centralCategoria.Familia_ID = LAcategoria.Familia;
                    centralCategoria.Nombre = LAcategoria.Descripcion;

                    if (Central.DB.Exists("CategoriasMecanicos", Param("CategoriaMecanico_ID", centralCategoria.CategoriaMecanico_ID)))
                    {
                        centralCategoria.Update();
                    }
                    else
                    {
                        centralCategoria.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado CategoriaMecanico_ID: {0}", centralCategoria.CategoriaMecanico_ID));
                }
            }

            //  Compras
            public void SyncCompras()
            {
                //  Obtener el listado de ordenes de compras faltantes
                //  Donde hay ordenes de compra que no hay en compras
                //  Para cada una de ellas
                string strSQL = "SELECT	DISTINCT OrdenCompra_ID \r\n " +
                    "FROM	OrdenesCompras \r\n " +
                    "WHERE	OrdenCompra_ID \r\n " +
                    "NOT IN	(SELECT DISTINCT OrdenCompra_ID FROM Compras) \r\n " +
                    "AND		OrdenCompra_ID NOT IN (SELECT OrdenCompra_ID FROM OrdenesComprasCanceladas)";

                System.Data.DataTable dt = Central.DB.Query(strSQL);
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    int ordencompra = Convert.ToInt32(dr["OrdenCompra_ID"]);
                    List<LA.Entities.Compras> comprasLA = LA.Entities.Compras.Read(Param("OrdenCompra", ordencompra));

                    foreach (LA.Entities.Compras LAcompra in comprasLA)
                    {
                        Central.Entities.Compras centralCompra = new Central.Entities.Compras();
                        centralCompra.Cantidad = LAcompra.Cantidad;
                        centralCompra.Compra_ID = 0;
                        centralCompra.CostoUnitario = LAcompra.CostoUnitario;
                        centralCompra.Fecha = LAcompra.FechaAlta;
                        centralCompra.MarcaRefaccion_ID = LAcompra.Marca;
                        centralCompra.OrdenCompra_ID = LAcompra.OrdenCompra;
                        centralCompra.Refaccion_ID = LAcompra.Refaccion;
                        centralCompra.RefaccionesSurtidas = (int)Central.DB.GetNullableInt32(LAcompra.RefSurtidas);
                        centralCompra.Usuario_ID = LAcompra.UsuarioAlta;

                        if (Central.DB.Exists("Compras", Param("OrdenCompra_ID", centralCompra.OrdenCompra_ID),
                                Param("Refaccion_ID", centralCompra.Refaccion_ID),
                                    Param("MarcaRefaccion_ID", centralCompra.MarcaRefaccion_ID)))
                        {
                            //  Consulta la compra ID
                            centralCompra.Compra_ID =
                                Convert.ToInt32(Central.DB.ReadScalar("Compras", "Compra_ID",
                                    Param("OrdenCompra_ID", centralCompra.OrdenCompra_ID),
                                        Param("Refaccion_ID", centralCompra.Refaccion_ID),
                                            Param("MarcaRefaccion_ID", centralCompra.MarcaRefaccion_ID)));

                            centralCompra.Update();
                        }
                        else
                        {
                            centralCompra.Create();
                        }

                        Console.WriteLine(String.Format("Registro actualizado OrdenCompra_ID: {0}", centralCompra.OrdenCompra_ID));
                    }
                }
            }

            //  Concesiones            
            public void SyncConcesiones()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Concesion_ID),0) folio FROM Concesiones WHERE EstacionReferencia_ID = @Estacion";

                LA.Entities.Concesiones ConcesionesLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.Concesiones.Read(out ConcesionesLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = ConcesionesLA.Folio;

                    Central.Entities.Concesiones centralConcesion = new Central.Entities.Concesiones();
                    centralConcesion.Activo = (ConcesionesLA.Status == 1) ? true : false;
                    
                    centralConcesion.Empresa_ID = (int)((ConcesionesLA.EmpresaConcesionaria==null) ? 1 : ConcesionesLA.EmpresaConcesionaria); // CAM
                    centralConcesion.NumeroConcesion = ConcesionesLA.NumeroConcesion;
                    centralConcesion.Placa = ConcesionesLA.Placa;
                    centralConcesion.Referencia_ID = ConcesionesLA.Folio;
                    centralConcesion.TipoConcesion_ID = ConcesionesLA.Tipo;

                    if (Central.DB.Exists("Concesiones",
                            Param("NumeroConcesion", centralConcesion.NumeroConcesion),
                                Param("Placa", centralConcesion.Placa),
                                    Param("Referencia_ID", centralConcesion.Referencia_ID),
                                        Param("EstacionReferencia_ID", Estacion)))
                    {
                        //  Consulta la concesion_ID
                        centralConcesion.Concesion_ID =
                            Convert.ToInt32(Central.DB.ReadScalar("Concesiones", "Concesion_ID",
                                Param("NumeroConcesion", centralConcesion.NumeroConcesion),
                                    Param("Placa", centralConcesion.Placa),
                                        Param("Referencia_ID", centralConcesion.Referencia_ID),
                                            Param("EstacionReferencia_ID", Estacion)));

                        centralConcesion.Update();
                    }
                    else
                    {
                        centralConcesion.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Concesion_ID: {0}", centralConcesion.Concesion_ID));
                }                             
            }   //  End method

            //  Conductores
            public void SyncConductores()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Conductores WHERE Estacion_ID = @Estacion";

                LA.Entities.Conductores ConductoresLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.Conductores.Read(out ConductoresLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = ConductoresLA.Folio;

                    Central.Entities.Conductores centralConductor = new Central.Entities.Conductores();
                    centralConductor.ActaNacimiento = (ConductoresLA.DocumentacionConductor==null) ? "" : ConductoresLA.DocumentacionConductor.ActaNacimiento;
                    centralConductor.AñosExperiencia = (ConductoresLA.RegistroPublicitarioConductor == null) ? null : (Int32?)(AppHelper.IsNull(ConductoresLA.RegistroPublicitarioConductor.AñosExperiencia, 0));
                    centralConductor.Apellidos = ConductoresLA.ApellidoPaterno + " " + ConductoresLA.ApellidoMaterno;
                    centralConductor.Apellidos_Aval = (ConductoresLA.AvalConductor==null) ? "" : ConductoresLA.AvalConductor.ApellidoPaterno + " " + ConductoresLA.AvalConductor.ApellidoMaterno;
                    centralConductor.BloquearConductor = (ConductoresLA.Detalle == null) ? false : ConductoresLA.Detalle.BloquearConductor;
                    centralConductor.CartaNoAntecedentes = (ConductoresLA.DocumentacionConductor==null) ? "" :ConductoresLA.DocumentacionConductor.CartaNoAntecedentes;
                    centralConductor.Ciudad = ConductoresLA.Ciudad;
                    centralConductor.Ciudad_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Ciudad;
                    centralConductor.CodigoPostal = ConductoresLA.CP.ToString();
                    centralConductor.CodigoPostal_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.CP.ToString();
                    centralConductor.Comentarios = (ConductoresLA.RegistroPublicitarioConductor == null) ? "" :  ConductoresLA.RegistroPublicitarioConductor.Comentarios;
                    centralConductor.ComprobanteDomicilio = (ConductoresLA.DocumentacionConductor == null) ? "" : ConductoresLA.DocumentacionConductor.ComprobanteDomicilio;
                    centralConductor.ComprobanteDomicilio_Aval = (ConductoresLA.DocumentacionConductor == null) ? "" : ConductoresLA.DocumentacionConductor.ComprobanteDomicilioAval;
                    centralConductor.Conductor_ID = 0;
                    centralConductor.CredencialElector = (ConductoresLA.DocumentacionConductor == null) ? "" : ConductoresLA.DocumentacionConductor.CredencialElector;
                    centralConductor.CredencialElector_Aval = (ConductoresLA.DocumentacionConductor == null) ? "" : ConductoresLA.DocumentacionConductor.CredencialElectorAval;
                    centralConductor.Cronocasco = (ConductoresLA.Detalle == null) ? false : ConductoresLA.Detalle.Cronocasco;
                    centralConductor.CumplioPerfil = (ConductoresLA.RegistroPublicitarioConductor == null) ? false : ConductoresLA.RegistroPublicitarioConductor.CumplioPerfil;
                    centralConductor.CURP = ConductoresLA.Curp;
                    centralConductor.Curp_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Curp;
                    centralConductor.Domicilio = ConductoresLA.Calle + " No. " + ConductoresLA.NumeroCasa + ", Col. " + ConductoresLA.Colonia;
                    centralConductor.Domicilio_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Calle + " No. " + ConductoresLA.AvalConductor.NumeroCasa + ", Col. " + ConductoresLA.AvalConductor.Colonia;
                    centralConductor.Edad = (ConductoresLA.RegistroPublicitarioConductor == null) ? null : (int?)(AppHelper.IsNull(ConductoresLA.RegistroPublicitarioConductor.Edad, 0));
                    centralConductor.Email = ConductoresLA.CorreoElectronico;
                    centralConductor.Email_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.CorreoElectronico;
                    centralConductor.Entidad = ConductoresLA.Estado;
                    centralConductor.Estacion_ID = this.Estacion; // LA
                    centralConductor.Estado_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Estado;
                    centralConductor.EstadoCivil = (ConductoresLA.RegistroPublicitarioConductor == null) ? "" : ConductoresLA.RegistroPublicitarioConductor.EstadoCivil;
                    centralConductor.EstatusConductor_ID = (ConductoresLA.Status==1) ? 1 : ConductoresLA.Status + 4; // Convertir
                    centralConductor.Fecha = ConductoresLA.FechaAlta;
                    centralConductor.FolioLicencia = (ConductoresLA.Licencia == null) ? "" : ConductoresLA.Licencia.Folio.ToString();
                    centralConductor.Fotografia = null; //    Esta no se lleva    // Hay que actualizar el proceso de creación y actualización
                    centralConductor.Genero = "M";
                    centralConductor.Interesado = (ConductoresLA.RegistroPublicitarioConductor == null) ? false : ConductoresLA.RegistroPublicitarioConductor.Interesado;
                    centralConductor.MedioPublicitario_ID = (ConductoresLA.RegistroPublicitarioConductor == null) ? null : (int?)ConductoresLA.RegistroPublicitarioConductor.MedioPublicitario;
                    centralConductor.MensajeACaja = (ConductoresLA.Detalle == null) ? "" : ConductoresLA.Detalle.MensajeACaja;
                    centralConductor.Mercado_ID = (ConductoresLA.RegistroPublicitarioConductor == null) ? null : (int?)ConductoresLA.RegistroPublicitarioConductor.PlanEmpresarial; // Hay que hacer el mapeo correcto
                    centralConductor.Movil = null;
                    centralConductor.Nombre = ConductoresLA.Nombre;
                    centralConductor.Nombre_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Nombre;
                    centralConductor.Referencia_ID = ConductoresLA.Folio;
                    centralConductor.RFC = ConductoresLA.Rfc;
                    centralConductor.Rfc_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Rfc;
                    centralConductor.SaldoATratar = (ConductoresLA.Detalle == null) ? 0 : ConductoresLA.Detalle.SaldoATratar;
                    centralConductor.Solicitud = (ConductoresLA.DocumentacionConductor == null) ? "" : ConductoresLA.DocumentacionConductor.Solicitud;
                    centralConductor.Telefono = ConductoresLA.Telefono;
                    centralConductor.Telefono_Aval = (ConductoresLA.AvalConductor == null) ? "" : ConductoresLA.AvalConductor.Telefono;
                    centralConductor.Telefono2 = null;
                    centralConductor.TerminalDatos = (ConductoresLA.Detalle == null) ? false : ConductoresLA.Detalle.TerminalDatos;
                    centralConductor.TipoLicencia_ID = (ConductoresLA.Licencia == null) ? null : (int?)ConductoresLA.Licencia.Tipo; // Revisar si entra directo
                    centralConductor.Usuario_ID = ConductoresLA.UsuarioAlta;
                    centralConductor.VenceLicencia = (ConductoresLA.Licencia == null) ? null : (DateTime?)ConductoresLA.Licencia.FechaVencimiento;

                    if (Central.DB.Exists("Conductores", Param("Estacion_ID", Estacion), Param("Referencia_ID", centralConductor.Referencia_ID)))
                    {
                        //  Get Conductor_ID
                        centralConductor.Conductor_ID =
                            Convert.ToInt32(Central.DB.ReadScalar("Conductores", "Conductor_ID",
                                Param("Estacion_ID", Estacion),
                                    Param("Referencia_ID", centralConductor.Referencia_ID)));
                        centralConductor.Update();
                    }
                    else
                    {
                        centralConductor.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Conductor_ID: {0}", centralConductor.Conductor_ID));
                }
                
                //List<LA.Entities.Conductores> conductoresLA = LA.Entities.Conductores.Read();

                //foreach (LA.Entities.Conductores LAconductor in conductoresLA)
                //{
                    
                //}   //  End foreach
            }   //  End Method

            //  Contratos
            public void SyncContratos()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Contratos WHERE Estacion_ID = @Estacion";

                LA.Entities.Contratos ContratosLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.Contratos.Read(out ContratosLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = ContratosLA.Folio;

                    Central.Entities.Contratos centralContrato = new Central.Entities.Contratos();
                    centralContrato.CobroPermanente = (ContratosLA.FechaFinal == null) ? true : false;
                    centralContrato.Comentarios = "";
                    centralContrato.Concepto_ID = 1;
                    centralContrato.Conductor_ID = Central.Entities.Conductores.Read(Param("Estacion_ID", Estacion), Param("Referencia_ID", ContratosLA.Conductor)).Conductor_ID;
                    
                    // Si no existe el conductor copia, insertarlo y relacionarlo
                    if (ContratosLA.Copia == null)
                    {
                        centralContrato.ConductorCopia_ID = null;
                    }
                    else
                    {
                        Central.Entities.Conductores cond = Central.Entities.Conductores.Read(Param("Rfc", ContratosLA.Copia.Rfc));
                        if (cond==null)
                        {
                            //  Insertar conductor en Central
                            //  a partir de contratos copia
                            cond = new Central.Entities.Conductores();
                            cond.Apellidos = ContratosLA.Copia.ApellidoPaterno + " " + ContratosLA.Copia.ApellidoMaterno;
                            cond.Domicilio = ContratosLA.Copia.Colonia + ", " + ContratosLA.Copia.Calle + " No. " + ContratosLA.Copia.NumeroCasa;
                            cond.Ciudad = ContratosLA.Copia.Ciudad;
                            cond.Email = ContratosLA.Copia.CorreoElectronico;
                            cond.CodigoPostal = ContratosLA.Copia.CP.ToString();
                            cond.CURP = ContratosLA.Copia.Curp;
                            cond.Entidad = ContratosLA.Copia.Estado;
                            cond.Fecha = ContratosLA.Copia.FechaAlta;
                            cond.Nombre = ContratosLA.Copia.Nombre;
                            cond.RFC = ContratosLA.Copia.Rfc;
                            cond.Telefono = ContratosLA.Copia.Telefono;
                            cond.Usuario_ID = ContratosLA.Copia.UsuarioAlta;
                            cond.Estacion_ID = Estacion;
                            cond.EstatusConductor_ID = 1;
                            cond.Create();
                            centralContrato.ConductorCopia_ID = cond.Conductor_ID;
                        }
                        else
                        {
                            centralContrato.ConductorCopia_ID = cond.Conductor_ID;
                        }                        
                    }                    
                    
                    centralContrato.Contrato_ID = 0; // A actualizar si es update
                    centralContrato.Cuenta_ID = 1;
                    centralContrato.Descripcion = "Contrato de renta folio " + ContratosLA.Folio.ToString();

                    //  Obtener los días de cobro
                    centralContrato.DiasDeCobro_ID = (int)ContratosLA.Planes.DiasDeCobro;

                    if (ContratosLA.Tipo == 3)
                    {
                        centralContrato.Empresa_ID = 5; // CCR
                    }
                    else
                    {
                        centralContrato.Empresa_ID = Empresa; // CAM
                    }                    
                    centralContrato.Estacion_ID = Estacion;
                    centralContrato.EstatusContrato_ID = (ContratosLA.Status==1) ? 1 : ContratosLA.Status + 7;
                    centralContrato.FechaFinal = Central.DB.GetNullableDateTime(ContratosLA.FechaFinal);
                    centralContrato.FechaInicial = ContratosLA.FechaInicial;
                    centralContrato.FondoResidual = Convert.ToInt32(AppHelper.IsNull(ContratosLA.Planes.FondoResidual, 0));                    
                    centralContrato.ModeloUnidad_ID = 
                        Central.Entities.ModelosUnidades.Read(Param("referencia_id",(int)ContratosLA.Planes.Modelo), Param("EmpresaReferencia", Empresa)).ModeloUnidad_ID;
                    centralContrato.MontoDiario = ContratosLA.Planes.RentaBase;
                    centralContrato.NumeroEconomico = 
                        Central.Entities.Unidades.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", ContratosLA.Unidad)).NumeroEconomico;
                    centralContrato.TipoContrato_ID = (ContratosLA.Tipo==3) ? 2 : ContratosLA.Tipo; // Si 3 entonces es CCR
                    centralContrato.Unidad_ID = Central.Entities.Unidades.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", ContratosLA.Unidad)).Unidad_ID;
                    centralContrato.Referencia_ID = folio;
                    if (Central.DB.Exists("Contratos", Param("Estacion_ID", this.Estacion), Param("Referencia_ID", ContratosLA.Folio)))
                    {
                        //  Obtener el contrato ID
                        centralContrato.Contrato_ID =
                            Convert.ToInt32(Central.DB.ReadScalar("Contratos", "Contrato_ID",
                                Param("Estacion_ID", this.Estacion), Param("Referencia_ID", ContratosLA.Folio)));
                        centralContrato.Update();
                    }
                    else
                    {
                        centralContrato.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Contrato_ID: {0}", centralContrato.Contrato_ID));
                }

            }   //  End Method

            //  Usuarios
            public void SyncUsuarios()
            {
                List<LA.Entities.Usuarios> usuariosLA = LA.Entities.Usuarios.Read();
                foreach (LA.Entities.Usuarios usuarioLA in usuariosLA)
                {
                    Central.Entities.Usuarios usuario = new Central.Entities.Usuarios();
                    usuario.Activo = (usuarioLA.Status == 1) ? true : false;
                    usuario.Apellidos = usuarioLA.ApellidoPaterno + " " + usuarioLA.ApellidoMaterno;
                    usuario.Email = "";
                    usuario.Empresa_ID = Empresa; // CAM
                    usuario.Estacion_ID = Estacion; // LA
                    usuario.Nombre = usuarioLA.Nombre;
                    usuario.pwd = (byte[])Central.DB.QueryScalar(String.Format("SELECT PWDENCRYPT('{0}')", usuarioLA.Pwd));
                    usuario.Usuario_ID = usuarioLA.Clave;

                    // if exists update else insert
                    if (Central.DB.Exists("Usuarios", Param("Usuario_ID", usuario.Usuario_ID)))
                    {
                        usuario.Update();
                    }
                    else
                    {
                        usuario.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Usuario: {0}", usuario.Usuario_ID));
                }
            }

            private int CuentaDeFondo(int fondo)
            {
                int cuenta = 0;

                switch (fondo)
                { 
                    case 1: cuenta = 1; break;
                    case 2: cuenta = 2; break;
                    case 3: cuenta = 3; break;
                    case 5: cuenta = 4; break;
                    case 11: cuenta = 5; break;
                    case 12: cuenta = 6; break;
                    case 13: cuenta = 7; break;
                    case 14: cuenta = 1; break;
                    case 15: cuenta = 8; break;
                    case 16: cuenta = 32; break; // BOTON DE PANICO
                }

                return cuenta;
            }

            private int EmpresaDeFondo(int fondo)
            {
                int empresa = 0;

                switch (fondo)
                {
                    case 1: empresa  = 2; break;
                    case 2: empresa  = 2; break;
                    case 3: empresa  = 2; break;
                    case 5: empresa  = 4; break;
                    case 11: empresa  = 6; break;
                    case 12: empresa  = 2; break;
                    case 13: empresa  = 2; break;
                    case 14: empresa  = 5; break;
                    case 15: empresa  = 6; break;
                    case 16: empresa  = 2; break;
                }

                return empresa;
            }

            //  CuentaCajas
            public void SyncCuentaCajas()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM CuentaCajas WHERE Estacion_ID = @Estacion";

                LA.Entities.MovimientosCaja CuentaCajasLA;
                int folio, maxfolio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));
                maxfolio = Convert.ToInt32(LA.DB.QueryScalar("SELECT MAX(Folio) MaxFolio FROM MovimientosCaja"));

                while (LA.Entities.MovimientosCaja.Read(out CuentaCajasLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = CuentaCajasLA.Folio;

                    Central.Entities.CuentaCajas centralCuentaCajas = new Central.Entities.CuentaCajas();
                    centralCuentaCajas.Referencia_ID = CuentaCajasLA.Folio;
                    centralCuentaCajas.CuentaCaja_ID = 0;
                    centralCuentaCajas.Sesion_ID = Central.Entities.Sesiones.Read(Param("Referencia_ID", CuentaCajasLA.Sesion),
                        Param("Estacion_ID", Estacion)).Sesion_ID; // Verificar correspondencia

                    //  La empresa tambien depende del fondo
                    centralCuentaCajas.Empresa_ID = EmpresaDeFondo(CuentaCajasLA.Fondo);

                    centralCuentaCajas.Estacion_ID = Estacion;
                    centralCuentaCajas.Caja_ID = (int)Central.Entities.Sesiones.Read(Param("Referencia_ID", CuentaCajasLA.Sesion),
                        Param("Estacion_ID", Estacion)).Caja_ID; // Se obtiene de la sesion
                    
                    centralCuentaCajas.Ticket_ID = null;    //  No esta supeditada a un ticket
                    
                    centralCuentaCajas.Cuenta_ID = CuentaDeFondo(CuentaCajasLA.Fondo); // De este dato obtener la cuenta
                    
                    centralCuentaCajas.Concepto_ID = null; // No se lleva concepto

                    decimal abono, cargo;
                    if (CuentaCajasLA.Monto < 0)
                    {
                        abono = 0;
                        cargo = Math.Abs(CuentaCajasLA.Monto);
                    }
                    else
                    {
                        cargo = 0;
                        abono = Math.Abs(CuentaCajasLA.Monto);
                    }

                    centralCuentaCajas.Cargo = cargo; // De este dato depende
                    centralCuentaCajas.Abono = abono;
                    centralCuentaCajas.Saldo = 0; // Es calculado, meter dentro del create
                    centralCuentaCajas.Comentarios = "";
                    centralCuentaCajas.Fecha = CuentaCajasLA.Fecha;
                    centralCuentaCajas.Usuario_ID = CuentaCajasLA.Usuario;

                    if (Central.DB.Exists("CuentaCajas", Param("Referencia_ID", centralCuentaCajas.Referencia_ID),
                            Param("Estacion_ID",Estacion)))
                    {
                        //  Obtener el id
                        centralCuentaCajas.Update();
                    }
                    else
                    {
                        centralCuentaCajas.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado CuentaCajas: {0} de {1}", folio, maxfolio));
                }

            }	//	End Method SyncCuentaCajas

            private int CuentaDeCuenta(int cuentalocal)
            {
                int cuenta = 0;
                switch (cuentalocal)
                {
                    case 1: cuenta = 1; break;
                    case 2: cuenta = 4; break;
                    case 3: cuenta = 3; break;
                    case 4: cuenta = 2; break;
                    case 9: cuenta = 2; break;
                    case 10: cuenta = 8; break;
                    case 11: cuenta = 32; break;
                }
                return cuenta;
            }

            private int ConceptoCentral(int conceptolocal)
            {
                int concepto = 0;
                switch (conceptolocal)
                {
                    case 88: concepto = 92; break;
                    case 89: concepto = 93; break;
                    default: concepto = conceptolocal; break;
                }
                return concepto;
            }

            public void SyncCuentaConductores()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM CuentaConductores WHERE Estacion_ID IN (1,2,3,4,6,7)";

                LA.Entities.CuentaConductor CuentaConductoresLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry));

                while (LA.Entities.CuentaConductor.Read(out CuentaConductoresLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = CuentaConductoresLA.Folio;
                    
                    Central.Entities.CuentaConductores centralCuentaConductores = new Central.Entities.CuentaConductores();
                    centralCuentaConductores.Referencia_ID = folio;
                    centralCuentaConductores.CuentaConductor_ID = 0;

                    //Obtener segun concepto
                    //Del concepto obtener la cuenta
                    int cuenta = LA.Entities.Conceptos.Read(CuentaConductoresLA.Concepto).Cuenta;
                    int fondo = LA.Entities.Cuentas.Read(cuenta).FondoCaja;
                    //De la cuenta, obtener el fondo
                    //Del fondo, la empresa.
                    centralCuentaConductores.Empresa_ID = EmpresaDeFondo(fondo);

                    centralCuentaConductores.Estacion_ID = Estacion; // LA

                    if (CuentaConductoresLA.Unidad == 0)
                    {
                        centralCuentaConductores.Unidad_ID = null;
                    }
                    else
                    {
                        centralCuentaConductores.Unidad_ID =
                        Central.Entities.Unidades.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", CuentaConductoresLA.Unidad)).Unidad_ID;
                    }
                    
                    centralCuentaConductores.Conductor_ID =
                        Central.Entities.Conductores.Read(Param("Estacion_ID", Estacion), Param("Referencia_ID", CuentaConductoresLA.Conductor)).Conductor_ID;

                    // Verificar la caja para obtener la estación
                    if (CuentaConductoresLA.Caja == null)
                    {
                        centralCuentaConductores.Caja_ID = null;
                    }
                    else
                    {
                        if (CuentaConductoresLA.Caja == 1 || CuentaConductoresLA.Caja == 9)
                        {
                            centralCuentaConductores.Caja_ID =
                            Central.Entities.Cajas.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", CuentaConductoresLA.Caja)).Caja_ID;
                        }
                        else
                        {
                            centralCuentaConductores.Estacion_ID = CuentaConductoresLA.Caja; // Otra estacion
                            centralCuentaConductores.Caja_ID =
                            Central.Entities.Cajas.Read(Param("Estacion_ID", CuentaConductoresLA.Caja), Param("Referencia_ID", CuentaConductoresLA.Caja)).Caja_ID;
                        }
                    }                                        

                    //  Es posible que se pueda hacer referencia
                    //  Si folio tiene ticket local, buscar su ticket remoto
                    if (LA.DB.Exists("RecibosMovimientos", Param("Movimiento", CuentaConductoresLA.Folio)))
                    {
                        int recibo = (int)LA.Entities.RecibosMovimientos.Read(Param("Movimiento", CuentaConductoresLA.Folio)).Recibo;
                        int ticket_id = Central.Entities.Tickets.Read(Param("Referencia_ID", recibo), Param("Estacion_ID", Estacion)).Ticket_ID;
                        centralCuentaConductores.Ticket_ID = ticket_id;
                    }
                    else
                    {
                        centralCuentaConductores.Ticket_ID = null; // Ticket a null
                    }  

                    centralCuentaConductores.Cuenta_ID = CuentaDeCuenta(cuenta);
                    centralCuentaConductores.Concepto_ID = ConceptoCentral(CuentaConductoresLA.Concepto);

                    decimal abono, cargo;
                    if (CuentaConductoresLA.Monto < 0)
                    {
                        abono = 0;
                        cargo = Math.Abs(CuentaConductoresLA.Monto);
                    }
                    else
                    {
                        cargo = 0;
                        abono = Math.Abs(CuentaConductoresLA.Monto);
                    }

                    centralCuentaConductores.Cargo = cargo;
                    centralCuentaConductores.Abono = abono;
                    centralCuentaConductores.Saldo = 0; // Calculado
                    centralCuentaConductores.Comentarios = CuentaConductoresLA.Comentarios;
                    centralCuentaConductores.Fecha = CuentaConductoresLA.FechaAlta;
                    centralCuentaConductores.Usuario_ID = CuentaConductoresLA.UsuarioAlta;

                    if (Central.DB.Exists("CuentaConductores", Param("CuentaConductor_ID", centralCuentaConductores.CuentaConductor_ID)))
                    {
                        //  Obtener la clave
                        centralCuentaConductores.Update();
                    }
                    else
                    {
                        centralCuentaConductores.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado CuentaConductor_ID: {0}", centralCuentaConductores.Conductor_ID));

                }
            }	//	End Method SyncCuentaConductores

            public void SyncFamilias()
            {                
                List<LA.Entities.Familias> familiasLA = LA.Entities.Familias.Read();
                foreach (LA.Entities.Familias FamiliasLA in familiasLA)
                {
                    Central.Entities.Familias centralFamilias = new Central.Entities.Familias();
                    centralFamilias.Familia_ID = FamiliasLA.Folio;
                    centralFamilias.Nombre = FamiliasLA.Descripcion;


                    if (Central.DB.Exists("Familias", Param("Familia_ID", centralFamilias.Familia_ID)))
                    {
                        centralFamilias.Update();
                    }
                    else
                    {
                        centralFamilias.Create(true);
                    }
                    Console.WriteLine(String.Format("Registro actualizado Familia: {0}", centralFamilias.Familia_ID));
                }	//	End foreach

            }	//	End Method SyncFamilias

            public void SyncMarcasRefacciones()
            {
                List<LA.Entities.MarcasRefacciones> marcasrefaccionesLA = 
                    LA.Entities.MarcasRefacciones.Read();
                foreach (LA.Entities.MarcasRefacciones MarcasRefaccionesLA in marcasrefaccionesLA)
                {
                    Central.Entities.MarcasRefacciones centralMarcasRefacciones = new Central.Entities.MarcasRefacciones();
                    centralMarcasRefacciones.MarcaRefaccion_ID = MarcasRefaccionesLA.Folio;
                    centralMarcasRefacciones.Nombre = MarcasRefaccionesLA.Descripcion;

                    if (Central.DB.Exists("MarcasRefacciones", Param("MarcaRefaccion_ID", centralMarcasRefacciones.MarcaRefaccion_ID)))
                    {
                        centralMarcasRefacciones.Update();
                    }
                    else
                    {
                        centralMarcasRefacciones.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado MarcaRefaccion_ID: {0}", centralMarcasRefacciones.MarcaRefaccion_ID));
                }	//	End foreach

            }	//	End Method SyncMarcasRefacciones

            public void SyncEstatusMecanicos()
            {
                List<LA.Entities.StatusMecanicos> estatusmecanicosLA = LA.Entities.StatusMecanicos.Read();
                foreach (LA.Entities.StatusMecanicos EstatusMecanicosLA in estatusmecanicosLA)
                {
                    Central.Entities.EstatusMecanicos centralEstatusMecanicos = new Central.Entities.EstatusMecanicos();
                    centralEstatusMecanicos.EstatusMecanico_ID = EstatusMecanicosLA.Folio;
                    centralEstatusMecanicos.Nombre = EstatusMecanicosLA.Descripcion;


                    if (Central.DB.Exists("EstatusMecanicos", Param("EstatusMecanico_ID", centralEstatusMecanicos.EstatusMecanico_ID)))
                    {
                        centralEstatusMecanicos.Update();
                    }
                    else
                    {
                        centralEstatusMecanicos.Create(true);
                    }
                }	//	End foreach

            }	//	End Method SyncEstatusMecanicos

            public void SyncMecanicos()
            {
                //  Ajustar con read
                List<LA.Entities.Mecanicos> mecanicosLA = LA.Entities.Mecanicos.Read();
                foreach (LA.Entities.Mecanicos MecanicosLA in mecanicosLA)
                {
                    Central.Entities.Mecanicos centralMecanicos = new Central.Entities.Mecanicos();
                    centralMecanicos.Mecanico_ID = MecanicosLA.Folio;
                    centralMecanicos.CategoriaMecanico_ID = MecanicosLA.Categoria;
                    centralMecanicos.EstatusMecanico_ID = MecanicosLA.Status;
                    centralMecanicos.Usuario_ID = MecanicosLA.UsuarioAlta;
                    centralMecanicos.Fecha = MecanicosLA.FechaAlta;
                    centralMecanicos.CodigoBarras = MecanicosLA.CodigoBarras;
                    centralMecanicos.Nombres = MecanicosLA.Nombre;
                    centralMecanicos.Apellidos = MecanicosLA.ApellidoPaterno +  " " + MecanicosLA.ApellidoMaterno;
                    centralMecanicos.Rfc = MecanicosLA.Rfc;
                    centralMecanicos.Curp = MecanicosLA.Curp;
                    centralMecanicos.NSS = MecanicosLA.NumeroSeguroSocial;
                    centralMecanicos.Domicilio = MecanicosLA.Calle + " No. " + MecanicosLA.Numero + ", Col. " + MecanicosLA.Colonia;
                    centralMecanicos.Ciudad = MecanicosLA.Ciudad;
                    centralMecanicos.Entidad = MecanicosLA.Estado;
                    centralMecanicos.CodigoPostal = MecanicosLA.CodigoPostal.ToString();
                    centralMecanicos.Telefono = MecanicosLA.Telefonos;
                    centralMecanicos.CorreoElectronico = MecanicosLA.CorreoElectronico;
                    centralMecanicos.SalarioDiario = MecanicosLA.SalarioDiario;
                    centralMecanicos.HorarioEntrada = MecanicosLA.HorarioEntrada;
                    centralMecanicos.HorarioSalida = MecanicosLA.HorarioSalida;


                    if (Central.DB.Exists("Mecanicos", Param("Mecanico_ID", centralMecanicos.Mecanico_ID)))
                    {
                        centralMecanicos.Update();
                    }
                    else
                    {
                        centralMecanicos.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado Mecanico_ID: {0}", centralMecanicos.Mecanico_ID));

                }	//	End foreach

            }	//	End Method SyncMecanicos

            public void SyncModelos()
            {
                List<LA.Entities.ModelosTaller> modelosLA = LA.Entities.ModelosTaller.Read();
                foreach (LA.Entities.ModelosTaller ModelosLA in modelosLA)
                {
                    Central.Entities.Modelos centralModelos = new Central.Entities.Modelos();
                    centralModelos.Modelo_ID = ModelosLA.Folio;
                    centralModelos.Nombre = ModelosLA.Descripcion;


                    if (Central.DB.Exists("Modelos", Param("Modelo_ID", centralModelos.Modelo_ID)))
                    {
                        centralModelos.Update();
                    }
                    else
                    {
                        centralModelos.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Modelo_ID: {0}", centralModelos.Modelo_ID));
                }	//	End foreach

            }	//	End Method SyncModelos

            public void SyncModelosUnidades()
            {
                List<LA.Entities.Modelos> modelosunidadesLA = LA.Entities.Modelos.Read();
                foreach (LA.Entities.Modelos ModelosUnidadesLA in modelosunidadesLA)
                {
                    Central.Entities.ModelosUnidades centralModelosUnidades = new Central.Entities.ModelosUnidades();
                    centralModelosUnidades.ModeloUnidad_ID = 0;

                    centralModelosUnidades.MarcaUnidad_ID = 1; // Actualizar posteriormente
                    centralModelosUnidades.Descripcion = ModelosUnidadesLA.Descripcion;
                    centralModelosUnidades.PrecioLista = Convert.ToDecimal(AppHelper.IsNull(ModelosUnidadesLA.PrecioLista, 0));
                    centralModelosUnidades.Anio = ModelosUnidadesLA.Año;
                    centralModelosUnidades.Deposito = Convert.ToDecimal(AppHelper.IsNull(ModelosUnidadesLA.Deposito, 0));
                    centralModelosUnidades.Activo = (ModelosUnidadesLA.Status == 1) ? true : false;
                    centralModelosUnidades.referencia_id = ModelosUnidadesLA.Folio;
                    centralModelosUnidades.EmpresaReferencia = Empresa; //    CAM


                    if (Central.DB.Exists("ModelosUnidades", Param("ModeloUnidad_ID", centralModelosUnidades.ModeloUnidad_ID)))
                    {
                        centralModelosUnidades.Update();
                    }
                    else
                    {
                        centralModelosUnidades.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado ModeloUnidad_ID: {0}", centralModelosUnidades.ModeloUnidad_ID));

                }	//	End foreach

            }	//	End Method SyncModelosUnidades

            private int GetTipoMovimientoInventario(string tipo)
            {
                int result = 0;

                switch(tipo)
                {
                    case "O.T.":
                        result = 1;
                        break;
                    case "Compra":
                        result = 2;
                        break;
                    case "Ajuste":
                        result = 3;
                        break;
                    case "CancelO.C.":
                        result = 4;
                        break;
                    case "Inicial":
                        result = 5;
                        break;
                    case "CancelO.T.":
                        result = 6;
                        break;
                }

                return result;
            }

            public void SyncMovimientosInventario()
            {
                //  Ajustar con read
                List<LA.Entities.HistorialInventario> historialinventarioLA = LA.Entities.HistorialInventario.Read();
                foreach (LA.Entities.HistorialInventario HistorialInventarioLA in historialinventarioLA)
                {
                    Central.Entities.MovimientosInventario centralMovimientosInventario = new Central.Entities.MovimientosInventario();
                    centralMovimientosInventario.MovimientoInventario_ID = 0;
                    int tipo = GetTipoMovimientoInventario(HistorialInventarioLA.Tipo);
                    centralMovimientosInventario.TipoMovimientoInventario_ID = tipo;
                    centralMovimientosInventario.OrdenCompra_ID = (tipo == 2 || tipo == 4) ? Convert.ToInt32(HistorialInventarioLA.Folio) : Central.DB.GetNullableInt32(null);
                    centralMovimientosInventario.OrdenTrabajo_ID = (tipo == 1 || tipo == 6) ? Convert.ToInt32(HistorialInventarioLA.Folio) : Central.DB.GetNullableInt32(null);
                    centralMovimientosInventario.NotaAlmacen_ID = HistorialInventarioLA.NotaAlmacen;
                    centralMovimientosInventario.AjusteInventario_ID = (tipo == 3) ? Convert.ToInt32(HistorialInventarioLA.Folio) : Central.DB.GetNullableInt32(null);
                    centralMovimientosInventario.Usuario_ID = HistorialInventarioLA.Usuario;
                    centralMovimientosInventario.Refaccion_ID = HistorialInventarioLA.Refaccion;
                    centralMovimientosInventario.Fecha = HistorialInventarioLA.Fecha;
                    centralMovimientosInventario.Cantidad = Convert.ToInt32(HistorialInventarioLA.Cantidad);
                    centralMovimientosInventario.CostoUnitario = HistorialInventarioLA.CostoUnitario;
                    centralMovimientosInventario.Valor = HistorialInventarioLA.Valor;
                    centralMovimientosInventario.CantidadPrev = Convert.ToInt32(HistorialInventarioLA.CantidadPrev);
                    centralMovimientosInventario.ValorPrev = HistorialInventarioLA.ValorPrev;
                    centralMovimientosInventario.CantidadPost = Convert.ToInt32(HistorialInventarioLA.CantidadPost);
                    centralMovimientosInventario.ValorPost = HistorialInventarioLA.ValorPost;
                    centralMovimientosInventario.CantidadPrevProm = 0; // Por calcular
                    centralMovimientosInventario.ValorPrevProm = 0; // Por calcular
                    centralMovimientosInventario.CantidadPostProm = 0; // Por calcular
                    centralMovimientosInventario.ValorPostProm = 0; // Por calcular
                    centralMovimientosInventario.Referencia = HistorialInventarioLA.Movimiento;


                    if (Central.DB.Exists("MovimientosInventario", Param("Referencia", centralMovimientosInventario.Referencia)))
                    {
                        //  Get
                        centralMovimientosInventario.Update();
                    }
                    else
                    {
                        centralMovimientosInventario.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado MovimientoInventario_ID: {0}", centralMovimientosInventario.MovimientoInventario_ID));
                }	//	End foreach

            }	//	End Method SyncMovimientosInventario

            public void SyncNotasAlmacen()
            {
                //  Ajustar con read
                List<LA.Entities.NotasAlmacen> notasalmacenLA = LA.Entities.NotasAlmacen.Read();
                foreach (LA.Entities.NotasAlmacen NotasAlmacenLA in notasalmacenLA)
                {
                    if (NotasAlmacenLA.OrdenCompra != null && NotasAlmacenLA.OrdenCompra == 0) continue;
                    if (NotasAlmacenLA.OrdenTrabajo != null && NotasAlmacenLA.OrdenTrabajo == 0) continue;

                    Central.Entities.NotasAlmacen centralNotasAlmacen = new Central.Entities.NotasAlmacen();
                    centralNotasAlmacen.NotaAlmacen_ID = NotasAlmacenLA.NotaAlmacenID;
                    centralNotasAlmacen.Usuario_ID = NotasAlmacenLA.Usuario;
                    centralNotasAlmacen.TipoMovimientoInventario_ID = (NotasAlmacenLA.Tipo == "ENTRADA") ? 1 : 2;
                    centralNotasAlmacen.OrdenCompra_ID = NotasAlmacenLA.OrdenCompra;
                    centralNotasAlmacen.OrdenTrabajo_ID = NotasAlmacenLA.OrdenTrabajo;
                    centralNotasAlmacen.Fecha = NotasAlmacenLA.Fecha;                    

                    if (Central.DB.Exists("NotasAlmacen", Param("NotaAlmacen_ID", centralNotasAlmacen.NotaAlmacen_ID)))
                    {
                        centralNotasAlmacen.Update();
                    }
                    else
                    {
                        centralNotasAlmacen.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado NotaAlmacen_ID: {0}", centralNotasAlmacen.NotaAlmacen_ID));

                }	//	End foreach

            }	//	End Method SyncNotasAlmacen

            public void SyncOrdenesCompras()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(OrdenCompra_ID),0) folio FROM OrdenesCompra";

                LA.Entities.OrdenesCompras OrdenesComprasLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry));

                while (LA.Entities.OrdenesCompras.Read(out OrdenesComprasLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = OrdenesComprasLA.Folio;

                    Central.Entities.OrdenesCompras centralOrdenesCompras = new Central.Entities.OrdenesCompras();
                    centralOrdenesCompras.OrdenCompra_ID = OrdenesComprasLA.Folio;

                    //  Obtener el proveedor
                    //  Los proveedores deben estar datos de alta en el sistema previamente
                    //  buscar por rfc
                    int proveedor = Central.Entities.Empresas.Read(Param("Rfc", OrdenesComprasLA.Proveedores.Rfc))[0].Empresa_ID;
                    centralOrdenesCompras.Proveedor_ID = proveedor;
                    centralOrdenesCompras.EstatusOrdenCompra_ID = Convert.ToInt32(AppHelper.IsNull(OrdenesComprasLA.Status, 1));
                    centralOrdenesCompras.Usuario_ID = OrdenesComprasLA.UsuarioAlta;
                    centralOrdenesCompras.Fecha = OrdenesComprasLA.FechaAlta;
                    centralOrdenesCompras.Factura = OrdenesComprasLA.Factura;
                    centralOrdenesCompras.Subtotal = OrdenesComprasLA.SubTotal;
                    centralOrdenesCompras.IVA = OrdenesComprasLA.IVA;
                    centralOrdenesCompras.Total = OrdenesComprasLA.Total;

                    if (Central.DB.Exists("OrdenesCompras", Param("OrdenCompra_ID", centralOrdenesCompras.OrdenCompra_ID)))
                    {
                        centralOrdenesCompras.Update();
                    }
                    else
                    {
                        centralOrdenesCompras.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenCompra_ID: {0}", centralOrdenesCompras.OrdenCompra_ID));
                }

                //List<LA.Entities.OrdenesCompras> ordenescomprasLA = LA.Entities.OrdenesCompras.Read();
                //foreach (LA.Entities.OrdenesCompras OrdenesComprasLA in ordenescomprasLA)
                //{                    
                    

                //}	//	End foreach

            }	//	End Method SyncOrdenesCompras

            public void SyncOrdenesComprasCanceladas()
            {
                //  Ajustar con read
                List<LA.Entities.OrdenesComprasCanceladas> ordenescomprascanceladasLA = LA.Entities.OrdenesComprasCanceladas.Read();
                foreach (LA.Entities.OrdenesComprasCanceladas OrdenesComprasCanceladasLA in ordenescomprascanceladasLA)
                {
                    // si no tiene compra, no checar
                    if(!LA.DB.Exists("OrdenesCompras", Param("Folio", OrdenesComprasCanceladasLA.OrdenCompra))) continue;

                    Central.Entities.OrdenesComprasCanceladas centralOrdenesComprasCanceladas = new Central.Entities.OrdenesComprasCanceladas();
                    centralOrdenesComprasCanceladas.OrdenCompra_ID = OrdenesComprasCanceladasLA.OrdenCompra;                    
                    centralOrdenesComprasCanceladas.Usuario_ID = OrdenesComprasCanceladasLA.Usuario;
                    centralOrdenesComprasCanceladas.Fecha = OrdenesComprasCanceladasLA.Fecha;
                    centralOrdenesComprasCanceladas.Comentarios = OrdenesComprasCanceladasLA.Motivos;


                    if (Central.DB.Exists("OrdenesComprasCanceladas", Param("OrdenCompra_ID", centralOrdenesComprasCanceladas.OrdenCompra_ID)))
                    {
                        centralOrdenesComprasCanceladas.Update();
                    }
                    else
                    {
                        centralOrdenesComprasCanceladas.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenCompraCancelada_ID: {0}", centralOrdenesComprasCanceladas.OrdenCompra_ID));
                }	//	End foreach

            }	//	End Method SyncOrdenesComprasCanceladas

            public void SyncOrdenesServicios()
            {
                LA.Entities.OrdenesServicio OrdenesServiciosLA;
                string filter = "Folio > @Folio";
                string sort = "Folio ASC";
                int folio = Convert.ToInt32(Central.DB.QueryScalar("SELECT ISNULL(MAX(OrdenServicio_ID),0) folio FROM OrdenesServicios"));

                while (LA.Entities.OrdenesServicio.Read(out OrdenesServiciosLA,1,filter,sort,Param("@Folio",folio)))
                {
                    try
                    {
                        Central.Entities.OrdenesTrabajos.Read(OrdenesServiciosLA.OrdenTrabajo);
                    }
                    catch (SICASException sicasEx)
                    {
                        folio = OrdenesServiciosLA.Folio;
                        continue;
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }

                    Central.Entities.OrdenesServicios centralOrdenesServicios = new Central.Entities.OrdenesServicios();
                    folio = OrdenesServiciosLA.Folio;
                    
                    centralOrdenesServicios.OrdenServicio_ID = OrdenesServiciosLA.Folio;
                    centralOrdenesServicios.OrdenTrabajo_ID = OrdenesServiciosLA.OrdenTrabajo;
                    centralOrdenesServicios.ServicioMantenimiento_ID = OrdenesServiciosLA.Servicio;
                    centralOrdenesServicios.Mecanico_ID = OrdenesServiciosLA.Mecanico;
                    centralOrdenesServicios.EstatusOrdenServicio_ID = OrdenesServiciosLA.Status;
                    centralOrdenesServicios.Fecha = Central.DB.GetNullableDateTime(OrdenesServiciosLA.FechaSurtida);
                    centralOrdenesServicios.Cantidad = Convert.ToInt32(OrdenesServiciosLA.Cantidad);
                    centralOrdenesServicios.Precio = OrdenesServiciosLA.PrecioUnitario;
                    centralOrdenesServicios.Total = OrdenesServiciosLA.Total;


                    if (Central.DB.Exists("OrdenesServicios", Param("OrdenServicio_ID", centralOrdenesServicios.OrdenServicio_ID)))
                    {
                        centralOrdenesServicios.Update();
                    }
                    else
                    {
                        centralOrdenesServicios.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenServicio_ID: {0}", centralOrdenesServicios.OrdenServicio_ID));
                }

            }	//	End Method SyncOrdenesServicios

            public void SyncOrdenesServiciosRefacciones()
            {
                //  Ajustar como con compras
                List<LA.Entities.OrdenesServicioRefacciones> ordenesserviciosrefaccionesLA = LA.Entities.OrdenesServicioRefacciones.Read();
                foreach (LA.Entities.OrdenesServicioRefacciones OrdenesServiciosRefaccionesLA in ordenesserviciosrefaccionesLA)
                {
                    if (!Central.DB.Exists("OrdenesServicios", Param("OrdenServicio_ID", OrdenesServiciosRefaccionesLA.OrdenServicio)))
                    {
                        continue;
                    }
                    Central.Entities.OrdenesServiciosRefacciones centralOrdenesServiciosRefacciones = new Central.Entities.OrdenesServiciosRefacciones();
                    centralOrdenesServiciosRefacciones.OrdenServicioRefaccion_ID = 0;
                    centralOrdenesServiciosRefacciones.OrdenServicio_ID = OrdenesServiciosRefaccionesLA.OrdenServicio;
                    centralOrdenesServiciosRefacciones.Refaccion_ID = OrdenesServiciosRefaccionesLA.Refaccion;
                    centralOrdenesServiciosRefacciones.Cantidad = Convert.ToInt32(OrdenesServiciosRefaccionesLA.Cantidad);
                    centralOrdenesServiciosRefacciones.PrecioUnitario = OrdenesServiciosRefaccionesLA.PrecioUnitario;
                    centralOrdenesServiciosRefacciones.Total = OrdenesServiciosRefaccionesLA.Total;
                    centralOrdenesServiciosRefacciones.CostoUnitario = (decimal)OrdenesServiciosRefaccionesLA.CostoUnitario;
                    centralOrdenesServiciosRefacciones.RefSurtidas = Central.DB.GetNullableInt32(OrdenesServiciosRefaccionesLA.RefSurtidas);


                    if (Central.DB.Exists("OrdenesServiciosRefacciones", 
                            Param("OrdenServicio_ID", centralOrdenesServiciosRefacciones.OrdenServicio_ID),
                                Param("Refaccion_ID",centralOrdenesServiciosRefacciones.Refaccion_ID)))
                    {
                        //  Obtener OrdenServicioRefaccion_ID
                        centralOrdenesServiciosRefacciones.OrdenServicioRefaccion_ID =
                            Convert.ToInt32(Central.DB.ReadScalar("OrdenesServiciosRefacciones", "OrdenServicioRefaccion_ID",
                                Param("OrdenServicio_ID", centralOrdenesServiciosRefacciones.OrdenServicio_ID),
                                    Param("Refaccion_ID", centralOrdenesServiciosRefacciones.Refaccion_ID)));

                        centralOrdenesServiciosRefacciones.Update();
                    }
                    else
                    {
                        centralOrdenesServiciosRefacciones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenServicio: {0} Refaccion {1}", 
                        centralOrdenesServiciosRefacciones.OrdenServicio_ID, centralOrdenesServiciosRefacciones.Refaccion_ID));
                }	//	End foreach

            }	//	End Method SyncOrdenesServiciosRefacciones

            private int GetEmpresaClienteTaller(int clientetaller)
            {
                Dictionary<int, int> clientes = new Dictionary<int, int>();
   
                clientes.Add(7,5);
                clientes.Add(5,585);
                clientes.Add(4,586);
                clientes.Add(2,3);
                clientes.Add(1,2);

                return clientes[clientetaller];
            }

            public void SyncEstatusOrdenesTrabajos()
            {
                List<LA.Entities.StatusOrdenesTrabajo> estatusordenestrabajosLA = LA.Entities.StatusOrdenesTrabajo.Read();
                foreach (LA.Entities.StatusOrdenesTrabajo EstatusOrdenesTrabajosLA in estatusordenestrabajosLA)
                {
                    Central.Entities.EstatusOrdenesTrabajos centralEstatusOrdenesTrabajos = new Central.Entities.EstatusOrdenesTrabajos();
                    centralEstatusOrdenesTrabajos.EstatusOrdenTrabajo_ID = EstatusOrdenesTrabajosLA.Folio;
                    centralEstatusOrdenesTrabajos.Nombre = EstatusOrdenesTrabajosLA.Descripcion;

                    if (Central.DB.Exists("EstatusOrdenesTrabajos", Param("EstatusOrdenTrabajo_ID", centralEstatusOrdenesTrabajos.EstatusOrdenTrabajo_ID)))
                    {
                        centralEstatusOrdenesTrabajos.Update();
                    }
                    else
                    {
                        centralEstatusOrdenesTrabajos.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado EstatusOrdenTrabajo_ID: {0}", centralEstatusOrdenesTrabajos.EstatusOrdenTrabajo_ID));

                }	//	End foreach

            }	//	End Method SyncEstatusOrdenesTrabajos

            public void SyncTiposMantenimientos()
            {
                List<LA.Entities.TiposMantenimientos> tiposmantenimientosLA = LA.Entities.TiposMantenimientos.Read();
                foreach (LA.Entities.TiposMantenimientos TiposMantenimientosLA in tiposmantenimientosLA)
                {
                    Central.Entities.TiposMantenimientos centralTiposMantenimientos = new Central.Entities.TiposMantenimientos();
                    centralTiposMantenimientos.TipoMantenimiento_ID = TiposMantenimientosLA.Folio;
                    centralTiposMantenimientos.Nombre = TiposMantenimientosLA.Descripcion;


                    if (Central.DB.Exists("TiposMantenimientos", Param("TipoMantenimiento_ID", centralTiposMantenimientos.TipoMantenimiento_ID)))
                    {
                        centralTiposMantenimientos.Update();
                    }
                    else
                    {
                        centralTiposMantenimientos.Create(true);
                    }
                    Console.WriteLine(String.Format("Registro actualizado TipoMantenimiento_ID: {0}", centralTiposMantenimientos.TipoMantenimiento_ID));
                }	//	End foreach

            }	//	End Method SyncTiposMantenimientos

            public void SyncOrdenesTrabajos()
            {
                string filter = "Cliente <> 0 AND Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(OrdenTrabajo_ID),0) folio FROM OrdenesTrabajos";

                LA.Entities.OrdenesTrabajo OrdenesTrabajosLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry));

                while (LA.Entities.OrdenesTrabajo.Read(out OrdenesTrabajosLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = OrdenesTrabajosLA.Folio;
                    Central.Entities.OrdenesTrabajos centralOrdenesTrabajos = new Central.Entities.OrdenesTrabajos();
                    centralOrdenesTrabajos.OrdenTrabajo_ID = OrdenesTrabajosLA.Folio;
                    centralOrdenesTrabajos.Empresa_ID = GetEmpresaClienteTaller(OrdenesTrabajosLA.ClienteTaller.Tipo);
                    centralOrdenesTrabajos.TipoMantenimiento_ID = Convert.ToInt32(OrdenesTrabajosLA.TipoMantenimiento);
                    centralOrdenesTrabajos.ClienteFacturar_ID = GetEmpresaClienteTaller(OrdenesTrabajosLA.ClienteTaller.Tipo);

                    Central.Entities.Unidades unidad = Central.Entities.Unidades.Read(Param("Referencia_ID", OrdenesTrabajosLA.Unidad), Param("Estacion_ID", Estacion));
                    int unidad_id = 1;
                    if (unidad != null) unidad_id = unidad.Unidad_ID;

                    centralOrdenesTrabajos.Unidad_ID = unidad_id;
                    centralOrdenesTrabajos.EstatusOrdenTrabajo_ID = OrdenesTrabajosLA.Status;
                    centralOrdenesTrabajos.Caja_ID = (OrdenesTrabajosLA.Caja == 9) ? 2 : OrdenesTrabajosLA.Caja;
                    centralOrdenesTrabajos.Usuario_ID = OrdenesTrabajosLA.UsuarioAlta;
                    centralOrdenesTrabajos.Factura_ID = null;
                    centralOrdenesTrabajos.UsuarioFacturacion_ID = OrdenesTrabajosLA.UsuarioFacturacion;
                    centralOrdenesTrabajos.CodigoBarras = OrdenesTrabajosLA.CodigoBarras;
                    centralOrdenesTrabajos.Subtotal = OrdenesTrabajosLA.Subtotal;
                    centralOrdenesTrabajos.IVA = OrdenesTrabajosLA.IVA;
                    centralOrdenesTrabajos.Total = OrdenesTrabajosLA.Total;
                    centralOrdenesTrabajos.FechaAlta = OrdenesTrabajosLA.FechaAlta;
                    centralOrdenesTrabajos.FechaTerminacion = OrdenesTrabajosLA.FechaTerminacion;
                    centralOrdenesTrabajos.FechaPago = OrdenesTrabajosLA.FechaPago;
                    centralOrdenesTrabajos.NumeroEconomico = Convert.ToInt32(OrdenesTrabajosLA.NumeroEconomico);
                    centralOrdenesTrabajos.FechaInicioReparacion = OrdenesTrabajosLA.FechaInicioReparacion;
                    centralOrdenesTrabajos.ManoObra = Convert.ToDecimal(OrdenesTrabajosLA.ManoObra);
                    centralOrdenesTrabajos.IVAManoObra = Convert.ToDecimal(OrdenesTrabajosLA.IVAManoObra);
                    centralOrdenesTrabajos.Refacciones = Convert.ToDecimal(OrdenesTrabajosLA.Refacciones);
                    centralOrdenesTrabajos.IVARefacciones = Convert.ToDecimal(OrdenesTrabajosLA.IVARefacciones);
                    centralOrdenesTrabajos.FechaFacturacion = OrdenesTrabajosLA.FechaFacturacion;
                    centralOrdenesTrabajos.Kilometraje = OrdenesTrabajosLA.Kilometraje;
                    centralOrdenesTrabajos.Comentarios = OrdenesTrabajosLA.Comentarios;
                    centralOrdenesTrabajos.CostoRefacciones = Convert.ToDecimal(OrdenesTrabajosLA.CostoRefacciones);
                    centralOrdenesTrabajos.CostoManoObra = Convert.ToDecimal(OrdenesTrabajosLA.CostoManoObra);
                    centralOrdenesTrabajos.CargoAConductor = Convert.ToBoolean(AppHelper.IsNull(OrdenesTrabajosLA.CargoCond, false));
                    centralOrdenesTrabajos.CB = OrdenesTrabajosLA.CB;
                    centralOrdenesTrabajos.CB_Activo = Convert.ToBoolean(AppHelper.IsNull(OrdenesTrabajosLA.CB_Activo, false));


                    if (Central.DB.Exists("OrdenesTrabajos", Param("OrdenTrabajo_ID", centralOrdenesTrabajos.OrdenTrabajo_ID)))
                    {
                        centralOrdenesTrabajos.Update();
                    }
                    else
                    {
                        centralOrdenesTrabajos.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado OrdenTrabajo_ID: {0}", centralOrdenesTrabajos.OrdenTrabajo_ID));
                }

                //List<LA.Entities.OrdenesTrabajo> ordenestrabajosLA = LA.Entities.OrdenesTrabajo.Read();
                //foreach (LA.Entities.OrdenesTrabajo OrdenesTrabajosLA in ordenestrabajosLA)
                //{                    
                //}	//	End foreach

            }	//	End Method SyncOrdenesTrabajos

            public void SyncRefacciones(int folioinicial)
            {
                string filter = "(Folio IN " +
                    "(SELECT Refaccion FROM Compras) " +
                    "OR Folio IN " +
                    "(SELECT Refaccion FROM OrdenesServicioRefacciones) " +
                    "OR Folio IN (SELECT Refaccion FROM MovimientosDirectosAInventario)) " +
                    "AND Folio > @Folio";

                string sort = "Folio ASC";
                
                LA.Entities.Refacciones RefaccionesLA;
                int folio = folioinicial;

                while (LA.Entities.Refacciones.Read(out RefaccionesLA, 1, filter, sort, Param("Folio", folio)))
                {
                    Central.Entities.Refacciones centralRefacciones = new Central.Entities.Refacciones();
                    folio = RefaccionesLA.Folio;
                    centralRefacciones.Refaccion_ID = RefaccionesLA.Folio;
                    centralRefacciones.TipoRefaccion_ID = RefaccionesLA.Tipo;
                    centralRefacciones.Modelo_ID = RefaccionesLA.Modelo;

                    int marcaRefaccion;
                    if (RefaccionesLA.Marca == null)
                    {
                        if (RefaccionesLA.Inventario.Count != 0)
                        {
                            marcaRefaccion = RefaccionesLA.Inventario[0].Marca;
                        }
                        else
                        {
                            // No tiene marca
                            marcaRefaccion = 1;
                        }
                    }
                    else
                    {
                        marcaRefaccion = Convert.ToInt32(RefaccionesLA.Marca);
                    }

                    centralRefacciones.MarcaRefaccion_ID = marcaRefaccion;
                    centralRefacciones.Anio = RefaccionesLA.Año;
                    centralRefacciones.Pasillo = RefaccionesLA.Pasillo;
                    centralRefacciones.Estante = RefaccionesLA.Estante;
                    centralRefacciones.Nivel = RefaccionesLA.Nivel;
                    centralRefacciones.Seccion = RefaccionesLA.Seccion;
                    centralRefacciones.NumeroSerial = RefaccionesLA.NumeroDeParte;
                    centralRefacciones.Descripcion = RefaccionesLA.Descripcion;
                    centralRefacciones.CostoUnitario = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.Costo, 0));
                    centralRefacciones.PrecioInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioInt, 0));
                    centralRefacciones.PrecioExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioExt, 0));
                    centralRefacciones.MargenInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenInt, 0));
                    centralRefacciones.MargentExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenExt, 0));
                    centralRefacciones.CantidadInventario = 0; // Obtener de inventario
                    centralRefacciones.ValorInventario = 0; // Obtener de inventario
                    centralRefacciones.PuntoDeReOrden = 0; // Obtener de inventario


                    if (Central.DB.Exists("Refacciones", Param("Refaccion_ID", centralRefacciones.Refaccion_ID)))
                    {
                        centralRefacciones.Update();
                    }
                    else
                    {
                        centralRefacciones.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado Refaccion_ID: {0}", centralRefacciones.Refaccion_ID));
                }

            }	//	End Method SyncRefacciones

            public void SyncRefacciones()
            {
                string filter = "(Folio IN " +
                    "(SELECT Refaccion FROM Compras) " +
                    "OR Folio IN " +
                    "(SELECT Refaccion FROM OrdenesServicioRefacciones) " +
                    "OR Folio IN (SELECT Refaccion FROM MovimientosDirectosAInventario)) " +
                    "AND Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Refaccion_ID),0) folio FROM Refacciones";

                LA.Entities.Refacciones RefaccionesLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry));

                while (LA.Entities.Refacciones.Read(out RefaccionesLA, 1, filter, sort, Param("Folio",folio)))
                {
                    Central.Entities.Refacciones centralRefacciones = new Central.Entities.Refacciones();
                    folio = RefaccionesLA.Folio;
                    centralRefacciones.Refaccion_ID = RefaccionesLA.Folio;
                    centralRefacciones.TipoRefaccion_ID = RefaccionesLA.Tipo;
                    centralRefacciones.Modelo_ID = RefaccionesLA.Modelo;
                    
                    int marcaRefaccion;
                    if (RefaccionesLA.Marca == null)
                    {
                        if (RefaccionesLA.Inventario.Count != 0)
                        {
                            marcaRefaccion = RefaccionesLA.Inventario[0].Marca;
                        }
                        else
                        {
                            // No tiene marca
                            marcaRefaccion = 1;
                        }
                    }
                    else
                    {
                        marcaRefaccion = Convert.ToInt32(RefaccionesLA.Marca);
                    }

                    centralRefacciones.MarcaRefaccion_ID = marcaRefaccion;
                    centralRefacciones.Anio = RefaccionesLA.Año;
                    centralRefacciones.Pasillo = RefaccionesLA.Pasillo;
                    centralRefacciones.Estante = RefaccionesLA.Estante;
                    centralRefacciones.Nivel = RefaccionesLA.Nivel;
                    centralRefacciones.Seccion = RefaccionesLA.Seccion;
                    centralRefacciones.NumeroSerial = RefaccionesLA.NumeroDeParte;

                    //  Obtener la descripción a partir las variables
                    centralRefacciones.Descripcion = RefaccionesLA.Descripcion;

                    centralRefacciones.CostoUnitario = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.Costo, 0));
                    centralRefacciones.PrecioInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioInt, 0));
                    centralRefacciones.PrecioExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioExt, 0));
                    centralRefacciones.MargenInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenInt, 0));
                    centralRefacciones.MargentExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenExt, 0));

                    string sqlstr = "SELECT	SUM(Cantidad) Cantidad FROM Inventario WHERE	Refaccion = @Refaccion";
                    int cantidadInventario = Convert.ToInt32(LA.DB.QueryScalar(sqlstr, Param("@Refaccion", RefaccionesLA.Folio)));
                    centralRefacciones.CantidadInventario = cantidadInventario; 

                    sqlstr = "SELECT	SUM(Costo) Costo FROM Inventario WHERE	Refaccion = @Refaccion";
                    decimal valorInventario = Convert.ToDecimal(LA.DB.QueryScalar(sqlstr, Param("@Refaccion", RefaccionesLA.Folio)));
                    centralRefacciones.ValorInventario = valorInventario;

                    centralRefacciones.PuntoDeReOrden = cantidadInventario;


                    if (Central.DB.Exists("Refacciones", Param("Refaccion_ID", centralRefacciones.Refaccion_ID)))
                    {
                        centralRefacciones.Update();
                    }
                    else
                    {
                        centralRefacciones.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado Refaccion_ID: {0}", centralRefacciones.Refaccion_ID));
                }

            }	//	End Method SyncRefacciones

            public void SyncRefaccionesPre()
            {
                string filter = "Folio IN " +
                    "(SELECT Refaccion FROM Compras) " +
                    "AND Folio IN " +
                    "(SELECT Refaccion FROM OrdenesServicioRefacciones)";

                List<LA.Entities.Refacciones> refaccionesLA = LA.Entities.Refacciones.Read(filter, "");
                foreach (LA.Entities.Refacciones RefaccionesLA in refaccionesLA)
                {
                    Central.Entities.Refacciones centralRefacciones = new Central.Entities.Refacciones();
                    centralRefacciones.Refaccion_ID = RefaccionesLA.Folio;
                    centralRefacciones.TipoRefaccion_ID = RefaccionesLA.Tipo;
                    centralRefacciones.Modelo_ID = RefaccionesLA.Modelo;
                    centralRefacciones.MarcaRefaccion_ID = Convert.ToInt32(AppHelper.IsNull(RefaccionesLA.Marca, RefaccionesLA.Inventario[0].Marca));
                    centralRefacciones.Anio = RefaccionesLA.Año;
                    centralRefacciones.Pasillo = RefaccionesLA.Pasillo;
                    centralRefacciones.Estante = RefaccionesLA.Estante;
                    centralRefacciones.Nivel = RefaccionesLA.Nivel;
                    centralRefacciones.Seccion = RefaccionesLA.Seccion;
                    centralRefacciones.NumeroSerial = RefaccionesLA.NumeroDeParte;
                    centralRefacciones.Descripcion = RefaccionesLA.Descripcion;
                    centralRefacciones.CostoUnitario = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.Costo, 0));
                    centralRefacciones.PrecioInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioInt, 0));
                    centralRefacciones.PrecioExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.PrecioExt, 0));
                    centralRefacciones.MargenInterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenInt, 0));
                    centralRefacciones.MargentExterno = Convert.ToDecimal(AppHelper.IsNull(RefaccionesLA.MargenExt, 0));
                    centralRefacciones.CantidadInventario = 0; // Obtener de inventario
                    centralRefacciones.ValorInventario = 0; // Obtener de inventario
                    centralRefacciones.PuntoDeReOrden = 0; // Obtener de inventario


                    if (Central.DB.Exists("Refacciones", Param("Refaccion_ID", centralRefacciones.Refaccion_ID)))
                    {
                        centralRefacciones.Update();
                    }
                    else
                    {
                        centralRefacciones.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado Refaccion_ID: {0}", centralRefacciones.Refaccion_ID));
                }	//	End foreach

            }	//	End Method SyncRefacciones

            public void SyncServiciosMantenimientos()
            {
                //  Ajustar con read
                List<LA.Entities.Servicios> serviciosmantenimientosLA = LA.Entities.Servicios.Read();
                foreach (LA.Entities.Servicios ServiciosMantenimientosLA in serviciosmantenimientosLA)
                {
                    Central.Entities.ServiciosMantenimientos centralServiciosMantenimientos = new Central.Entities.ServiciosMantenimientos();
                    centralServiciosMantenimientos.ServicioMantenimiento_ID = ServiciosMantenimientosLA.Folio;
                    centralServiciosMantenimientos.TipoServicioMantenimiento_ID = 1; // Posteriormente se ajustará
                    centralServiciosMantenimientos.Familia_ID = (ServiciosMantenimientosLA.Familia == 0) ? 1 : ServiciosMantenimientosLA.Familia;
                    centralServiciosMantenimientos.Modelo_ID = 1; // Posteriormente se ajustará
                    centralServiciosMantenimientos.Nombre = ServiciosMantenimientosLA.Descripcion;
                    centralServiciosMantenimientos.TiempoAplicado = 0;
                    centralServiciosMantenimientos.CostoManoObraAreaMinuto = 0;
                    centralServiciosMantenimientos.PrecioMinuto = 0;
                    centralServiciosMantenimientos.Costo = 0;
                    centralServiciosMantenimientos.Precio = 0;
                    centralServiciosMantenimientos.PorcentajeUtilidad = 0;
                    centralServiciosMantenimientos.CuotaManoObra = 0;

                    if (Central.DB.Exists("ServiciosMantenimientos", Param("ServicioMantenimiento_ID", centralServiciosMantenimientos.ServicioMantenimiento_ID)))
                    {
                        centralServiciosMantenimientos.Update();
                    }
                    else
                    {
                        centralServiciosMantenimientos.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado ServicioMantenimiento_ID: {0}", centralServiciosMantenimientos.ServicioMantenimiento_ID));

                }	//	End foreach

            }	//	End Method SyncServiciosMantenimientos

            public void SyncServiciosMantenimientos_TiposRefacciones()
            {
                //  Ajustar con read
                List<LA.Entities.ServiciosTiposRefacciones> serviciosmantenimientos_tiposrefaccionesLA = LA.Entities.ServiciosTiposRefacciones.Read();
                foreach (LA.Entities.ServiciosTiposRefacciones ServiciosMantenimientos_TiposRefaccionesLA in serviciosmantenimientos_tiposrefaccionesLA)
                {
                    Central.Entities.ServiciosMantenimientos_TiposRefacciones centralServiciosMantenimientos_TiposRefacciones = new Central.Entities.ServiciosMantenimientos_TiposRefacciones();
                    centralServiciosMantenimientos_TiposRefacciones.ServicioMantenimiento_ID = ServiciosMantenimientos_TiposRefaccionesLA.Servicio;                    
                    centralServiciosMantenimientos_TiposRefacciones.TipoRefaccion_ID = ServiciosMantenimientos_TiposRefaccionesLA.TipoRefaccion;
                    centralServiciosMantenimientos_TiposRefacciones.Cantidad = ServiciosMantenimientos_TiposRefaccionesLA.Cantidad;

                    if (Central.DB.Exists("ServiciosMantenimientos_TiposRefacciones", 
                            Param("ServicioMantenimiento_ID", centralServiciosMantenimientos_TiposRefacciones.ServicioMantenimiento_ID),
                                Param("TipoRefaccion_ID", centralServiciosMantenimientos_TiposRefacciones.TipoRefaccion_ID)))
                    {
                        centralServiciosMantenimientos_TiposRefacciones.Update();
                    }
                    else
                    {
                        centralServiciosMantenimientos_TiposRefacciones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Servicio: {0} TipoRefaccion: {1}", 
                        centralServiciosMantenimientos_TiposRefacciones.ServicioMantenimiento_ID, centralServiciosMantenimientos_TiposRefacciones.TipoRefaccion_ID));
                }	//	End foreach

            }	//	End Method SyncServiciosMantenimientos_TiposRefacciones

            public void SyncSesiones()
            {
                string filter = "Sesion > @Sesion";

                string sort = "Sesion ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Sesiones WHERE Estacion_ID = @Estacion";

                LA.Entities.ControlCajas SesionesLA;
                int sesion;

                sesion = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.ControlCajas.Read(out SesionesLA, 1, filter, sort, Param("Sesion", sesion)))
                {
                    sesion = SesionesLA.Sesion;

                    Central.Entities.Sesiones centralSesiones = new Central.Entities.Sesiones();
                    centralSesiones.Sesion_ID = SesionesLA.Sesion;
                    centralSesiones.Empresa_ID = Empresa; // CAM
                    centralSesiones.Estacion_ID = Estacion; // LA

                    centralSesiones.Caja_ID = 
                        Central.Entities.Cajas.Read(Param("Referencia_ID", SesionesLA.Caja), Param("Estacion_ID", Estacion)).Caja_ID;
                    LA.Entities.MovimientosCaja mc = LA.Entities.MovimientosCaja.Read(Param("Sesion", SesionesLA.Sesion));

                    centralSesiones.Usuario_ID = (mc == null) ? "SICAS" : mc.Usuario;
                    
                    centralSesiones.FechaInicial = SesionesLA.Inicio;
                    centralSesiones.FechaFinal = SesionesLA.Corte;
                    centralSesiones.HostName = null;
                    centralSesiones.IPAddress = null;
                    centralSesiones.MACAddress = null;
                    centralSesiones.Activo = (SesionesLA.Corte == null) ? true : false;
                    centralSesiones.Referencia_ID = sesion;

                    if (Central.DB.Exists("Sesiones", Param("Sesion_ID", centralSesiones.Sesion_ID)))
                    {
                        centralSesiones.Update();
                    }
                    else
                    {
                        centralSesiones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Sesion_ID: {0}", centralSesiones.Sesion_ID));
                }

            }	//	End Method SyncSesiones

            public void SyncTickets()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Tickets WHERE Estacion_ID = @Estacion";

                LA.Entities.Recibos TicketsLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.Recibos.Read(out TicketsLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = TicketsLA.Folio;

                    Central.Entities.Tickets centralTickets = new Central.Entities.Tickets();
                    
                    centralTickets.Ticket_ID = 0;
                    centralTickets.Referencia_ID = folio;

                    //  Consultar la sesión por usuario y fecha
                    int sesionlocal = LA.Entities.ControlCajas.GetBy(TicketsLA.Fecha, TicketsLA.Caja).Sesion;
                    int sesion_id = Central.Entities.Sesiones.Read(Param("Referencia_ID", sesionlocal), Param("Estacion_ID", Estacion)).Sesion_ID;
                    centralTickets.Sesion_ID = sesion_id;

                    centralTickets.Caja_ID =
                        Central.Entities.Cajas.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", TicketsLA.Caja)).Caja_ID;
                    centralTickets.Usuario_ID = TicketsLA.UsuarioAlta;

                    //  Si existe en cancelados
                    if (LA.DB.Exists("RecibosCancelados", Param("Estacion", Estacion), Param("Recibo", TicketsLA.Folio)))
                    {
                        centralTickets.EstatusTicket_ID = 2;
                    }
                    else
                    {
                        centralTickets.EstatusTicket_ID = 1;
                    }
                    
                    centralTickets.Empresa_ID = Empresa; // CAM
                    centralTickets.Estacion_ID = Estacion; // LA

                    if (TicketsLA.Unidad == 0)
                    {
                        centralTickets.Unidad_ID = null;
                    }
                    else
                    {
                        centralTickets.Unidad_ID =
                        Central.Entities.Unidades.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", TicketsLA.Unidad)).Unidad_ID;
                    }

                    centralTickets.Conductor_ID =
                        Central.Entities.Conductores.Read(Param("Estacion_ID", Estacion), Param("Referencia_ID", TicketsLA.Conductor)).Conductor_ID;


                    centralTickets.Fecha = TicketsLA.Fecha;

                    if (Central.DB.Exists("Tickets", Param("Ticket_ID", centralTickets.Ticket_ID)))
                    {
                        centralTickets.Update();
                    }
                    else
                    {
                        centralTickets.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Ticket_ID: {0}", folio));
                }
            }	//	End Method SyncTickets

            public void SyncTicketsCancelados()
            {
                //  Ajustar con read
                List<LA.Entities.RecibosCancelados> ticketscanceladosLA = LA.Entities.RecibosCancelados.Read();
                foreach (LA.Entities.RecibosCancelados TicketsCanceladosLA in ticketscanceladosLA)
                {
                    Central.Entities.TicketsCancelados centralTicketsCancelados = new Central.Entities.TicketsCancelados();

                    Central.Entities.Tickets ticket = Central.Entities.Tickets.Read(Param("Referencia_ID",TicketsCanceladosLA.Recibo), Param("Estacion_ID", Estacion));
                    if(ticket == null)
                    {
                        // Ticket no existe
                        continue;
                    }
                    centralTicketsCancelados.Ticket_ID = ticket.Ticket_ID;
                    centralTicketsCancelados.Motivo = TicketsCanceladosLA.Motivo;
                    centralTicketsCancelados.Usuario_ID = TicketsCanceladosLA.Usuario;
                    centralTicketsCancelados.Fecha = Convert.ToDateTime(TicketsCanceladosLA.Fecha);


                    if (Central.DB.Exists("TicketsCancelados", Param("Ticket_ID", centralTicketsCancelados.Ticket_ID)))
                    {
                        centralTicketsCancelados.Update();
                    }
                    else
                    {
                        centralTicketsCancelados.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Ticket_ID (Cancelacion): {0}", centralTicketsCancelados.Ticket_ID));
                }	//	End foreach

            }	//	End Method SyncTicketsCancelados

            public void SyncTiposRefacciones()
            {
                //  Ajustar con read
                List<LA.Entities.TiposRefacciones> tiposrefaccionesLA 
                    = LA.Entities.TiposRefacciones.Read();
                foreach (LA.Entities.TiposRefacciones TiposRefaccionesLA in tiposrefaccionesLA)
                {
                    Central.Entities.TiposRefacciones centralTiposRefacciones = new Central.Entities.TiposRefacciones();
                    centralTiposRefacciones.TipoRefaccion_ID = TiposRefaccionesLA.Folio;
                    centralTiposRefacciones.Familia_ID = TiposRefaccionesLA.Familia;
                    centralTiposRefacciones.Nombre = TiposRefaccionesLA.Descripcion;


                    if (Central.DB.Exists("TiposRefacciones", Param("TipoRefaccion_ID", centralTiposRefacciones.TipoRefaccion_ID)))
                    {
                        //  Compara
                        //  Si difiere
                        //  Actualiza
                        centralTiposRefacciones.Update();
                    }
                    else
                    {
                        centralTiposRefacciones.Create(true);
                    }

                    Console.WriteLine(String.Format("Registro actualizado TipoRefaccion_ID: {0}", centralTiposRefacciones.TipoRefaccion_ID));

                }	//	End foreach

            }	//	End Method SyncTiposRefacciones

            public void ImportTiposRefacciones()
            {
                List<LA.Entities.TiposRefacciones> tiposrefaccionesLA = LA.Entities.TiposRefacciones.Read();
                foreach (LA.Entities.TiposRefacciones TiposRefaccionesLA in tiposrefaccionesLA)
                {
                    Central.Entities.TiposRefacciones centralTiposRefacciones = new Central.Entities.TiposRefacciones();
                    centralTiposRefacciones.TipoRefaccion_ID = TiposRefaccionesLA.Folio;
                    centralTiposRefacciones.Familia_ID = TiposRefaccionesLA.Familia;
                    centralTiposRefacciones.Nombre = TiposRefaccionesLA.Descripcion;

                    centralTiposRefacciones.Create(true);

                    Console.WriteLine(String.Format("Registro actualizado TipoRefaccion_ID: {0}", centralTiposRefacciones.TipoRefaccion_ID));
                }	//	End foreach

            }	//	End Method SyncTiposRefacciones

            private int LocacionCentral(int locacionlocal)
            {
                int locacion = 0;
                switch (locacionlocal)
                {
                    case 1: locacion = 3; break;
                    case 2: locacion = 15; break;
                    case 3: locacion = 13; break;
                    case 4: locacion = 12; break;
                    case 5: locacion = 18; break;
                    case 6: locacion = 8; break;
                    case 7: locacion = 11; break;
                    case 8: locacion = 4; break;
                    case 9: locacion = 10; break;
                    case 10: locacion = 2; break;
                    case 11: locacion = 14; break;
                    case 12: locacion = 22; break;
                    case 13: locacion = 5; break;
                    case 14: locacion = 17; break;
                    case 15: locacion = 20; break;
                    case 16: locacion = 16; break;
                    case 17: locacion = 10; break;
                    case 18: locacion = 19; break;
                    case 19: locacion = 1; break;
                    case 20: locacion = 7; break;
                    case 21: locacion = 6; break;
                    case 22: locacion = 21; break;
                    case 23: locacion = 3; break;
                    case 24: locacion = 3; break;
                    case 25: locacion = 3; break;
                }

                return locacion;
            }

            public void SyncUnidadesInit()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Unidades WHERE Estacion_ID = @Estacion";

                LA.Entities.Unidades UnidadesLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));
                folio = 0;
                while (LA.Entities.Unidades.Read(out UnidadesLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = UnidadesLA.Folio;

                    Central.Entities.Unidades centralUnidades = new Central.Entities.Unidades();
                    centralUnidades.Unidad_ID = UnidadesLA.Folio;
                    centralUnidades.Empresa_ID = Empresa; // CAM
                    centralUnidades.Estacion_ID = Estacion; // LA
                    centralUnidades.NumeroEconomico = UnidadesLA.NumeroEconomico;

                    int modelounidad_id = Central.Entities.ModelosUnidades.Read(Param("referencia_id", UnidadesLA.Modelo), Param("EmpresaReferencia", Empresa)).ModeloUnidad_ID;
                    centralUnidades.ModeloUnidad_ID = modelounidad_id; // A consultar

                    centralUnidades.PrecioLista = UnidadesLA.PrecioLista;
                    centralUnidades.NumeroSerie = UnidadesLA.NumeroSerie;
                    centralUnidades.NumeroSerieMotor = UnidadesLA.NumeroSerieMotor;
                    centralUnidades.TarjetaCirculacion = UnidadesLA.TarjetaCirculacion;

                    centralUnidades.EstatusUnidad_ID = UnidadesLA.Status;
                    centralUnidades.LocacionUnidad_ID = LocacionCentral(UnidadesLA.Locacion);

                    centralUnidades.Placas = (UnidadesLA.Concesion == null) ? "" : UnidadesLA.Concesion.Placa;

                    centralUnidades.Kilometraje = 0; // Consultar de registro // Actualizar despues de importación

                    centralUnidades.Propietario_ID = 1; // Casco
                    centralUnidades.Arrendamiento_ID = null; // No entra control de arrendamientos, // Debe ser nulo

                    if (UnidadesLA.Concesion == null)
                    {
                        centralUnidades.Concesion_ID = null;
                    }
                    else
                    {
                        Central.Entities.Concesiones concesion = Central.Entities.Concesiones.Read(Param("EstacionReferencia_ID", Estacion), Param("Referencia_ID", UnidadesLA.Concesion.Folio));
                        if (concesion == null)
                        {
                            centralUnidades.Concesion_ID = null;
                        }
                        else
                        {
                            centralUnidades.Concesion_ID = concesion.Concesion_ID; // Obtener de concesiones
                        }
                    }

                    centralUnidades.Referencia_ID = UnidadesLA.Folio;


                    if (Central.DB.Exists("Unidades", Param("Unidad_ID", centralUnidades.Unidad_ID)))
                    {
                        centralUnidades.Update();
                    }
                    else
                    {
                        centralUnidades.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_ID: {0}", centralUnidades.Unidad_ID));
                }
            }	//	End Method SyncUnidades


            public void SyncUnidades()
            {
                string filter = "Folio > @Folio";

                string sort = "Folio ASC";

                string sqlQry = "SELECT ISNULL(MAX(Referencia_ID),0) folio FROM Unidades WHERE Estacion_ID = @Estacion";

                LA.Entities.Unidades UnidadesLA;
                int folio;

                folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.Unidades.Read(out UnidadesLA, 1, filter, sort, Param("Folio", folio)))
                {
                    folio = UnidadesLA.Folio;

                    Central.Entities.Unidades centralUnidades = new Central.Entities.Unidades();
                    centralUnidades.Unidad_ID = UnidadesLA.Folio;
                    centralUnidades.Empresa_ID = Empresa; // CAM
                    centralUnidades.Estacion_ID = Estacion; // LA
                    centralUnidades.NumeroEconomico = UnidadesLA.NumeroEconomico;

                    int modelounidad_id = Central.Entities.ModelosUnidades.Read(Param("referencia_id", UnidadesLA.Modelo), Param("EmpresaReferencia", Empresa)).ModeloUnidad_ID;
                    centralUnidades.ModeloUnidad_ID = modelounidad_id; // A consultar

                    centralUnidades.PrecioLista = UnidadesLA.PrecioLista;
                    centralUnidades.NumeroSerie = UnidadesLA.NumeroSerie;
                    centralUnidades.NumeroSerieMotor = UnidadesLA.NumeroSerieMotor;
                    centralUnidades.TarjetaCirculacion = UnidadesLA.TarjetaCirculacion;
                    
                    centralUnidades.EstatusUnidad_ID = UnidadesLA.Status;
                    centralUnidades.LocacionUnidad_ID = LocacionCentral(UnidadesLA.Locacion);
                    
                    centralUnidades.Placas = (UnidadesLA.Concesion==null) ? "" : UnidadesLA.Concesion.Placa; 

                    centralUnidades.Kilometraje = 0; // Consultar de registro // Actualizar despues de importación

                    centralUnidades.Propietario_ID = 1; // Casco
                    centralUnidades.Arrendamiento_ID = null; // No entra control de arrendamientos, // Debe ser nulo

                    if (UnidadesLA.Concesion == null)
                    {
                        centralUnidades.Concesion_ID = null;
                    }
                    else
                    {
                        Central.Entities.Concesiones concesion = Central.Entities.Concesiones.Read(Param("EstacionReferencia_ID", Estacion), Param("Referencia_ID", UnidadesLA.Concesion.Folio));
                        if (concesion == null)
                        {
                            centralUnidades.Concesion_ID = null;
                        }
                        else
                        {
                            centralUnidades.Concesion_ID = concesion.Concesion_ID; // Obtener de concesiones
                        }                        
                    }                    

                    centralUnidades.Referencia_ID = UnidadesLA.Folio;


                    if (Central.DB.Exists("Unidades", Param("Unidad_ID", centralUnidades.Unidad_ID)))
                    {
                        centralUnidades.Update();
                    }
                    else
                    {
                        centralUnidades.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_ID: {0}", centralUnidades.Unidad_ID));
                }
            }	//	End Method SyncUnidades

            public void SyncUnidades_Kilometrajes()
            {
                string filter = "Fecha > @Fecha";

                string sort = "Fecha ASC";

                string sqlQry = "SELECT ISNULL(MAX(UK.Fecha),0) Fecha FROM Unidades_Kilometrajes UK " +
                    "INNER JOIN Unidades U ON UK.Unidad_ID = U.Unidad_ID WHERE U.Estacion_ID = @Estacion";

                LA.Entities.RegistroKilometrajesUnidades Unidades_KilometrajesLA;
                DateTime fecha;

                fecha = Convert.ToDateTime(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.RegistroKilometrajesUnidades.Read(out Unidades_KilometrajesLA, 1, filter, sort, Param("Fecha", fecha)))
                {
                    fecha = Unidades_KilometrajesLA.Fecha;

                    Central.Entities.Unidades_Kilometrajes centralUnidades_Kilometrajes = new Central.Entities.Unidades_Kilometrajes();

                    centralUnidades_Kilometrajes.Unidad_Kilometraje_ID = 0; // A determinar

                    centralUnidades_Kilometrajes.Unidad_ID =
                        Central.Entities.Unidades.Read(Param("Estacion_ID", this.Estacion), Param("Referencia_ID", Unidades_KilometrajesLA.Unidad)).Unidad_ID;
                    centralUnidades_Kilometrajes.Conductor_ID =
                        Central.Entities.Conductores.Read(Param("Estacion_ID", Estacion), Param("Referencia_ID", Unidades_KilometrajesLA.ConductorActual)).Conductor_ID;

                    centralUnidades_Kilometrajes.Kilometraje = Unidades_KilometrajesLA.Kilometraje;
                    centralUnidades_Kilometrajes.Fecha = Unidades_KilometrajesLA.Fecha;

                    if (Central.DB.Exists("Unidades_Kilometrajes", Param("Unidad_Kilometraje_ID", centralUnidades_Kilometrajes.Unidad_Kilometraje_ID)))
                    {
                        centralUnidades_Kilometrajes.Update();
                    }
                    else
                    {
                        centralUnidades_Kilometrajes.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_Kilometraje_ID: {0}", centralUnidades_Kilometrajes.Unidad_Kilometraje_ID));
                }
            }	//	End Method SyncUnidades_Kilometrajes

            //  Unidades Locaciones
            public void SyncUnidades_Locaciones()
            {
                string filter = "Fecha > @Fecha";

                string sort = "Fecha ASC";

                string sqlQry = "SELECT ISNULL(MAX(Fecha),0) UL.Fecha FROM Unidades_Locaciones UL " +
                    "INNER JOIN Unidades U ON UL.Unidad_ID = U.Unidad_ID WHERE U.Estacion_ID = @Estacion";

                LA.Entities.RegistroLocacionesUnidades Unidades_LocacionesLA;
                DateTime fecha;

                fecha = Convert.ToDateTime(Central.DB.QueryScalar(sqlQry, Central.DB.GetParams(Param("@Estacion", Estacion))));

                while (LA.Entities.RegistroLocacionesUnidades.Read(out Unidades_LocacionesLA, 1, filter, sort, Param("Fecha", fecha)))
                {
                    fecha = Unidades_LocacionesLA.Fecha;

                    Central.Entities.Unidades_Locaciones centralUnidades_Locaciones = new Central.Entities.Unidades_Locaciones();
                    centralUnidades_Locaciones.Unidad_Locacion_ID = 0; // Por determinar

                    centralUnidades_Locaciones.Unidad_ID = Unidades_LocacionesLA.Unidad; // A consultar
                    centralUnidades_Locaciones.LocacionUnidad_ID = LocacionCentral(Unidades_LocacionesLA.Locacion); // A consultar
                    
                    centralUnidades_Locaciones.Fecha = Unidades_LocacionesLA.Fecha;


                    if (Central.DB.Exists("Unidades_Locaciones", Param("Unidad_Locacion_ID", centralUnidades_Locaciones.Unidad_Locacion_ID)))
                    {
                        centralUnidades_Locaciones.Update();
                    }
                    else
                    {
                        centralUnidades_Locaciones.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado Unidad_Locacion_ID: {0}", centralUnidades_Locaciones.Unidad_Locacion_ID));
                }              

            }	//	End Method SyncUnidades_Locaciones

            //  ValesPrepagados
            public void SyncValesPrepagados()
            {
                string filter = "Codigo > @Codigo";

                string sort = "Codigo ASC";

                string sqlQry = "SELECT ISNULL(MAX(ValePrepagado_ID),'') ValePrepagado_ID FROM ValesPrepagados";

                LA.Entities.ValesPrepagados ValesPrepagadosLA;
                string vale;

                vale = Convert.ToString(Central.DB.QueryScalar(sqlQry));

                while (LA.Entities.ValesPrepagados.Read(out ValesPrepagadosLA, 1, filter, sort, Param("@Codigo", vale)))
                {
                    vale = ValesPrepagadosLA.Codigo;

                    Central.Entities.ValesPrepagados centralValesPrepagados = new Central.Entities.ValesPrepagados();
                    centralValesPrepagados.ValePrepagado_ID = ValesPrepagadosLA.Codigo;

                    int empresacliente_id = Central.Entities.Empresas.Read(Param("Rfc", ValesPrepagadosLA.Clientes.Rfc))[0].Empresa_ID;
                    centralValesPrepagados.EmpresaCliente_ID = empresacliente_id;

                    centralValesPrepagados.Usuario_ID = ValesPrepagadosLA.UsuarioEmision;
                    centralValesPrepagados.EstatusValePrepagado_ID = ValesPrepagadosLA.Status;
                    centralValesPrepagados.FolioDiario = ValesPrepagadosLA.FolioDiario;
                    centralValesPrepagados.Denominacion = ValesPrepagadosLA.Denominacion;
                    centralValesPrepagados.FechaEmision = ValesPrepagadosLA.FechaEmision;
                    centralValesPrepagados.FechaExpiracion = ValesPrepagadosLA.FechaExpiracion;

                    //  Se obtiene del recibo
                    if (ValesPrepagadosLA.RecibosValesPrepagados != null)
                    {
                        centralValesPrepagados.Ticket_ID = ValesPrepagadosLA.Recibos.Folio;
                        centralValesPrepagados.FechaCanje = ValesPrepagadosLA.Recibos.Fecha;
                    }
                    else
                    {
                        centralValesPrepagados.Ticket_ID = null;
                        centralValesPrepagados.FechaCanje = null;
                    }

                    if (Central.DB.Exists("ValesPrepagados", Param("ValePrepagado_ID", centralValesPrepagados.ValePrepagado_ID)))
                    {
                        centralValesPrepagados.Update();
                    }
                    else
                    {
                        centralValesPrepagados.Create();
                    }

                    Console.WriteLine(String.Format("Registro actualizado vales: {0}", centralValesPrepagados.ValePrepagado_ID));
                
                } // End While

            }	//	End Method SyncValesPrepagados

            private decimal DenominacionPlanillas(decimal precio)
            {
                decimal denominacion = 0;
                switch ((int)precio)
                {
                    case 1: denominacion = 10; break;
                    case 5: denominacion = 50; break;
                }

                return denominacion;
            }

            //  Planillas Fiscales
            public void SyncPlanillasFiscales()
            {                
                IEnumerable<int> estaciones = LA.DB.QueryList<int>("SELECT DISTINCT Estacion FROM PlanillasFiscales", "Estacion");

                foreach (int estacion in estaciones)
                {
                    IEnumerable<string> series = 
                        LA.DB.QueryList<string>("SELECT DISTINCT Serie FROM PlanillasFiscales WHERE Estacion = " + estacion.ToString(), "Serie");

                    foreach (string serie in series)
                    {
                        //  Obtener el ultimo folio de planilla fiscal para dicha estación y serie
                        //  Ejecutar el read
                        string filter = "Estacion = @Estacion AND Serie = @Serie AND Folio > @Folio";
                        string sort = "Folio ASC";
                        string sqlQry = "SELECT ISNULL(MAX(Folio),0) Folio FROM PlanillasFiscales WHERE Estacion_ID = @Estacion_ID AND Serie = @Serie";

                        LA.Entities.PlanillasFiscales PlanillasFiscalesLA;
                        int folio = Convert.ToInt32(Central.DB.QueryScalar(sqlQry, LA.DB.GetParams(Param("@Estacion_ID", estacion),Param("@Serie",serie))));

                        while (LA.Entities.PlanillasFiscales.Read(out PlanillasFiscalesLA, 1, filter, sort, 
                            Param("@Estacion", estacion),Param("@Serie",serie), Param("@Folio", folio)))
                        {
                            Central.Entities.PlanillasFiscales centralPlanillasFiscales = new Central.Entities.PlanillasFiscales();
                            folio = PlanillasFiscalesLA.Folio;                            

                            if (PlanillasFiscalesLA.RecibosPlanillas == null)
                            {
                                centralPlanillasFiscales.Ticket_ID = null;
                            }
                            else
                            {
                                centralPlanillasFiscales.Ticket_ID =
                                    Central.Entities.Tickets.Read(
                                        Param("Referencia_ID", PlanillasFiscalesLA.RecibosPlanillas.Recibo),
                                            Param("Estacion_ID", Estacion)).Ticket_ID;
                            }

                            //  Mediante funcion
                            centralPlanillasFiscales.Denominacion = DenominacionPlanillas(PlanillasFiscalesLA.Precio);
                            centralPlanillasFiscales.Estacion_ID = estacion; // LA
                            centralPlanillasFiscales.EstatusPlanillaFiscal_ID = PlanillasFiscalesLA.Status;
                            centralPlanillasFiscales.Serie = serie;
                            centralPlanillasFiscales.Folio = folio;
                            centralPlanillasFiscales.Precio = PlanillasFiscalesLA.Precio;
                            centralPlanillasFiscales.Fecha = PlanillasFiscalesLA.FechaAlta;


                            if (Central.DB.Exists("PlanillasFiscales", Param("Estacion_ID", estacion),
                                Param("Serie", serie), Param("Folio", folio)))
                            {
                                centralPlanillasFiscales.Update();
                            }
                            else
                            {
                                centralPlanillasFiscales.Create();
                            }

                            Console.WriteLine(String.Format("Registro actualizado planillas: {0}", centralPlanillasFiscales.Folio));
                        }
                    }
                }

            }	//	End Method SyncPlanillasFiscales
        }   //  End Class        

    }   //  End Class

}   //  End Namespace