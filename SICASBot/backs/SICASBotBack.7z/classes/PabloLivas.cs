﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace SICASBot.PabloLivas
{
    public class DB
    {
        public static string connStr = "Data Source=cascola.dyndns.org;Initial Catalog=SICAS;Persist Security Info=True;User ID=SICASusr;Password=nhtccuag";
        private static SqlConnection conn;

        public static KeyValuePair<string, object> Param(string key, object value)
        {
            return new KeyValuePair<string, object>(key, value);
        }

        private static object Test()
        {
            return Read("tabla x", Param("", ""), Param("", ""));
        }

        public static DataTable Read(string tableName, params KeyValuePair<string, object>[] args)
        {
            Hashtable data = new Hashtable();
            foreach (KeyValuePair<string, object> kp in args)
            {
                data.Add(kp.Key, kp.Value);
            }
            return Select(tableName, data);
        }

        public static object Ident_Current(string tableName)
        {
            string sqlstr = String.Format("SELECT IDENT_CURRENT('{0}');", tableName);
            return QueryScalar(sqlstr);
        }

        public static DateTime GetDate()
        {
            string sqlstr = "SELECT GETDATE()";
            return (DateTime)QueryScalar(sqlstr);
        }

        public static object QueryScalar(string sqlQry, params KeyValuePair<string, object>[] @params)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            try
            {
                object result;
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = sqlQry;
                command.Parameters.Clear();

                foreach (KeyValuePair<string, object> kvp in @params)
                {
                    command.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }

                result = command.ExecuteScalar();
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static object QueryScalar

        public static object QueryScalar(string sqlQry, Hashtable @params)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            try
            {
                object result;
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = sqlQry;
                command.Parameters.Clear();
                foreach (string k in @params.Keys)
                {
                    command.Parameters.AddWithValue(k, @params[k]);
                }
                result = command.ExecuteScalar();
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static object QueryScalar

        public static object QueryScalar(string sqlQry)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            try
            {
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = sqlQry;

                Object Result = command.ExecuteScalar();
                return Result;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static object QueryScalar

        public static DataTable Query(string query)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);

            try
            {
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = query;

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(ds, "SICASDATA");

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static DataTable Query


        public static DataTable QueryCommand(string m_command, Hashtable m_params)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);

            try
            {
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = m_command;
                command.Parameters.Clear();

                foreach (string key in m_params.Keys)
                {
                    if (m_params[key] == null)
                    {
                        command.Parameters.AddWithValue(key, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue(key, m_params[key]);
                    }
                }

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(ds, "SICASDATA");

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static DataTable QueryCommand

        public static void ExecuteQuery(string execQuery)
        {
            SqlCommand command;
            conn = new SqlConnection(connStr);
            try
            {
                if (conn.State == ConnectionState.Closed) { conn.Open(); }

                command = new SqlCommand(execQuery, conn);
                command.CommandType = CommandType.Text;
                command.CommandText = execQuery;
                command.ExecuteNonQuery();
                command.Dispose();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        } // public static void ExecuteQuery

        public static void ExecuteCommand(string execQuery, Hashtable m_params)
        {
            SqlCommand command;
            conn = new SqlConnection(connStr);
            try
            {
                if (conn.State == ConnectionState.Closed) { conn.Open(); }

                command = new SqlCommand(execQuery, conn);
                command.CommandType = CommandType.Text;
                command.CommandText = execQuery;
                command.Parameters.Clear();

                foreach (string key in m_params.Keys)
                {
                    command.Parameters.AddWithValue(key, m_params[key]);
                }
                command.ExecuteNonQuery();
                command.Dispose();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
        } // public static void ExecuteCommand

        #region DBHelpers

        public static int InsertRow(string strTabla, Hashtable @params)
        {
            string strSQL = "INSERT INTO " + strTabla + " (";
            int cont = 0;
            foreach (string k in @params.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k;
                }
                else
                {
                    strSQL += "," + k;
                }
                cont += 1;
            }

            strSQL += ") VALUES (";
            cont = 0;

            foreach (string k in @params.Keys)
            {
                if (cont == 0)
                {
                    strSQL += "@" + k;
                }
                else
                {
                    strSQL += ", @" + k;
                }
                cont += 1;
            }

            strSQL += ")";

            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);

            command.Connection.Open();
            command.Parameters.Clear();
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            foreach (string k in @params.Keys)
            {
                if (@params[k] == null)
                {
                    command.Parameters.AddWithValue("@" + k, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@" + k, @params[k]);
                }
            }

            try
            {
                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static int InsertRow

        public static DataTable Select(string tablename)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);

            try
            {
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = "SELECT * FROM " + tablename;
                command.Parameters.Clear();

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(ds, "SICASDATA");

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        }

        public static DataTable Select(string tablename, Hashtable w_params)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);

            try
            {
                command.Connection.Open();
                command.CommandType = CommandType.Text;
                command.CommandText = SelectStatement(tablename, w_params);
                command.Parameters.Clear();

                foreach (string key in w_params.Keys)
                {
                    command.Parameters.AddWithValue(key, w_params[key]);
                }

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(ds, "SICASDATA");

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        }

        public static string SelectStatement(string strTabla, Hashtable @params, Hashtable @whereParams)
        {
            int cont;
            string strSQL = "";
            strSQL += "SELECT ";
            cont = 0;

            foreach (string k in @params.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k;
                }
                else
                {
                    strSQL += ", " + k;
                }
                cont += 1;
            }

            cont = 0;
            strSQL += " FROM " + strTabla + " WHERE ";
            foreach (string k in @whereParams.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += " AND " + k + " = @" + k;
                }
                cont += 1;
            }

            return strSQL;
        } // End SelectStatement

        public static string SelectStatement(string strTabla, Hashtable @whereParams)
        {
            int cont;
            string strSQL = "";
            strSQL += "SELECT * FROM " + strTabla + " WHERE ";
            cont = 0;

            foreach (string k in @whereParams.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += " AND " + k + " = @" + k;
                }
                cont += 1;
            }

            return strSQL;
        } // End SelectStatement

        public static int DeleteRow(string strTabla, Hashtable @whereParams)
        {
            string strSQL = "DELETE FROM " + strTabla + " ";
            int cont = 0;

            strSQL += " WHERE ";

            foreach (string k in @whereParams.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += " AND " + k + " = @" + k;
                }
                cont += 1;
            }

            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            command.Connection.Open();
            command.Parameters.Clear();
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            foreach (string k in @whereParams.Keys)
            {
                if (@whereParams[k] == null)
                {
                    command.Parameters.AddWithValue("@" + k, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@" + k, @whereParams[k]);
                }
            }

            try
            {
                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // public static int DeleteRow

        public static int UpdateRow(string strTabla, Hashtable @params)
        {
            string strSQL = "UPDATE " + strTabla + " SET ";
            int cont = 0;
            foreach (string k in @params.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += ", " + k + " = @" + k;
                }
                cont += 1;
            }

            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            command.Connection.Open();
            command.Parameters.Clear();
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            foreach (string k in @params.Keys)
            {
                if (@params[k] == null)
                {
                    command.Parameters.AddWithValue("@" + k, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@" + k, @params[k]);
                }
            }

            try
            {
                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // int UpdateRow


        public static int UpdateRow(string strTabla, Hashtable @params, Hashtable @whereParams)
        {

            string strSQL = "UPDATE " + strTabla + " SET ";
            int cont = 0;
            foreach (string k in @params.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += ", " + k + " = @" + k;
                }
                cont += 1;
            }

            strSQL += " WHERE ";
            cont = 0;

            foreach (string k in @whereParams.Keys)
            {
                if (cont == 0)
                {
                    strSQL += k + " = @" + k;
                }
                else
                {
                    strSQL += " AND " + k + " = @" + k;
                }
                cont += 1;
            }

            SqlCommand command = new SqlCommand();
            command.Connection = new SqlConnection(connStr);
            command.Connection.Open();
            command.Parameters.Clear();
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            foreach (string k in @params.Keys)
            {
                if (@params[k] == null)
                {
                    command.Parameters.AddWithValue("@" + k, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@" + k, @params[k]);
                }
            }

            foreach (string k in @whereParams.Keys)
            {
                if (@whereParams[k] == null)
                {
                    command.Parameters.AddWithValue("@" + k, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@" + k, @whereParams[k]);
                }
            }

            try
            {
                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                command.Connection.Close();
                command.Dispose();
            }
        } // int UpdateRow

        #endregion

        #region HasthToStr
        public static string GetStrHash(Hashtable m_params)
        {
            string result = "";
            foreach (string k in m_params.Keys)
            {
                if (result == "")
                {
                    result += k + ":    " + m_params[k];
                }
                else
                {
                    result += "\r\n" + k + ":    " + m_params[k];
                }

            }
            return result;
        }
        #endregion

        /// <summary>
        /// Regresa un entero nulable a partir de una expresión evaluada
        /// </summary>
        /// <param name="expression">La expresión a evaluar</param>
        /// <returns>int?</returns>
        public static int? GetNullableInt32(object expression)
        {
            if (expression == null || Convert.IsDBNull(expression))
            {
                return null;
            }
            else
            {
                if (expression.GetType() == typeof(string))
                {
                    if (string.IsNullOrEmpty((string)expression))
                    {
                        return null;
                    }
                }
                return Convert.ToInt32(expression);
            }
        }

        public static DateTime? GetNullableDateTime(object expression)
        {
            if (expression == null || Convert.IsDBNull(expression))
            {
                return null;
            }
            else
            {
                if (expression.GetType() == typeof(string))
                {
                    if (string.IsNullOrEmpty((string)expression))
                    {
                        return null;
                    }
                }
                return Convert.ToDateTime(expression);
            }
        }

        public static decimal? GetNullableDecimal(object expression)
        {
            if (expression == null || Convert.IsDBNull(expression))
            {
                return null;
            }
            else
            {
                if (expression.GetType() == typeof(string))
                {
                    if (string.IsNullOrEmpty((string)expression))
                    {
                        return null;
                    }
                }
                return Convert.ToDecimal(expression);
            }
        }

        public static Boolean? GetNullableBoolean(object expression)
        {
            if (expression == null || Convert.IsDBNull(expression))
            {
                return null;
            }
            else
            {
                if (expression.GetType() == typeof(string))
                {
                    if (string.IsNullOrEmpty((string)expression))
                    {
                        return null;
                    }
                }
                return Convert.ToBoolean(expression);
            }
        }

        public static Char? GetNullableChar(object expression)
        {
            if (expression == null || Convert.IsDBNull(expression))
            {
                return null;
            }
            else
            {
                if (expression.GetType() == typeof(string))
                {
                    if (string.IsNullOrEmpty((string)expression))
                    {
                        return null;
                    }
                }
                return Convert.ToChar(expression);
            }
        }
    } //    DB Class


    namespace Entities
    {

        public class AccionesUsuarios
        {

            public AccionesUsuarios()
            {
            }

            public AccionesUsuarios(string catalogo, string accion, string detalles, DateTime fecha, string usuario)
            {
                this.Catalogo = catalogo;
                this.Accion = accion;
                this.Detalles = detalles;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private string _Catalogo;
            public string Catalogo
            {
                get { return _Catalogo; }
                set { _Catalogo = value; }
            }

            private string _Accion;
            public string Accion
            {
                get { return _Accion; }
                set { _Accion = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Catalogo", this.Catalogo);
                m_params.Add("Accion", this.Accion);
                m_params.Add("Detalles", this.Detalles);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("AccionesUsuarios", m_params);
            } // End Create

            public static List<AccionesUsuarios> Read()
            {
                List<AccionesUsuarios> list = new List<AccionesUsuarios>();
                DataTable dt = DB.Select("AccionesUsuarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new AccionesUsuarios(Convert.ToString(dr["Catalogo"]), Convert.ToString(dr["Accion"]), Convert.ToString(dr["Detalles"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Catalogo", this.Catalogo);
                m_params.Add("Accion", this.Accion);
                m_params.Add("Detalles", this.Detalles);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("AccionesUsuarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("AccionesUsuarios", w_params);
            } // End Delete

        } //End Class AccionesUsuarios

        public class AjustesKm
        {

            public AjustesKm()
            {
            }

            public AjustesKm(int folio, int unidad, int kilometraje, string motivo, DateTime fecha, string usuario)
            {
                this.Folio = folio;
                this.Unidad = unidad;
                this.Kilometraje = kilometraje;
                this.Motivo = motivo;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Kilometraje;
            public int Kilometraje
            {
                get { return _Kilometraje; }
                set { _Kilometraje = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Kilometraje", this.Kilometraje);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("AjustesKm", m_params);
            } // End Create

            public static List<AjustesKm> Read()
            {
                List<AjustesKm> list = new List<AjustesKm>();
                DataTable dt = DB.Select("AjustesKm");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new AjustesKm(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Kilometraje"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Kilometraje", this.Kilometraje);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("AjustesKm", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("AjustesKm", w_params);
            } // End Delete

        } //End Class AjustesKm

        public class Arrendadoras
        {

            public Arrendadoras()
            {
            }

            public Arrendadoras(int folio, string descripcion, string razonsocial, string rfc, string direccion, string codigopostal, string telefono, string contacto, string correoelectronico, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.RazonSocial = razonsocial;
                this.RFC = rfc;
                this.Direccion = direccion;
                this.CodigoPostal = codigopostal;
                this.Telefono = telefono;
                this.Contacto = contacto;
                this.CorreoElectronico = correoelectronico;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _RFC;
            public string RFC
            {
                get { return _RFC; }
                set { _RFC = value; }
            }

            private string _Direccion;
            public string Direccion
            {
                get { return _Direccion; }
                set { _Direccion = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _Contacto;
            public string Contacto
            {
                get { return _Contacto; }
                set { _Contacto = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("Arrendadoras", m_params);
            } // End Create

            public static List<Arrendadoras> Read()
            {
                List<Arrendadoras> list = new List<Arrendadoras>();
                DataTable dt = DB.Select("Arrendadoras");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Arrendadoras(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static Arrendadoras Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Arrendadoras", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Arrendadoras con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Arrendadoras(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("Arrendadoras", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Arrendadoras", w_params);
            } // End Delete

        } //End Class Arrendadoras

        public class Aseguradoras
        {

            public Aseguradoras()
            {
            }

            public Aseguradoras(int folio, string razonsocial, string calle, string numero, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, string sitioweb, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.RazonSocial = razonsocial;
                this.Calle = calle;
                this.Numero = numero;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.SitioWeb = sitioweb;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _Numero;
            public string Numero
            {
                get { return _Numero; }
                set { _Numero = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _SitioWeb;
            public string SitioWeb
            {
                get { return _SitioWeb; }
                set { _SitioWeb = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                if (!AppHelper.IsNullOrEmpty(this.SitioWeb)) m_params.Add("SitioWeb", this.SitioWeb);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Aseguradoras", m_params);
            } // End Create

            public static List<Aseguradoras> Read()
            {
                List<Aseguradoras> list = new List<Aseguradoras>();
                DataTable dt = DB.Select("Aseguradoras");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Aseguradoras(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["SitioWeb"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                if (!AppHelper.IsNullOrEmpty(this.SitioWeb)) m_params.Add("SitioWeb", this.SitioWeb);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Aseguradoras", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Aseguradoras", w_params);
            } // End Delete

        } //End Class Aseguradoras

        public class Auditoria
        {

            public Auditoria()
            {
            }

            public Auditoria(int folio, string catalago, string accion, string usuario, string detalles, DateTime? fecha)
            {
                this.Folio = folio;
                this.Catalago = catalago;
                this.Accion = accion;
                this.Usuario = usuario;
                this.Detalles = detalles;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Catalago;
            public string Catalago
            {
                get { return _Catalago; }
                set { _Catalago = value; }
            }

            private string _Accion;
            public string Accion
            {
                get { return _Accion; }
                set { _Accion = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Catalago)) m_params.Add("Catalago", this.Catalago);
                if (!AppHelper.IsNullOrEmpty(this.Accion)) m_params.Add("Accion", this.Accion);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("Auditoria", m_params);
            } // End Create

            public static List<Auditoria> Read()
            {
                List<Auditoria> list = new List<Auditoria>();
                DataTable dt = DB.Select("Auditoria");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Auditoria(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Catalago"]), Convert.ToString(dr["Accion"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Detalles"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static Auditoria Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Auditoria", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Auditoria con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Auditoria(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Catalago"]), Convert.ToString(dr["Accion"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Detalles"]), DB.GetNullableDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Catalago)) m_params.Add("Catalago", this.Catalago);
                if (!AppHelper.IsNullOrEmpty(this.Accion)) m_params.Add("Accion", this.Accion);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("Auditoria", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Auditoria", w_params);
            } // End Delete

        } //End Class Auditoria

        public class Avales
        {

            public Avales()
            {
            }

            public Avales(int folio, int conductor, string rfc, string apellidopaterno, string apellidomaterno, string nombre, string curp, string calle, string numerocasa, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Rfc = rfc;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Nombre = nombre;
                this.Curp = curp;
                this.Calle = calle;
                this.NumeroCasa = numerocasa;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _NumeroCasa;
            public string NumeroCasa
            {
                get { return _NumeroCasa; }
                set { _NumeroCasa = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Avales", m_params);
            } // End Create

            public static List<Avales> Read()
            {
                List<Avales> list = new List<Avales>();
                DataTable dt = DB.Select("Avales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Avales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Avales Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Avales", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Avales con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Avales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Avales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Avales", w_params);
            } // End Delete

        } //End Class Avales

        public class BajasConductores
        {

            public BajasConductores()
            {
            }

            public BajasConductores(int folio, int conductor, int unidad, int motivo, string comentarios, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Motivo = motivo;
                this.Comentarios = comentarios;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Motivo;
            public int Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("BajasConductores", m_params);
            } // End Create

            public static List<BajasConductores> Read()
            {
                List<BajasConductores> list = new List<BajasConductores>();
                DataTable dt = DB.Select("BajasConductores");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new BajasConductores(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Motivo"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static BajasConductores Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("BajasConductores", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe BajasConductores con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new BajasConductores(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Motivo"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("BajasConductores", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("BajasConductores", w_params);
            } // End Delete

        } //End Class BajasConductores

        public class BeneficiosParaPlanes
        {

            public BeneficiosParaPlanes()
            {
            }

            public BeneficiosParaPlanes(int folio, string descripcion, string condiciones, DateTime fechaalra, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Condiciones = condiciones;
                this.FechaAlra = fechaalra;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _Condiciones;
            public string Condiciones
            {
                get { return _Condiciones; }
                set { _Condiciones = value; }
            }

            private DateTime _FechaAlra;
            public DateTime FechaAlra
            {
                get { return _FechaAlra; }
                set { _FechaAlra = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Condiciones", this.Condiciones);
                m_params.Add("FechaAlra", this.FechaAlra);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("BeneficiosParaPlanes", m_params);
            } // End Create

            public static List<BeneficiosParaPlanes> Read()
            {
                List<BeneficiosParaPlanes> list = new List<BeneficiosParaPlanes>();
                DataTable dt = DB.Select("BeneficiosParaPlanes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new BeneficiosParaPlanes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Condiciones"]), Convert.ToDateTime(dr["FechaAlra"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static BeneficiosParaPlanes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("BeneficiosParaPlanes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe BeneficiosParaPlanes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new BeneficiosParaPlanes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Condiciones"]), Convert.ToDateTime(dr["FechaAlra"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Condiciones", this.Condiciones);
                m_params.Add("FechaAlra", this.FechaAlra);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("BeneficiosParaPlanes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("BeneficiosParaPlanes", w_params);
            } // End Delete

        } //End Class BeneficiosParaPlanes

        public class Cajas
        {

            public Cajas()
            {
            }

            public Cajas(int folio, int estacion, string descripcion, int status)
            {
                this.Folio = folio;
                this.Estacion = estacion;
                this.Descripcion = descripcion;
                this.Status = status;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("Cajas", m_params);
            } // End Create

            public static List<Cajas> Read()
            {
                List<Cajas> list = new List<Cajas>();
                DataTable dt = DB.Select("Cajas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Cajas(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToString(dr["Descripcion"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("Cajas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Cajas", w_params);
            } // End Delete

        } //End Class Cajas

        public class CambiosFacturaOrdenesCompras
        {

            public CambiosFacturaOrdenesCompras()
            {
            }

            public CambiosFacturaOrdenesCompras(int ordencompra, string factura1, string factura2, string usuario, string motivo, DateTime fecha)
            {
                this.OrdenCompra = ordencompra;
                this.Factura1 = factura1;
                this.Factura2 = factura2;
                this.Usuario = usuario;
                this.Motivo = motivo;
                this.Fecha = fecha;
            }

            private int _OrdenCompra;
            public int OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private string _Factura1;
            public string Factura1
            {
                get { return _Factura1; }
                set { _Factura1 = value; }
            }

            private string _Factura2;
            public string Factura2
            {
                get { return _Factura2; }
                set { _Factura2 = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Factura1", this.Factura1);
                m_params.Add("Factura2", this.Factura2);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("CambiosFacturaOrdenesCompras", m_params);
            } // End Create

            public static List<CambiosFacturaOrdenesCompras> Read()
            {
                List<CambiosFacturaOrdenesCompras> list = new List<CambiosFacturaOrdenesCompras>();
                DataTable dt = DB.Select("CambiosFacturaOrdenesCompras");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CambiosFacturaOrdenesCompras(Convert.ToInt32(dr["OrdenCompra"]), Convert.ToString(dr["Factura1"]), Convert.ToString(dr["Factura2"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Factura1", this.Factura1);
                m_params.Add("Factura2", this.Factura2);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("CambiosFacturaOrdenesCompras", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("CambiosFacturaOrdenesCompras", w_params);
            } // End Delete

        } //End Class CambiosFacturaOrdenesCompras

        public class Catalogos_Consulta_Reporteador
        {

            public Catalogos_Consulta_Reporteador()
            {
            }

            public Catalogos_Consulta_Reporteador(string nombre, string descripcion)
            {
                this.Nombre = nombre;
                this.Descripcion = descripcion;
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Nombre", this.Nombre);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Catalogos_Consulta_Reporteador", m_params);
            } // End Create

            public static List<Catalogos_Consulta_Reporteador> Read()
            {
                List<Catalogos_Consulta_Reporteador> list = new List<Catalogos_Consulta_Reporteador>();
                DataTable dt = DB.Select("Catalogos_Consulta_Reporteador");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Catalogos_Consulta_Reporteador(Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static Catalogos_Consulta_Reporteador Read(string nombre)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Nombre", nombre);
                DataTable dt = DB.Select("Catalogos_Consulta_Reporteador", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Catalogos_Consulta_Reporteador con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Catalogos_Consulta_Reporteador(Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Nombre", this.Nombre);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Catalogos_Consulta_Reporteador", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Nombre", this.Nombre);

                return DB.DeleteRow("Catalogos_Consulta_Reporteador", w_params);
            } // End Delete

        } //End Class Catalogos_Consulta_Reporteador

        public class CategoriasMecanicos
        {

            public CategoriasMecanicos()
            {
            }

            public CategoriasMecanicos(int folio, int familia, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Familia = familia;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Familia;
            public int Familia
            {
                get { return _Familia; }
                set { _Familia = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("CategoriasMecanicos", m_params);
            } // End Create

            public static List<CategoriasMecanicos> Read()
            {
                List<CategoriasMecanicos> list = new List<CategoriasMecanicos>();
                DataTable dt = DB.Select("CategoriasMecanicos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CategoriasMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static CategoriasMecanicos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("CategoriasMecanicos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CategoriasMecanicos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CategoriasMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("CategoriasMecanicos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("CategoriasMecanicos", w_params);
            } // End Delete

        } //End Class CategoriasMecanicos

        public class Causalidades
        {

            public Causalidades()
            {
            }

            public Causalidades(int folio, int conductor, int unidad, int? siniestro, string motivo, DateTime fecha, string usuarioalta, DateTime inicio, DateTime? fin)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Siniestro = siniestro;
                this.Motivo = motivo;
                this.Fecha = fecha;
                this.UsuarioAlta = usuarioalta;
                this.Inicio = inicio;
                this.Fin = fin;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int? _Siniestro;
            public int? Siniestro
            {
                get { return _Siniestro; }
                set { _Siniestro = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private DateTime _Inicio;
            public DateTime Inicio
            {
                get { return _Inicio; }
                set { _Inicio = value; }
            }

            private DateTime? _Fin;
            public DateTime? Fin
            {
                get { return _Fin; }
                set { _Fin = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.Siniestro)) m_params.Add("Siniestro", this.Siniestro);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Fin)) m_params.Add("Fin", this.Fin);

                return DB.InsertRow("Causalidades", m_params);
            } // End Create

            public static List<Causalidades> Read()
            {
                List<Causalidades> list = new List<Causalidades>();
                DataTable dt = DB.Select("Causalidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Causalidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), DB.GetNullableInt32(dr["Siniestro"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Fin"])));
                }

                return list;
            } // End Read

            public static Causalidades Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Causalidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Causalidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Causalidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), DB.GetNullableInt32(dr["Siniestro"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Fin"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.Siniestro)) m_params.Add("Siniestro", this.Siniestro);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Fin)) m_params.Add("Fin", this.Fin);

                return DB.UpdateRow("Causalidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Causalidades", w_params);
            } // End Delete

        } //End Class Causalidades

        public class ClasesClientes
        {

            public ClasesClientes()
            {
            }

            public ClasesClientes(int folio, string descripcion, int? subsistema, bool? permitecredito, int? minnumeco, int? maxnumeco, string nombrecorto, bool? activo, int? tipo)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Subsistema = subsistema;
                this.PermiteCredito = permitecredito;
                this.MinNumEco = minnumeco;
                this.MaxNumEco = maxnumeco;
                this.NombreCorto = nombrecorto;
                this.Activo = activo;
                this.Tipo = tipo;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Subsistema;
            public int? Subsistema
            {
                get { return _Subsistema; }
                set { _Subsistema = value; }
            }

            private bool? _PermiteCredito;
            public bool? PermiteCredito
            {
                get { return _PermiteCredito; }
                set { _PermiteCredito = value; }
            }

            private int? _MinNumEco;
            public int? MinNumEco
            {
                get { return _MinNumEco; }
                set { _MinNumEco = value; }
            }

            private int? _MaxNumEco;
            public int? MaxNumEco
            {
                get { return _MaxNumEco; }
                set { _MaxNumEco = value; }
            }

            private string _NombreCorto;
            public string NombreCorto
            {
                get { return _NombreCorto; }
                set { _NombreCorto = value; }
            }

            private bool? _Activo;
            public bool? Activo
            {
                get { return _Activo; }
                set { _Activo = value; }
            }

            private int? _Tipo;
            public int? Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Subsistema)) m_params.Add("Subsistema", this.Subsistema);
                if (!AppHelper.IsNullOrEmpty(this.PermiteCredito)) m_params.Add("PermiteCredito", this.PermiteCredito);
                if (!AppHelper.IsNullOrEmpty(this.MinNumEco)) m_params.Add("MinNumEco", this.MinNumEco);
                if (!AppHelper.IsNullOrEmpty(this.MaxNumEco)) m_params.Add("MaxNumEco", this.MaxNumEco);
                if (!AppHelper.IsNullOrEmpty(this.NombreCorto)) m_params.Add("NombreCorto", this.NombreCorto);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);

                return DB.InsertRow("ClasesClientes", m_params);
            } // End Create

            public static List<ClasesClientes> Read()
            {
                List<ClasesClientes> list = new List<ClasesClientes>();
                DataTable dt = DB.Select("ClasesClientes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ClasesClientes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Subsistema"]), DB.GetNullableBoolean(dr["PermiteCredito"]), DB.GetNullableInt32(dr["MinNumEco"]), DB.GetNullableInt32(dr["MaxNumEco"]), Convert.ToString(dr["NombreCorto"]), DB.GetNullableBoolean(dr["Activo"]), DB.GetNullableInt32(dr["Tipo"])));
                }

                return list;
            } // End Read

            public static ClasesClientes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ClasesClientes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ClasesClientes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ClasesClientes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Subsistema"]), DB.GetNullableBoolean(dr["PermiteCredito"]), DB.GetNullableInt32(dr["MinNumEco"]), DB.GetNullableInt32(dr["MaxNumEco"]), Convert.ToString(dr["NombreCorto"]), DB.GetNullableBoolean(dr["Activo"]), DB.GetNullableInt32(dr["Tipo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Subsistema)) m_params.Add("Subsistema", this.Subsistema);
                if (!AppHelper.IsNullOrEmpty(this.PermiteCredito)) m_params.Add("PermiteCredito", this.PermiteCredito);
                if (!AppHelper.IsNullOrEmpty(this.MinNumEco)) m_params.Add("MinNumEco", this.MinNumEco);
                if (!AppHelper.IsNullOrEmpty(this.MaxNumEco)) m_params.Add("MaxNumEco", this.MaxNumEco);
                if (!AppHelper.IsNullOrEmpty(this.NombreCorto)) m_params.Add("NombreCorto", this.NombreCorto);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);

                return DB.UpdateRow("ClasesClientes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ClasesClientes", w_params);
            } // End Delete

        } //End Class ClasesClientes

        public class ClasesConceptos
        {

            public ClasesConceptos()
            {
            }

            public ClasesConceptos(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("ClasesConceptos", m_params);
            } // End Create

            public static List<ClasesConceptos> Read()
            {
                List<ClasesConceptos> list = new List<ClasesConceptos>();
                DataTable dt = DB.Select("ClasesConceptos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ClasesConceptos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static ClasesConceptos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ClasesConceptos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ClasesConceptos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ClasesConceptos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("ClasesConceptos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ClasesConceptos", w_params);
            } // End Delete

        } //End Class ClasesConceptos

        public class ClasesPublicidad
        {

            public ClasesPublicidad()
            {
            }

            public ClasesPublicidad(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("ClasesPublicidad", m_params);
            } // End Create

            public static List<ClasesPublicidad> Read()
            {
                List<ClasesPublicidad> list = new List<ClasesPublicidad>();
                DataTable dt = DB.Select("ClasesPublicidad");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ClasesPublicidad(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static ClasesPublicidad Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ClasesPublicidad", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ClasesPublicidad con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ClasesPublicidad(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("ClasesPublicidad", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ClasesPublicidad", w_params);
            } // End Delete

        } //End Class ClasesPublicidad

        public class Clientes
        {

            public Clientes()
            {
            }

            public Clientes(int folio, string rfc, string razonsocial, string curp, string calle, string numerocasa, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, int status, DateTime fechaalta, string usuarioalta, int personafiscal)
            {
                this.Folio = folio;
                this.Rfc = rfc;
                this.RazonSocial = razonsocial;
                this.Curp = curp;
                this.Calle = calle;
                this.NumeroCasa = numerocasa;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.PersonaFiscal = personafiscal;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _NumeroCasa;
            public string NumeroCasa
            {
                get { return _NumeroCasa; }
                set { _NumeroCasa = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int _PersonaFiscal;
            public int PersonaFiscal
            {
                get { return _PersonaFiscal; }
                set { _PersonaFiscal = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("PersonaFiscal", this.PersonaFiscal);

                return DB.InsertRow("Clientes", m_params);
            } // End Create

            public static List<Clientes> Read()
            {
                List<Clientes> list = new List<Clientes>();
                DataTable dt = DB.Select("Clientes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Clientes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToInt32(dr["PersonaFiscal"])));
                }

                return list;
            } // End Read

            public static Clientes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Clientes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Clientes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Clientes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToInt32(dr["PersonaFiscal"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("PersonaFiscal", this.PersonaFiscal);

                return DB.UpdateRow("Clientes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Clientes", w_params);
            } // End Delete

        } //End Class Clientes

        public class ClientesTaller
        {

            public ClientesTaller()
            {
            }

            public ClientesTaller(int folio, int tipo, int referencia, string rfc, string apellidopaterno, string apellidomaterno, string nombre, string calle, string numero, string colonia, string ciudad, string estado, string pais, string codigopostal, string telefonos, int status, int unidad, int numeroeconomico, int modelo, string placas, DateTime fechaalta, string usuarioalta, int? tipocontrato)
            {
                this.Folio = folio;
                this.Tipo = tipo;
                this.Referencia = referencia;
                this.Rfc = rfc;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Nombre = nombre;
                this.Calle = calle;
                this.Numero = numero;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CodigoPostal = codigopostal;
                this.Telefonos = telefonos;
                this.Status = status;
                this.Unidad = unidad;
                this.NumeroEconomico = numeroeconomico;
                this.Modelo = modelo;
                this.Placas = placas;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.TipoContrato = tipocontrato;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Referencia;
            public int Referencia
            {
                get { return _Referencia; }
                set { _Referencia = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _Numero;
            public string Numero
            {
                get { return _Numero; }
                set { _Numero = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefonos;
            public string Telefonos
            {
                get { return _Telefonos; }
                set { _Telefonos = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _NumeroEconomico;
            public int NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            private int _Modelo;
            public int Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private string _Placas;
            public string Placas
            {
                get { return _Placas; }
                set { _Placas = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _TipoContrato;
            public int? TipoContrato
            {
                get { return _TipoContrato; }
                set { _TipoContrato = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("Status", this.Status);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("Modelo", this.Modelo);
                m_params.Add("Placas", this.Placas);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.TipoContrato)) m_params.Add("TipoContrato", this.TipoContrato);

                return DB.InsertRow("ClientesTaller", m_params);
            } // End Create

            public static List<ClientesTaller> Read()
            {
                List<ClientesTaller> list = new List<ClientesTaller>();
                DataTable dt = DB.Select("ClientesTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Referencia"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToInt32(dr["Status"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["Modelo"]), Convert.ToString(dr["Placas"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["TipoContrato"])));
                }

                return list;
            } // End Read

            public static ClientesTaller Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ClientesTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ClientesTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Referencia"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToInt32(dr["Status"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["Modelo"]), Convert.ToString(dr["Placas"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["TipoContrato"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("Status", this.Status);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("Modelo", this.Modelo);
                m_params.Add("Placas", this.Placas);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.TipoContrato)) m_params.Add("TipoContrato", this.TipoContrato);

                return DB.UpdateRow("ClientesTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ClientesTaller", w_params);
            } // End Delete

        } //End Class ClientesTaller

        public class CoberturasSeguros
        {

            public CoberturasSeguros()
            {
            }

            public CoberturasSeguros(int folio, string descripcion, string detalles, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Detalles = detalles;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("CoberturasSeguros", m_params);
            } // End Create

            public static List<CoberturasSeguros> Read()
            {
                List<CoberturasSeguros> list = new List<CoberturasSeguros>();
                DataTable dt = DB.Select("CoberturasSeguros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CoberturasSeguros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static CoberturasSeguros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("CoberturasSeguros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CoberturasSeguros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CoberturasSeguros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("CoberturasSeguros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("CoberturasSeguros", w_params);
            } // End Delete

        } //End Class CoberturasSeguros

        public class ComisionesDestajoTaller
        {

            public ComisionesDestajoTaller()
            {
            }

            public ComisionesDestajoTaller(int categoria, decimal papees, decimal papsse, decimal papces, decimal pmo, decimal ppd, string usuario, DateTime? fecha)
            {
                this.Categoria = categoria;
                this.PAPEES = papees;
                this.PAPSSE = papsse;
                this.PAPCES = papces;
                this.PMO = pmo;
                this.PPD = ppd;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Categoria;
            public int Categoria
            {
                get { return _Categoria; }
                set { _Categoria = value; }
            }

            private decimal _PAPEES;
            public decimal PAPEES
            {
                get { return _PAPEES; }
                set { _PAPEES = value; }
            }

            private decimal _PAPSSE;
            public decimal PAPSSE
            {
                get { return _PAPSSE; }
                set { _PAPSSE = value; }
            }

            private decimal _PAPCES;
            public decimal PAPCES
            {
                get { return _PAPCES; }
                set { _PAPCES = value; }
            }

            private decimal _PMO;
            public decimal PMO
            {
                get { return _PMO; }
                set { _PMO = value; }
            }

            private decimal _PPD;
            public decimal PPD
            {
                get { return _PPD; }
                set { _PPD = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Categoria", this.Categoria);
                m_params.Add("PAPEES", this.PAPEES);
                m_params.Add("PAPSSE", this.PAPSSE);
                m_params.Add("PAPCES", this.PAPCES);
                m_params.Add("PMO", this.PMO);
                m_params.Add("PPD", this.PPD);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("ComisionesDestajoTaller", m_params);
            } // End Create

            public static List<ComisionesDestajoTaller> Read()
            {
                List<ComisionesDestajoTaller> list = new List<ComisionesDestajoTaller>();
                DataTable dt = DB.Select("ComisionesDestajoTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ComisionesDestajoTaller(Convert.ToInt32(dr["Categoria"]), Convert.ToDecimal(dr["PAPEES"]), Convert.ToDecimal(dr["PAPSSE"]), Convert.ToDecimal(dr["PAPCES"]), Convert.ToDecimal(dr["PMO"]), Convert.ToDecimal(dr["PPD"]), Convert.ToString(dr["Usuario"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static ComisionesDestajoTaller Read(int categoria)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Categoria", categoria);
                DataTable dt = DB.Select("ComisionesDestajoTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ComisionesDestajoTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ComisionesDestajoTaller(Convert.ToInt32(dr["Categoria"]), Convert.ToDecimal(dr["PAPEES"]), Convert.ToDecimal(dr["PAPSSE"]), Convert.ToDecimal(dr["PAPCES"]), Convert.ToDecimal(dr["PMO"]), Convert.ToDecimal(dr["PPD"]), Convert.ToString(dr["Usuario"]), DB.GetNullableDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Categoria", this.Categoria);
                m_params.Add("PAPEES", this.PAPEES);
                m_params.Add("PAPSSE", this.PAPSSE);
                m_params.Add("PAPCES", this.PAPCES);
                m_params.Add("PMO", this.PMO);
                m_params.Add("PPD", this.PPD);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("ComisionesDestajoTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Categoria", this.Categoria);

                return DB.DeleteRow("ComisionesDestajoTaller", w_params);
            } // End Delete

        } //End Class ComisionesDestajoTaller

        public class ComisionesServiciosTaller
        {

            public ComisionesServiciosTaller()
            {
            }

            public ComisionesServiciosTaller(decimal? eficienciaefectiva, decimal? sineficiencia, DateTime? fecha, string usuario)
            {
                this.EficienciaEfectiva = eficienciaefectiva;
                this.SinEficiencia = sineficiencia;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private decimal? _EficienciaEfectiva;
            public decimal? EficienciaEfectiva
            {
                get { return _EficienciaEfectiva; }
                set { _EficienciaEfectiva = value; }
            }

            private decimal? _SinEficiencia;
            public decimal? SinEficiencia
            {
                get { return _SinEficiencia; }
                set { _SinEficiencia = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.EficienciaEfectiva)) m_params.Add("EficienciaEfectiva", this.EficienciaEfectiva);
                if (!AppHelper.IsNullOrEmpty(this.SinEficiencia)) m_params.Add("SinEficiencia", this.SinEficiencia);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("ComisionesServiciosTaller", m_params);
            } // End Create

            public static List<ComisionesServiciosTaller> Read()
            {
                List<ComisionesServiciosTaller> list = new List<ComisionesServiciosTaller>();
                DataTable dt = DB.Select("ComisionesServiciosTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ComisionesServiciosTaller(DB.GetNullableDecimal(dr["EficienciaEfectiva"]), DB.GetNullableDecimal(dr["SinEficiencia"]), DB.GetNullableDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.EficienciaEfectiva)) m_params.Add("EficienciaEfectiva", this.EficienciaEfectiva);
                if (!AppHelper.IsNullOrEmpty(this.SinEficiencia)) m_params.Add("SinEficiencia", this.SinEficiencia);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("ComisionesServiciosTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ComisionesServiciosTaller", w_params);
            } // End Delete

        } //End Class ComisionesServiciosTaller

        public class Compras
        {

            public Compras()
            {
            }

            public Compras(int ordencompra, int refaccion, int marca, decimal costounitario, int cantidad, DateTime fechaalta, string usuarioalta, decimal? refsurtidas)
            {
                this.OrdenCompra = ordencompra;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.CostoUnitario = costounitario;
                this.Cantidad = cantidad;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.RefSurtidas = refsurtidas;
            }

            private int _OrdenCompra;
            public int OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private decimal? _RefSurtidas;
            public decimal? RefSurtidas
            {
                get { return _RefSurtidas; }
                set { _RefSurtidas = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.RefSurtidas)) m_params.Add("RefSurtidas", this.RefSurtidas);

                return DB.InsertRow("Compras", m_params);
            } // End Create

            public static List<Compras> Read()
            {
                List<Compras> list = new List<Compras>();
                DataTable dt = DB.Select("Compras");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Compras(Convert.ToInt32(dr["OrdenCompra"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableDecimal(dr["RefSurtidas"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.RefSurtidas)) m_params.Add("RefSurtidas", this.RefSurtidas);

                return DB.UpdateRow("Compras", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Compras", w_params);
            } // End Delete

        } //End Class Compras

        public class Conceptos
        {

            public Conceptos()
            {
            }

            public Conceptos(int folio, int cuenta, int tipo, string descripcion)
            {
                this.Folio = folio;
                this.Cuenta = cuenta;
                this.Tipo = tipo;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Cuenta;
            public int Cuenta
            {
                get { return _Cuenta; }
                set { _Cuenta = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Cuenta", this.Cuenta);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Conceptos", m_params);
            } // End Create

            public static List<Conceptos> Read()
            {
                List<Conceptos> list = new List<Conceptos>();
                DataTable dt = DB.Select("Conceptos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Conceptos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Cuenta"]), Convert.ToInt32(dr["Tipo"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static Conceptos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Conceptos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Conceptos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Conceptos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Cuenta"]), Convert.ToInt32(dr["Tipo"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Cuenta", this.Cuenta);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Conceptos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Conceptos", w_params);
            } // End Delete

        } //End Class Conceptos

        public class ConceptosDepositosGarantia
        {

            public ConceptosDepositosGarantia()
            {
            }

            public ConceptosDepositosGarantia(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("ConceptosDepositosGarantia", m_params);
            } // End Create

            public static List<ConceptosDepositosGarantia> Read()
            {
                List<ConceptosDepositosGarantia> list = new List<ConceptosDepositosGarantia>();
                DataTable dt = DB.Select("ConceptosDepositosGarantia");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ConceptosDepositosGarantia(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static ConceptosDepositosGarantia Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ConceptosDepositosGarantia", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ConceptosDepositosGarantia con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ConceptosDepositosGarantia(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("ConceptosDepositosGarantia", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ConceptosDepositosGarantia", w_params);
            } // End Delete

        } //End Class ConceptosDepositosGarantia

        public class Concesiones
        {

            public Concesiones()
            {
            }

            public Concesiones(int folio, string placa, int tipo, int status, DateTime fechaalta, string usuarioalta, int? empresaconcesionaria, int? empresaoperativa, string numeroconcesion, int? empresaestacion)
            {
                this.Folio = folio;
                this.Placa = placa;
                this.Tipo = tipo;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.EmpresaConcesionaria = empresaconcesionaria;
                this.EmpresaOperativa = empresaoperativa;
                this.NumeroConcesion = numeroconcesion;
                this.EmpresaEstacion = empresaestacion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Placa;
            public string Placa
            {
                get { return _Placa; }
                set { _Placa = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _EmpresaConcesionaria;
            public int? EmpresaConcesionaria
            {
                get { return _EmpresaConcesionaria; }
                set { _EmpresaConcesionaria = value; }
            }

            private int? _EmpresaOperativa;
            public int? EmpresaOperativa
            {
                get { return _EmpresaOperativa; }
                set { _EmpresaOperativa = value; }
            }

            private string _NumeroConcesion;
            public string NumeroConcesion
            {
                get { return _NumeroConcesion; }
                set { _NumeroConcesion = value; }
            }

            private int? _EmpresaEstacion;
            public int? EmpresaEstacion
            {
                get { return _EmpresaEstacion; }
                set { _EmpresaEstacion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Placa", this.Placa);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaConcesionaria)) m_params.Add("EmpresaConcesionaria", this.EmpresaConcesionaria);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaOperativa)) m_params.Add("EmpresaOperativa", this.EmpresaOperativa);
                if (!AppHelper.IsNullOrEmpty(this.NumeroConcesion)) m_params.Add("NumeroConcesion", this.NumeroConcesion);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaEstacion)) m_params.Add("EmpresaEstacion", this.EmpresaEstacion);

                return DB.InsertRow("Concesiones", m_params);
            } // End Create

            public static List<Concesiones> Read()
            {
                List<Concesiones> list = new List<Concesiones>();
                DataTable dt = DB.Select("Concesiones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Concesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Placa"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["EmpresaConcesionaria"]), DB.GetNullableInt32(dr["EmpresaOperativa"]), Convert.ToString(dr["NumeroConcesion"]), DB.GetNullableInt32(dr["EmpresaEstacion"])));
                }

                return list;
            } // End Read

            public static Concesiones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Concesiones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Concesiones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Concesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Placa"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["EmpresaConcesionaria"]), DB.GetNullableInt32(dr["EmpresaOperativa"]), Convert.ToString(dr["NumeroConcesion"]), DB.GetNullableInt32(dr["EmpresaEstacion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Placa", this.Placa);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaConcesionaria)) m_params.Add("EmpresaConcesionaria", this.EmpresaConcesionaria);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaOperativa)) m_params.Add("EmpresaOperativa", this.EmpresaOperativa);
                if (!AppHelper.IsNullOrEmpty(this.NumeroConcesion)) m_params.Add("NumeroConcesion", this.NumeroConcesion);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaEstacion)) m_params.Add("EmpresaEstacion", this.EmpresaEstacion);

                return DB.UpdateRow("Concesiones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Concesiones", w_params);
            } // End Delete

        } //End Class Concesiones

        public class ConcesionesUnidades
        {

            public ConcesionesUnidades()
            {
            }

            public ConcesionesUnidades(int concesion, int unidad, DateTime fecha, string usuario, Guid claveconsecion)
            {
                this.Concesion = concesion;
                this.Unidad = unidad;
                this.Fecha = fecha;
                this.Usuario = usuario;
                this.ClaveConsecion = claveconsecion;
            }

            private int _Concesion;
            public int Concesion
            {
                get { return _Concesion; }
                set { _Concesion = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private Guid _ClaveConsecion;
            public Guid ClaveConsecion
            {
                get { return _ClaveConsecion; }
                set { _ClaveConsecion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Concesion", this.Concesion);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("ClaveConsecion", this.ClaveConsecion);

                return DB.InsertRow("ConcesionesUnidades", m_params);
            } // End Create

            public static List<ConcesionesUnidades> Read()
            {
                List<ConcesionesUnidades> list = new List<ConcesionesUnidades>();
                DataTable dt = DB.Select("ConcesionesUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ConcesionesUnidades(Convert.ToInt32(dr["Concesion"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), new Guid(Convert.ToString(dr["ClaveConsecion"]))));
                }

                return list;
            } // End Read

            public static ConcesionesUnidades Read(int concesion, int unidad)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Concesion", concesion);
                w_params.Add("Unidad", unidad);
                DataTable dt = DB.Select("ConcesionesUnidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ConcesionesUnidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ConcesionesUnidades(Convert.ToInt32(dr["Concesion"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDateTime(dr["Fecha"]), 
                            Convert.ToString(dr["Usuario"]), new Guid(Convert.ToString(dr["ClaveConsecion"])));                
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Concesion", this.Concesion);
                w_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("ClaveConsecion", this.ClaveConsecion);

                return DB.UpdateRow("ConcesionesUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Concesion", this.Concesion);
                w_params.Add("Unidad", this.Unidad);

                return DB.DeleteRow("ConcesionesUnidades", w_params);
            } // End Delete

        } //End Class ConcesionesUnidades

        public class Conductores
        {

            public Conductores()
            {
            }

            public Conductores(int folio, int estacion, string rfc, string apellidopaterno, string apellidomaterno, string nombre, string curp, string calle, string numerocasa, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, int status, DateTime fechaalta, string usuarioalta, string fotografia)
            {
                this.Folio = folio;
                this.Estacion = estacion;
                this.Rfc = rfc;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Nombre = nombre;
                this.Curp = curp;
                this.Calle = calle;
                this.NumeroCasa = numerocasa;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.Fotografia = fotografia;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _NumeroCasa;
            public string NumeroCasa
            {
                get { return _NumeroCasa; }
                set { _NumeroCasa = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private string _Fotografia;
            public string Fotografia
            {
                get { return _Fotografia; }
                set { _Fotografia = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Fotografia)) m_params.Add("Fotografia", this.Fotografia);

                return DB.InsertRow("Conductores", m_params);
            } // End Create

            public static List<Conductores> Read()
            {
                List<Conductores> list = new List<Conductores>();
                DataTable dt = DB.Select("Conductores");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Conductores(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Fotografia"])));
                }

                return list;
            } // End Read

            public static Conductores Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Conductores", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Conductores con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Conductores(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Fotografia"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Fotografia)) m_params.Add("Fotografia", this.Fotografia);

                return DB.UpdateRow("Conductores", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Conductores", w_params);
            } // End Delete

        } //End Class Conductores

        public class ConductoresCopia
        {

            public ConductoresCopia()
            {
            }

            public ConductoresCopia(int contrato, string rfc, string apellidopaterno, string apellidomaterno, string nombre, string curp, string calle, string numerocasa, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, DateTime fechaalta, string usuarioalta)
            {
                this.Contrato = contrato;
                this.Contrato = contrato;
                this.Rfc = rfc;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Nombre = nombre;
                this.Curp = curp;
                this.Calle = calle;
                this.NumeroCasa = numerocasa;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Contrato;
            public int Contrato
            {
                get { return _Contrato; }
                set { _Contrato = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _NumeroCasa;
            public string NumeroCasa
            {
                get { return _NumeroCasa; }
                set { _NumeroCasa = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("ConductoresCopia", m_params);
            } // End Create

            public static List<ConductoresCopia> Read()
            {
                List<ConductoresCopia> list = new List<ConductoresCopia>();
                DataTable dt = DB.Select("ConductoresCopia");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ConductoresCopia(Convert.ToInt32(dr["Contrato"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static ConductoresCopia Read(int contrato)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Contrato", contrato);
                DataTable dt = DB.Select("ConductoresCopia", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ConductoresCopia con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ConductoresCopia(Convert.ToInt32(dr["Contrato"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Contrato", this.Contrato);
                w_params.Add("Contrato", this.Contrato);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("ConductoresCopia", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Contrato", this.Contrato);

                return DB.DeleteRow("ConductoresCopia", w_params);
            } // End Delete

        } //End Class ConductoresCopia

        public class ConsesionesInventario
        {

            public ConsesionesInventario()
            {
            }

            public ConsesionesInventario(int ordenconsesion, int refaccion, int marca, decimal costounitario, int cantidad, DateTime fechaalta, string usuarioalta)
            {
                this.OrdenConsesion = ordenconsesion;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.CostoUnitario = costounitario;
                this.Cantidad = cantidad;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _OrdenConsesion;
            public int OrdenConsesion
            {
                get { return _OrdenConsesion; }
                set { _OrdenConsesion = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenConsesion", this.OrdenConsesion);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("ConsesionesInventario", m_params);
            } // End Create

            public static List<ConsesionesInventario> Read()
            {
                List<ConsesionesInventario> list = new List<ConsesionesInventario>();
                DataTable dt = DB.Select("ConsesionesInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ConsesionesInventario(Convert.ToInt32(dr["OrdenConsesion"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenConsesion", this.OrdenConsesion);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("ConsesionesInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ConsesionesInventario", w_params);
            } // End Delete

        } //End Class ConsesionesInventario

        public class Contratos
        {

            public Contratos()
            {
            }

            public Contratos(int folio, int estacion, int conductor, int unidad, int plancobro, int tipo, int status, DateTime fechainicial, DateTime? fechafinal, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Estacion = estacion;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.PlanCobro = plancobro;
                this.Tipo = tipo;
                this.Status = status;
                this.FechaInicial = fechainicial;
                this.FechaFinal = fechafinal;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _PlanCobro;
            public int PlanCobro
            {
                get { return _PlanCobro; }
                set { _PlanCobro = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaInicial;
            public DateTime FechaInicial
            {
                get { return _FechaInicial; }
                set { _FechaInicial = value; }
            }

            private DateTime? _FechaFinal;
            public DateTime? FechaFinal
            {
                get { return _FechaFinal; }
                set { _FechaFinal = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaInicial", this.FechaInicial);
                if (!AppHelper.IsNullOrEmpty(this.FechaFinal)) m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Contratos", m_params);
            } // End Create

            public static List<Contratos> Read()
            {
                List<Contratos> list = new List<Contratos>();
                DataTable dt = DB.Select("Contratos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Contratos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["PlanCobro"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaInicial"]), DB.GetNullableDateTime(dr["FechaFinal"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Contratos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Contratos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Contratos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Contratos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["PlanCobro"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaInicial"]), DB.GetNullableDateTime(dr["FechaFinal"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaInicial", this.FechaInicial);
                if (!AppHelper.IsNullOrEmpty(this.FechaFinal)) m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Contratos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Contratos", w_params);
            } // End Delete

        } //End Class Contratos

        public class ContratosArrendamiento
        {

            public ContratosArrendamiento()
            {
            }

            public ContratosArrendamiento(int folio, int statusfinanciero, int arrendadora, DateTime iniciodecontrato, DateTime findecontrato, decimal rentamensual, decimal valorresidual, decimal tasa, int tipodecredito, string numerodecontrato, string anexo, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.StatusFinanciero = statusfinanciero;
                this.Arrendadora = arrendadora;
                this.InicioDeContrato = iniciodecontrato;
                this.FinDeContrato = findecontrato;
                this.RentaMensual = rentamensual;
                this.ValorResidual = valorresidual;
                this.Tasa = tasa;
                this.TipoDeCredito = tipodecredito;
                this.NumeroDeContrato = numerodecontrato;
                this.Anexo = anexo;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _StatusFinanciero;
            public int StatusFinanciero
            {
                get { return _StatusFinanciero; }
                set { _StatusFinanciero = value; }
            }

            private int _Arrendadora;
            public int Arrendadora
            {
                get { return _Arrendadora; }
                set { _Arrendadora = value; }
            }

            private DateTime _InicioDeContrato;
            public DateTime InicioDeContrato
            {
                get { return _InicioDeContrato; }
                set { _InicioDeContrato = value; }
            }

            private DateTime _FinDeContrato;
            public DateTime FinDeContrato
            {
                get { return _FinDeContrato; }
                set { _FinDeContrato = value; }
            }

            private decimal _RentaMensual;
            public decimal RentaMensual
            {
                get { return _RentaMensual; }
                set { _RentaMensual = value; }
            }

            private decimal _ValorResidual;
            public decimal ValorResidual
            {
                get { return _ValorResidual; }
                set { _ValorResidual = value; }
            }

            private decimal _Tasa;
            public decimal Tasa
            {
                get { return _Tasa; }
                set { _Tasa = value; }
            }

            private int _TipoDeCredito;
            public int TipoDeCredito
            {
                get { return _TipoDeCredito; }
                set { _TipoDeCredito = value; }
            }

            private string _NumeroDeContrato;
            public string NumeroDeContrato
            {
                get { return _NumeroDeContrato; }
                set { _NumeroDeContrato = value; }
            }

            private string _Anexo;
            public string Anexo
            {
                get { return _Anexo; }
                set { _Anexo = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("StatusFinanciero", this.StatusFinanciero);
                m_params.Add("Arrendadora", this.Arrendadora);
                m_params.Add("InicioDeContrato", this.InicioDeContrato);
                m_params.Add("FinDeContrato", this.FinDeContrato);
                m_params.Add("RentaMensual", this.RentaMensual);
                m_params.Add("ValorResidual", this.ValorResidual);
                m_params.Add("Tasa", this.Tasa);
                m_params.Add("TipoDeCredito", this.TipoDeCredito);
                m_params.Add("NumeroDeContrato", this.NumeroDeContrato);
                m_params.Add("Anexo", this.Anexo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("ContratosArrendamiento", m_params);
            } // End Create

            public static List<ContratosArrendamiento> Read()
            {
                List<ContratosArrendamiento> list = new List<ContratosArrendamiento>();
                DataTable dt = DB.Select("ContratosArrendamiento");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ContratosArrendamiento(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["StatusFinanciero"]), Convert.ToInt32(dr["Arrendadora"]), Convert.ToDateTime(dr["InicioDeContrato"]), Convert.ToDateTime(dr["FinDeContrato"]), Convert.ToDecimal(dr["RentaMensual"]), Convert.ToDecimal(dr["ValorResidual"]), Convert.ToDecimal(dr["Tasa"]), Convert.ToInt32(dr["TipoDeCredito"]), Convert.ToString(dr["NumeroDeContrato"]), Convert.ToString(dr["Anexo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static ContratosArrendamiento Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ContratosArrendamiento", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ContratosArrendamiento con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ContratosArrendamiento(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["StatusFinanciero"]), Convert.ToInt32(dr["Arrendadora"]), Convert.ToDateTime(dr["InicioDeContrato"]), Convert.ToDateTime(dr["FinDeContrato"]), Convert.ToDecimal(dr["RentaMensual"]), Convert.ToDecimal(dr["ValorResidual"]), Convert.ToDecimal(dr["Tasa"]), Convert.ToInt32(dr["TipoDeCredito"]), Convert.ToString(dr["NumeroDeContrato"]), Convert.ToString(dr["Anexo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("StatusFinanciero", this.StatusFinanciero);
                m_params.Add("Arrendadora", this.Arrendadora);
                m_params.Add("InicioDeContrato", this.InicioDeContrato);
                m_params.Add("FinDeContrato", this.FinDeContrato);
                m_params.Add("RentaMensual", this.RentaMensual);
                m_params.Add("ValorResidual", this.ValorResidual);
                m_params.Add("Tasa", this.Tasa);
                m_params.Add("TipoDeCredito", this.TipoDeCredito);
                m_params.Add("NumeroDeContrato", this.NumeroDeContrato);
                m_params.Add("Anexo", this.Anexo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("ContratosArrendamiento", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ContratosArrendamiento", w_params);
            } // End Delete

        } //End Class ContratosArrendamiento

        public class ContratosLiquidados
        {

            public ContratosLiquidados()
            {
            }

            public ContratosLiquidados(int folio, int contrato, int conductor, int unidad, int locacionunidad, int statusconductor, int statuscontrato, string comentario, DateTime fecha, string usuario)
            {
                this.Folio = folio;
                this.Contrato = contrato;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.LocacionUnidad = locacionunidad;
                this.StatusConductor = statusconductor;
                this.StatusContrato = statuscontrato;
                this.Comentario = comentario;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Contrato;
            public int Contrato
            {
                get { return _Contrato; }
                set { _Contrato = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _LocacionUnidad;
            public int LocacionUnidad
            {
                get { return _LocacionUnidad; }
                set { _LocacionUnidad = value; }
            }

            private int _StatusConductor;
            public int StatusConductor
            {
                get { return _StatusConductor; }
                set { _StatusConductor = value; }
            }

            private int _StatusContrato;
            public int StatusContrato
            {
                get { return _StatusContrato; }
                set { _StatusContrato = value; }
            }

            private string _Comentario;
            public string Comentario
            {
                get { return _Comentario; }
                set { _Comentario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("LocacionUnidad", this.LocacionUnidad);
                m_params.Add("StatusConductor", this.StatusConductor);
                m_params.Add("StatusContrato", this.StatusContrato);
                m_params.Add("Comentario", this.Comentario);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("ContratosLiquidados", m_params);
            } // End Create

            public static List<ContratosLiquidados> Read()
            {
                List<ContratosLiquidados> list = new List<ContratosLiquidados>();
                DataTable dt = DB.Select("ContratosLiquidados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ContratosLiquidados(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Contrato"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["LocacionUnidad"]), Convert.ToInt32(dr["StatusConductor"]), Convert.ToInt32(dr["StatusContrato"]), Convert.ToString(dr["Comentario"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("LocacionUnidad", this.LocacionUnidad);
                m_params.Add("StatusConductor", this.StatusConductor);
                m_params.Add("StatusContrato", this.StatusContrato);
                m_params.Add("Comentario", this.Comentario);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("ContratosLiquidados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ContratosLiquidados", w_params);
            } // End Delete

        } //End Class ContratosLiquidados

        public class ControlAsistencia
        {

            public ControlAsistencia()
            {
            }

            public ControlAsistencia(int folio, int mecanico, char fechahabil, DateTime fechareal, int status, string usuario, string comentarios, bool? notificacion, int? segundostranscurridos)
            {
                this.Folio = folio;
                this.Mecanico = mecanico;
                this.FechaHabil = fechahabil;
                this.FechaReal = fechareal;
                this.Status = status;
                this.Usuario = usuario;
                this.Comentarios = comentarios;
                this.Notificacion = notificacion;
                this.SegundosTranscurridos = segundostranscurridos;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            private char _FechaHabil;
            public char FechaHabil
            {
                get { return _FechaHabil; }
                set { _FechaHabil = value; }
            }

            private DateTime _FechaReal;
            public DateTime FechaReal
            {
                get { return _FechaReal; }
                set { _FechaReal = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private bool? _Notificacion;
            public bool? Notificacion
            {
                get { return _Notificacion; }
                set { _Notificacion = value; }
            }

            private int? _SegundosTranscurridos;
            public int? SegundosTranscurridos
            {
                get { return _SegundosTranscurridos; }
                set { _SegundosTranscurridos = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("FechaHabil", this.FechaHabil);
                m_params.Add("FechaReal", this.FechaReal);
                m_params.Add("Status", this.Status);
                m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.Notificacion)) m_params.Add("Notificacion", this.Notificacion);
                if (!AppHelper.IsNullOrEmpty(this.SegundosTranscurridos)) m_params.Add("SegundosTranscurridos", this.SegundosTranscurridos);

                return DB.InsertRow("ControlAsistencia", m_params);
            } // End Create

            public static List<ControlAsistencia> Read()
            {
                List<ControlAsistencia> list = new List<ControlAsistencia>();
                DataTable dt = DB.Select("ControlAsistencia");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlAsistencia(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToChar(dr["FechaHabil"]), Convert.ToDateTime(dr["FechaReal"]), Convert.ToInt32(dr["Status"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableBoolean(dr["Notificacion"]), DB.GetNullableInt32(dr["SegundosTranscurridos"])));
                }

                return list;
            } // End Read

            public static ControlAsistencia Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ControlAsistencia", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlAsistencia con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlAsistencia(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToChar(dr["FechaHabil"]), Convert.ToDateTime(dr["FechaReal"]), Convert.ToInt32(dr["Status"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableBoolean(dr["Notificacion"]), DB.GetNullableInt32(dr["SegundosTranscurridos"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("FechaHabil", this.FechaHabil);
                m_params.Add("FechaReal", this.FechaReal);
                m_params.Add("Status", this.Status);
                m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.Notificacion)) m_params.Add("Notificacion", this.Notificacion);
                if (!AppHelper.IsNullOrEmpty(this.SegundosTranscurridos)) m_params.Add("SegundosTranscurridos", this.SegundosTranscurridos);

                return DB.UpdateRow("ControlAsistencia", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ControlAsistencia", w_params);
            } // End Delete

        } //End Class ControlAsistencia

        public class ControlCajas
        {

            public ControlCajas()
            {
            }

            public ControlCajas(int sesion, char caja, DateTime inicio, DateTime? corte)
            {
                this.Sesion = sesion;
                this.Caja = caja;
                this.Inicio = inicio;
                this.Corte = corte;
            }

            private int _Sesion;
            public int Sesion
            {
                get { return _Sesion; }
                set { _Sesion = value; }
            }

            private char _Caja;
            public char Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private DateTime _Inicio;
            public DateTime Inicio
            {
                get { return _Inicio; }
                set { _Inicio = value; }
            }

            private DateTime? _Corte;
            public DateTime? Corte
            {
                get { return _Corte; }
                set { _Corte = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Caja", this.Caja);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Corte)) m_params.Add("Corte", this.Corte);

                return DB.InsertRow("ControlCajas", m_params);
            } // End Create

            public static List<ControlCajas> Read()
            {
                List<ControlCajas> list = new List<ControlCajas>();
                DataTable dt = DB.Select("ControlCajas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlCajas(Convert.ToInt32(dr["Sesion"]), Convert.ToChar(dr["Caja"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Corte"])));
                }

                return list;
            } // End Read

            public static ControlCajas Read(int sesion)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Sesion", sesion);
                DataTable dt = DB.Select("ControlCajas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlCajas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlCajas(Convert.ToInt32(dr["Sesion"]), Convert.ToChar(dr["Caja"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Corte"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Sesion", this.Sesion);
                m_params.Add("Caja", this.Caja);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Corte)) m_params.Add("Corte", this.Corte);

                return DB.UpdateRow("ControlCajas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Sesion", this.Sesion);

                return DB.DeleteRow("ControlCajas", w_params);
            } // End Delete

        } //End Class ControlCajas

        public class ControlInventarioPEPS
        {

            public ControlInventarioPEPS()
            {
            }

            public ControlInventarioPEPS(int folio, int anno, int mes, char movimiento, string concepto, int? ordencompra, int? ordentrabajo, int refaccion, int marca, int proveedor, int tipo, decimal cantidad, decimal costounitario, decimal valor, decimal? preciounitario, decimal? valorventa, decimal? utilidad, decimal saldocantidad, decimal saldocostounitario, decimal saldovalor, DateTime fecha, string usuario)
            {
                this.Folio = folio;
                this.Anno = anno;
                this.Mes = mes;
                this.Movimiento = movimiento;
                this.Concepto = concepto;
                this.OrdenCompra = ordencompra;
                this.OrdenTrabajo = ordentrabajo;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.PrecioUnitario = preciounitario;
                this.ValorVenta = valorventa;
                this.Utilidad = utilidad;
                this.SaldoCantidad = saldocantidad;
                this.SaldoCostoUnitario = saldocostounitario;
                this.SaldoValor = saldovalor;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Anno;
            public int Anno
            {
                get { return _Anno; }
                set { _Anno = value; }
            }

            private int _Mes;
            public int Mes
            {
                get { return _Mes; }
                set { _Mes = value; }
            }

            private char _Movimiento;
            public char Movimiento
            {
                get { return _Movimiento; }
                set { _Movimiento = value; }
            }

            private string _Concepto;
            public string Concepto
            {
                get { return _Concepto; }
                set { _Concepto = value; }
            }

            private int? _OrdenCompra;
            public int? OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private int? _OrdenTrabajo;
            public int? OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal _Valor;
            public decimal Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private decimal? _PrecioUnitario;
            public decimal? PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private decimal? _ValorVenta;
            public decimal? ValorVenta
            {
                get { return _ValorVenta; }
                set { _ValorVenta = value; }
            }

            private decimal? _Utilidad;
            public decimal? Utilidad
            {
                get { return _Utilidad; }
                set { _Utilidad = value; }
            }

            private decimal _SaldoCantidad;
            public decimal SaldoCantidad
            {
                get { return _SaldoCantidad; }
                set { _SaldoCantidad = value; }
            }

            private decimal _SaldoCostoUnitario;
            public decimal SaldoCostoUnitario
            {
                get { return _SaldoCostoUnitario; }
                set { _SaldoCostoUnitario = value; }
            }

            private decimal _SaldoValor;
            public decimal SaldoValor
            {
                get { return _SaldoValor; }
                set { _SaldoValor = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Concepto", this.Concepto);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.PrecioUnitario)) m_params.Add("PrecioUnitario", this.PrecioUnitario);
                if (!AppHelper.IsNullOrEmpty(this.ValorVenta)) m_params.Add("ValorVenta", this.ValorVenta);
                if (!AppHelper.IsNullOrEmpty(this.Utilidad)) m_params.Add("Utilidad", this.Utilidad);
                m_params.Add("SaldoCantidad", this.SaldoCantidad);
                m_params.Add("SaldoCostoUnitario", this.SaldoCostoUnitario);
                m_params.Add("SaldoValor", this.SaldoValor);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("ControlInventarioPEPS", m_params);
            } // End Create

            public static List<ControlInventarioPEPS> Read()
            {
                List<ControlInventarioPEPS> list = new List<ControlInventarioPEPS>();
                DataTable dt = DB.Select("ControlInventarioPEPS");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlInventarioPEPS(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), Convert.ToChar(dr["Movimiento"]), Convert.ToString(dr["Concepto"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), DB.GetNullableDecimal(dr["PrecioUnitario"]), DB.GetNullableDecimal(dr["ValorVenta"]), DB.GetNullableDecimal(dr["Utilidad"]), Convert.ToDecimal(dr["SaldoCantidad"]), Convert.ToDecimal(dr["SaldoCostoUnitario"]), Convert.ToDecimal(dr["SaldoValor"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public static ControlInventarioPEPS Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ControlInventarioPEPS", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlInventarioPEPS con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlInventarioPEPS(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), Convert.ToChar(dr["Movimiento"]), Convert.ToString(dr["Concepto"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), DB.GetNullableDecimal(dr["PrecioUnitario"]), DB.GetNullableDecimal(dr["ValorVenta"]), DB.GetNullableDecimal(dr["Utilidad"]), Convert.ToDecimal(dr["SaldoCantidad"]), Convert.ToDecimal(dr["SaldoCostoUnitario"]), Convert.ToDecimal(dr["SaldoValor"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Concepto", this.Concepto);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.PrecioUnitario)) m_params.Add("PrecioUnitario", this.PrecioUnitario);
                if (!AppHelper.IsNullOrEmpty(this.ValorVenta)) m_params.Add("ValorVenta", this.ValorVenta);
                if (!AppHelper.IsNullOrEmpty(this.Utilidad)) m_params.Add("Utilidad", this.Utilidad);
                m_params.Add("SaldoCantidad", this.SaldoCantidad);
                m_params.Add("SaldoCostoUnitario", this.SaldoCostoUnitario);
                m_params.Add("SaldoValor", this.SaldoValor);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("ControlInventarioPEPS", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ControlInventarioPEPS", w_params);
            } // End Delete

        } //End Class ControlInventarioPEPS

        public class ControlInventarioPromedio
        {

            public ControlInventarioPromedio()
            {
            }

            public ControlInventarioPromedio(int folio, int anno, int mes, char movimiento, string concepto, int? ordencompra, int? ordentrabajo, int refaccion, int marca, int proveedor, int tipo, decimal cantidad, decimal costounitario, decimal valor, decimal? preciounitario, decimal? valorventa, decimal? utilidad, decimal saldocantidad, decimal saldocostounitario, decimal saldovalor, DateTime fecha, string usuario)
            {
                this.Folio = folio;
                this.Anno = anno;
                this.Mes = mes;
                this.Movimiento = movimiento;
                this.Concepto = concepto;
                this.OrdenCompra = ordencompra;
                this.OrdenTrabajo = ordentrabajo;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.PrecioUnitario = preciounitario;
                this.ValorVenta = valorventa;
                this.Utilidad = utilidad;
                this.SaldoCantidad = saldocantidad;
                this.SaldoCostoUnitario = saldocostounitario;
                this.SaldoValor = saldovalor;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Anno;
            public int Anno
            {
                get { return _Anno; }
                set { _Anno = value; }
            }

            private int _Mes;
            public int Mes
            {
                get { return _Mes; }
                set { _Mes = value; }
            }

            private char _Movimiento;
            public char Movimiento
            {
                get { return _Movimiento; }
                set { _Movimiento = value; }
            }

            private string _Concepto;
            public string Concepto
            {
                get { return _Concepto; }
                set { _Concepto = value; }
            }

            private int? _OrdenCompra;
            public int? OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private int? _OrdenTrabajo;
            public int? OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal _Valor;
            public decimal Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private decimal? _PrecioUnitario;
            public decimal? PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private decimal? _ValorVenta;
            public decimal? ValorVenta
            {
                get { return _ValorVenta; }
                set { _ValorVenta = value; }
            }

            private decimal? _Utilidad;
            public decimal? Utilidad
            {
                get { return _Utilidad; }
                set { _Utilidad = value; }
            }

            private decimal _SaldoCantidad;
            public decimal SaldoCantidad
            {
                get { return _SaldoCantidad; }
                set { _SaldoCantidad = value; }
            }

            private decimal _SaldoCostoUnitario;
            public decimal SaldoCostoUnitario
            {
                get { return _SaldoCostoUnitario; }
                set { _SaldoCostoUnitario = value; }
            }

            private decimal _SaldoValor;
            public decimal SaldoValor
            {
                get { return _SaldoValor; }
                set { _SaldoValor = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Concepto", this.Concepto);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.PrecioUnitario)) m_params.Add("PrecioUnitario", this.PrecioUnitario);
                if (!AppHelper.IsNullOrEmpty(this.ValorVenta)) m_params.Add("ValorVenta", this.ValorVenta);
                if (!AppHelper.IsNullOrEmpty(this.Utilidad)) m_params.Add("Utilidad", this.Utilidad);
                m_params.Add("SaldoCantidad", this.SaldoCantidad);
                m_params.Add("SaldoCostoUnitario", this.SaldoCostoUnitario);
                m_params.Add("SaldoValor", this.SaldoValor);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("ControlInventarioPromedio", m_params);
            } // End Create

            public static List<ControlInventarioPromedio> Read()
            {
                List<ControlInventarioPromedio> list = new List<ControlInventarioPromedio>();
                DataTable dt = DB.Select("ControlInventarioPromedio");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlInventarioPromedio(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), Convert.ToChar(dr["Movimiento"]), Convert.ToString(dr["Concepto"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), DB.GetNullableDecimal(dr["PrecioUnitario"]), DB.GetNullableDecimal(dr["ValorVenta"]), DB.GetNullableDecimal(dr["Utilidad"]), Convert.ToDecimal(dr["SaldoCantidad"]), Convert.ToDecimal(dr["SaldoCostoUnitario"]), Convert.ToDecimal(dr["SaldoValor"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public static ControlInventarioPromedio Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ControlInventarioPromedio", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlInventarioPromedio con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlInventarioPromedio(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), Convert.ToChar(dr["Movimiento"]), Convert.ToString(dr["Concepto"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), DB.GetNullableDecimal(dr["PrecioUnitario"]), DB.GetNullableDecimal(dr["ValorVenta"]), DB.GetNullableDecimal(dr["Utilidad"]), Convert.ToDecimal(dr["SaldoCantidad"]), Convert.ToDecimal(dr["SaldoCostoUnitario"]), Convert.ToDecimal(dr["SaldoValor"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Concepto", this.Concepto);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.PrecioUnitario)) m_params.Add("PrecioUnitario", this.PrecioUnitario);
                if (!AppHelper.IsNullOrEmpty(this.ValorVenta)) m_params.Add("ValorVenta", this.ValorVenta);
                if (!AppHelper.IsNullOrEmpty(this.Utilidad)) m_params.Add("Utilidad", this.Utilidad);
                m_params.Add("SaldoCantidad", this.SaldoCantidad);
                m_params.Add("SaldoCostoUnitario", this.SaldoCostoUnitario);
                m_params.Add("SaldoValor", this.SaldoValor);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("ControlInventarioPromedio", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ControlInventarioPromedio", w_params);
            } // End Delete

        } //End Class ControlInventarioPromedio

        public class ControlLicencias
        {

            public ControlLicencias()
            {
            }

            public ControlLicencias(int folio, int conductor, int tipo, string numerolicencia, DateTime fechavencimiento)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Tipo = tipo;
                this.NumeroLicencia = numerolicencia;
                this.FechaVencimiento = fechavencimiento;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private string _NumeroLicencia;
            public string NumeroLicencia
            {
                get { return _NumeroLicencia; }
                set { _NumeroLicencia = value; }
            }

            private DateTime _FechaVencimiento;
            public DateTime FechaVencimiento
            {
                get { return _FechaVencimiento; }
                set { _FechaVencimiento = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("NumeroLicencia", this.NumeroLicencia);
                m_params.Add("FechaVencimiento", this.FechaVencimiento);

                return DB.InsertRow("ControlLicencias", m_params);
            } // End Create

            public static List<ControlLicencias> Read()
            {
                List<ControlLicencias> list = new List<ControlLicencias>();
                DataTable dt = DB.Select("ControlLicencias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlLicencias(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToString(dr["NumeroLicencia"]), Convert.ToDateTime(dr["FechaVencimiento"])));
                }

                return list;
            } // End Read

            public static ControlLicencias Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ControlLicencias", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlLicencias con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlLicencias(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToString(dr["NumeroLicencia"]), Convert.ToDateTime(dr["FechaVencimiento"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("NumeroLicencia", this.NumeroLicencia);
                m_params.Add("FechaVencimiento", this.FechaVencimiento);

                return DB.UpdateRow("ControlLicencias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ControlLicencias", w_params);
            } // End Delete

        } //End Class ControlLicencias

        public class ControlServiciosMecanicos
        {

            public ControlServiciosMecanicos()
            {
            }

            public ControlServiciosMecanicos(int folio, int ordenservicio, int servicio, int mecanico, DateTime inicio, DateTime? fin, int? minutostotales, int? minutosefectivos, int? minutosreales, int? diferencia, decimal? costoservicio, decimal? porcentajecomision, decimal? comision, int status)
            {
                this.Folio = folio;
                this.OrdenServicio = ordenservicio;
                this.Servicio = servicio;
                this.Mecanico = mecanico;
                this.Inicio = inicio;
                this.Fin = fin;
                this.MinutosTotales = minutostotales;
                this.MinutosEfectivos = minutosefectivos;
                this.MinutosReales = minutosreales;
                this.Diferencia = diferencia;
                this.CostoServicio = costoservicio;
                this.PorcentajeComision = porcentajecomision;
                this.Comision = comision;
                this.Status = status;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _OrdenServicio;
            public int OrdenServicio
            {
                get { return _OrdenServicio; }
                set { _OrdenServicio = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            private DateTime _Inicio;
            public DateTime Inicio
            {
                get { return _Inicio; }
                set { _Inicio = value; }
            }

            private DateTime? _Fin;
            public DateTime? Fin
            {
                get { return _Fin; }
                set { _Fin = value; }
            }

            private int? _MinutosTotales;
            public int? MinutosTotales
            {
                get { return _MinutosTotales; }
                set { _MinutosTotales = value; }
            }

            private int? _MinutosEfectivos;
            public int? MinutosEfectivos
            {
                get { return _MinutosEfectivos; }
                set { _MinutosEfectivos = value; }
            }

            private int? _MinutosReales;
            public int? MinutosReales
            {
                get { return _MinutosReales; }
                set { _MinutosReales = value; }
            }

            private int? _Diferencia;
            public int? Diferencia
            {
                get { return _Diferencia; }
                set { _Diferencia = value; }
            }

            private decimal? _CostoServicio;
            public decimal? CostoServicio
            {
                get { return _CostoServicio; }
                set { _CostoServicio = value; }
            }

            private decimal? _PorcentajeComision;
            public decimal? PorcentajeComision
            {
                get { return _PorcentajeComision; }
                set { _PorcentajeComision = value; }
            }

            private decimal? _Comision;
            public decimal? Comision
            {
                get { return _Comision; }
                set { _Comision = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Fin)) m_params.Add("Fin", this.Fin);
                if (!AppHelper.IsNullOrEmpty(this.MinutosTotales)) m_params.Add("MinutosTotales", this.MinutosTotales);
                if (!AppHelper.IsNullOrEmpty(this.MinutosEfectivos)) m_params.Add("MinutosEfectivos", this.MinutosEfectivos);
                if (!AppHelper.IsNullOrEmpty(this.MinutosReales)) m_params.Add("MinutosReales", this.MinutosReales);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.CostoServicio)) m_params.Add("CostoServicio", this.CostoServicio);
                if (!AppHelper.IsNullOrEmpty(this.PorcentajeComision)) m_params.Add("PorcentajeComision", this.PorcentajeComision);
                if (!AppHelper.IsNullOrEmpty(this.Comision)) m_params.Add("Comision", this.Comision);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("ControlServiciosMecanicos", m_params);
            } // End Create

            public static List<ControlServiciosMecanicos> Read()
            {
                List<ControlServiciosMecanicos> list = new List<ControlServiciosMecanicos>();
                DataTable dt = DB.Select("ControlServiciosMecanicos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ControlServiciosMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Fin"]), DB.GetNullableInt32(dr["MinutosTotales"]), DB.GetNullableInt32(dr["MinutosEfectivos"]), DB.GetNullableInt32(dr["MinutosReales"]), DB.GetNullableInt32(dr["Diferencia"]), DB.GetNullableDecimal(dr["CostoServicio"]), DB.GetNullableDecimal(dr["PorcentajeComision"]), DB.GetNullableDecimal(dr["Comision"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public static ControlServiciosMecanicos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ControlServiciosMecanicos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ControlServiciosMecanicos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ControlServiciosMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToDateTime(dr["Inicio"]), DB.GetNullableDateTime(dr["Fin"]), DB.GetNullableInt32(dr["MinutosTotales"]), DB.GetNullableInt32(dr["MinutosEfectivos"]), DB.GetNullableInt32(dr["MinutosReales"]), DB.GetNullableInt32(dr["Diferencia"]), DB.GetNullableDecimal(dr["CostoServicio"]), DB.GetNullableDecimal(dr["PorcentajeComision"]), DB.GetNullableDecimal(dr["Comision"]), Convert.ToInt32(dr["Status"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Inicio", this.Inicio);
                if (!AppHelper.IsNullOrEmpty(this.Fin)) m_params.Add("Fin", this.Fin);
                if (!AppHelper.IsNullOrEmpty(this.MinutosTotales)) m_params.Add("MinutosTotales", this.MinutosTotales);
                if (!AppHelper.IsNullOrEmpty(this.MinutosEfectivos)) m_params.Add("MinutosEfectivos", this.MinutosEfectivos);
                if (!AppHelper.IsNullOrEmpty(this.MinutosReales)) m_params.Add("MinutosReales", this.MinutosReales);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.CostoServicio)) m_params.Add("CostoServicio", this.CostoServicio);
                if (!AppHelper.IsNullOrEmpty(this.PorcentajeComision)) m_params.Add("PorcentajeComision", this.PorcentajeComision);
                if (!AppHelper.IsNullOrEmpty(this.Comision)) m_params.Add("Comision", this.Comision);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("ControlServiciosMecanicos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ControlServiciosMecanicos", w_params);
            } // End Delete

        } //End Class ControlServiciosMecanicos

        public class Cotizaciones
        {

            public Cotizaciones()
            {
            }

            public Cotizaciones(int folio, int cliente, int unidad, string comentarios, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Cliente = cliente;
                this.Unidad = unidad;
                this.Comentarios = comentarios;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Cliente;
            public int Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Cotizaciones", m_params);
            } // End Create

            public static List<Cotizaciones> Read()
            {
                List<Cotizaciones> list = new List<Cotizaciones>();
                DataTable dt = DB.Select("Cotizaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Cotizaciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Cliente"]), Convert.ToInt32(dr["Unidad"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Cotizaciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Cotizaciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Cotizaciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Cotizaciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Cliente"]), Convert.ToInt32(dr["Unidad"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Cotizaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Cotizaciones", w_params);
            } // End Delete

        } //End Class Cotizaciones

        public class CuentaConductor
        {

            public CuentaConductor()
            {
            }

            public CuentaConductor(int folio, int conductor, int unidad, int concepto, decimal monto, int? caja, DateTime fechaalta, string usuarioalta, string comentarios)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Concepto = concepto;
                this.Monto = monto;
                this.Caja = caja;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.Comentarios = comentarios;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Concepto;
            public int Concepto
            {
                get { return _Concepto; }
                set { _Concepto = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private int? _Caja;
            public int? Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Concepto", this.Concepto);
                m_params.Add("Monto", this.Monto);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);

                return DB.InsertRow("CuentaConductor", m_params);
            } // End Create

            public static List<CuentaConductor> Read()
            {
                List<CuentaConductor> list = new List<CuentaConductor>();
                DataTable dt = DB.Select("CuentaConductor");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CuentaConductor(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Concepto"]), Convert.ToDecimal(dr["Monto"]), DB.GetNullableInt32(dr["Caja"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Comentarios"])));
                }

                return list;
            } // End Read

            public static CuentaConductor Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("CuentaConductor", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CuentaConductor con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CuentaConductor(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Concepto"]), Convert.ToDecimal(dr["Monto"]), DB.GetNullableInt32(dr["Caja"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Comentarios"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Concepto", this.Concepto);
                m_params.Add("Monto", this.Monto);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);

                return DB.UpdateRow("CuentaConductor", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("CuentaConductor", w_params);
            } // End Delete

        } //End Class CuentaConductor

        public class CuentaConductor_MovimientosCaja
        {

            public CuentaConductor_MovimientosCaja()
            {
            }

            public CuentaConductor_MovimientosCaja(int movimientocc, int movimientocaja)
            {
                this.MovimientoCC = movimientocc;
                this.MovimientoCaja = movimientocaja;
            }

            private int _MovimientoCC;
            public int MovimientoCC
            {
                get { return _MovimientoCC; }
                set { _MovimientoCC = value; }
            }

            private int _MovimientoCaja;
            public int MovimientoCaja
            {
                get { return _MovimientoCaja; }
                set { _MovimientoCaja = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("MovimientoCC", this.MovimientoCC);
                m_params.Add("MovimientoCaja", this.MovimientoCaja);

                return DB.InsertRow("CuentaConductor_MovimientosCaja", m_params);
            } // End Create

            public static List<CuentaConductor_MovimientosCaja> Read()
            {
                List<CuentaConductor_MovimientosCaja> list = new List<CuentaConductor_MovimientosCaja>();
                DataTable dt = DB.Select("CuentaConductor_MovimientosCaja");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CuentaConductor_MovimientosCaja(Convert.ToInt32(dr["MovimientoCC"]), Convert.ToInt32(dr["MovimientoCaja"])));
                }

                return list;
            } // End Read

            public static CuentaConductor_MovimientosCaja Read(int movimientocc, int movimientocaja)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("MovimientoCC", movimientocc);
                w_params.Add("MovimientoCaja", movimientocaja);
                DataTable dt = DB.Select("CuentaConductor_MovimientosCaja", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CuentaConductor_MovimientosCaja con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CuentaConductor_MovimientosCaja(Convert.ToInt32(dr["MovimientoCC"]), Convert.ToInt32(dr["MovimientoCaja"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("MovimientoCC", this.MovimientoCC);
                w_params.Add("MovimientoCaja", this.MovimientoCaja);

                return DB.UpdateRow("CuentaConductor_MovimientosCaja", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("MovimientoCC", this.MovimientoCC);
                w_params.Add("MovimientoCaja", this.MovimientoCaja);

                return DB.DeleteRow("CuentaConductor_MovimientosCaja", w_params);
            } // End Delete

        } //End Class CuentaConductor_MovimientosCaja

        public class CuentaDepositosGarantia
        {

            public CuentaDepositosGarantia()
            {
            }

            public CuentaDepositosGarantia(int folio, int estacion, int? concepto, int caja, int conductor, decimal monto, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Estacion = estacion;
                this.Concepto = concepto;
                this.Caja = caja;
                this.Conductor = conductor;
                this.Monto = monto;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int? _Concepto;
            public int? Concepto
            {
                get { return _Concepto; }
                set { _Concepto = value; }
            }

            private int _Caja;
            public int Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Concepto)) m_params.Add("Concepto", this.Concepto);
                m_params.Add("Caja", this.Caja);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Monto", this.Monto);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("CuentaDepositosGarantia", m_params);
            } // End Create

            public static List<CuentaDepositosGarantia> Read()
            {
                List<CuentaDepositosGarantia> list = new List<CuentaDepositosGarantia>();
                DataTable dt = DB.Select("CuentaDepositosGarantia");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CuentaDepositosGarantia(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), DB.GetNullableInt32(dr["Concepto"]), Convert.ToInt32(dr["Caja"]), Convert.ToInt32(dr["Conductor"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static CuentaDepositosGarantia Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("CuentaDepositosGarantia", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CuentaDepositosGarantia con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CuentaDepositosGarantia(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), DB.GetNullableInt32(dr["Concepto"]), Convert.ToInt32(dr["Caja"]), Convert.ToInt32(dr["Conductor"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Concepto)) m_params.Add("Concepto", this.Concepto);
                m_params.Add("Caja", this.Caja);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Monto", this.Monto);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("CuentaDepositosGarantia", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("CuentaDepositosGarantia", w_params);
            } // End Delete

        } //End Class CuentaDepositosGarantia

        public class Cuentas
        {

            public Cuentas()
            {
            }

            public Cuentas(int folio, int fondocaja, string descripcion)
            {
                this.Folio = folio;
                this.FondoCaja = fondocaja;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _FondoCaja;
            public int FondoCaja
            {
                get { return _FondoCaja; }
                set { _FondoCaja = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("FondoCaja", this.FondoCaja);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Cuentas", m_params);
            } // End Create

            public static List<Cuentas> Read()
            {
                List<Cuentas> list = new List<Cuentas>();
                DataTable dt = DB.Select("Cuentas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Cuentas(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["FondoCaja"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static Cuentas Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Cuentas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Cuentas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Cuentas(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["FondoCaja"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("FondoCaja", this.FondoCaja);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Cuentas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Cuentas", w_params);
            } // End Delete

        } //End Class Cuentas

        public class CuentaSiniestros
        {

            public CuentaSiniestros()
            {
            }

            public CuentaSiniestros(int folio, int siniestro, int tipo, decimal monto, string motivo, DateTime fecha, string usuarioalta)
            {
                this.Folio = folio;
                this.Siniestro = siniestro;
                this.Tipo = tipo;
                this.Monto = monto;
                this.Motivo = motivo;
                this.Fecha = fecha;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Siniestro;
            public int Siniestro
            {
                get { return _Siniestro; }
                set { _Siniestro = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Siniestro", this.Siniestro);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("CuentaSiniestros", m_params);
            } // End Create

            public static List<CuentaSiniestros> Read()
            {
                List<CuentaSiniestros> list = new List<CuentaSiniestros>();
                DataTable dt = DB.Select("CuentaSiniestros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new CuentaSiniestros(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Siniestro"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Monto"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static CuentaSiniestros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("CuentaSiniestros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe CuentaSiniestros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new CuentaSiniestros(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Siniestro"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Monto"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Siniestro", this.Siniestro);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("CuentaSiniestros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("CuentaSiniestros", w_params);
            } // End Delete

        } //End Class CuentaSiniestros

        public class DeclaracionCopias
        {

            public DeclaracionCopias()
            {
            }

            public DeclaracionCopias(int folio, int contrato, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Contrato = contrato;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Contrato;
            public int Contrato
            {
                get { return _Contrato; }
                set { _Contrato = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("DeclaracionCopias", m_params);
            } // End Create

            public static List<DeclaracionCopias> Read()
            {
                List<DeclaracionCopias> list = new List<DeclaracionCopias>();
                DataTable dt = DB.Select("DeclaracionCopias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DeclaracionCopias(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Contrato"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static DeclaracionCopias Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("DeclaracionCopias", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe DeclaracionCopias con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new DeclaracionCopias(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Contrato"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Contrato", this.Contrato);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("DeclaracionCopias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("DeclaracionCopias", w_params);
            } // End Delete

        } //End Class DeclaracionCopias

        public class DestajosServiciosMecanicos
        {

            public DestajosServiciosMecanicos()
            {
            }

            public DestajosServiciosMecanicos(int mecanico, int? categoria, int año, int semana, DateTime fechainicial, DateTime fechafinal, int totaldeservicios, int serviciosconeficiencia, int serviciossineficiencia, int retrabajos, decimal porcentajeeficiencia, decimal porcentajecalidad, decimal porcentajetotalcomision, decimal totalmanoobra, decimal totaldestajo, DateTime fecha)
            {
                this.Mecanico = mecanico;
                this.Categoria = categoria;
                this.Año = año;
                this.Semana = semana;
                this.FechaInicial = fechainicial;
                this.FechaFinal = fechafinal;
                this.TotalDeServicios = totaldeservicios;
                this.ServiciosConEficiencia = serviciosconeficiencia;
                this.ServiciosSinEficiencia = serviciossineficiencia;
                this.Retrabajos = retrabajos;
                this.PorcentajeEficiencia = porcentajeeficiencia;
                this.PorcentajeCalidad = porcentajecalidad;
                this.PorcentajeTotalComision = porcentajetotalcomision;
                this.TotalManoObra = totalmanoobra;
                this.TotalDestajo = totaldestajo;
                this.Fecha = fecha;
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            private int? _Categoria;
            public int? Categoria
            {
                get { return _Categoria; }
                set { _Categoria = value; }
            }

            private int _Año;
            public int Año
            {
                get { return _Año; }
                set { _Año = value; }
            }

            private int _Semana;
            public int Semana
            {
                get { return _Semana; }
                set { _Semana = value; }
            }

            private DateTime _FechaInicial;
            public DateTime FechaInicial
            {
                get { return _FechaInicial; }
                set { _FechaInicial = value; }
            }

            private DateTime _FechaFinal;
            public DateTime FechaFinal
            {
                get { return _FechaFinal; }
                set { _FechaFinal = value; }
            }

            private int _TotalDeServicios;
            public int TotalDeServicios
            {
                get { return _TotalDeServicios; }
                set { _TotalDeServicios = value; }
            }

            private int _ServiciosConEficiencia;
            public int ServiciosConEficiencia
            {
                get { return _ServiciosConEficiencia; }
                set { _ServiciosConEficiencia = value; }
            }

            private int _ServiciosSinEficiencia;
            public int ServiciosSinEficiencia
            {
                get { return _ServiciosSinEficiencia; }
                set { _ServiciosSinEficiencia = value; }
            }

            private int _Retrabajos;
            public int Retrabajos
            {
                get { return _Retrabajos; }
                set { _Retrabajos = value; }
            }

            private decimal _PorcentajeEficiencia;
            public decimal PorcentajeEficiencia
            {
                get { return _PorcentajeEficiencia; }
                set { _PorcentajeEficiencia = value; }
            }

            private decimal _PorcentajeCalidad;
            public decimal PorcentajeCalidad
            {
                get { return _PorcentajeCalidad; }
                set { _PorcentajeCalidad = value; }
            }

            private decimal _PorcentajeTotalComision;
            public decimal PorcentajeTotalComision
            {
                get { return _PorcentajeTotalComision; }
                set { _PorcentajeTotalComision = value; }
            }

            private decimal _TotalManoObra;
            public decimal TotalManoObra
            {
                get { return _TotalManoObra; }
                set { _TotalManoObra = value; }
            }

            private decimal _TotalDestajo;
            public decimal TotalDestajo
            {
                get { return _TotalDestajo; }
                set { _TotalDestajo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Mecanico", this.Mecanico);
                if (!AppHelper.IsNullOrEmpty(this.Categoria)) m_params.Add("Categoria", this.Categoria);
                m_params.Add("Año", this.Año);
                m_params.Add("Semana", this.Semana);
                m_params.Add("FechaInicial", this.FechaInicial);
                m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("TotalDeServicios", this.TotalDeServicios);
                m_params.Add("ServiciosConEficiencia", this.ServiciosConEficiencia);
                m_params.Add("ServiciosSinEficiencia", this.ServiciosSinEficiencia);
                m_params.Add("Retrabajos", this.Retrabajos);
                m_params.Add("PorcentajeEficiencia", this.PorcentajeEficiencia);
                m_params.Add("PorcentajeCalidad", this.PorcentajeCalidad);
                m_params.Add("PorcentajeTotalComision", this.PorcentajeTotalComision);
                m_params.Add("TotalManoObra", this.TotalManoObra);
                m_params.Add("TotalDestajo", this.TotalDestajo);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("DestajosServiciosMecanicos", m_params);
            } // End Create

            public static List<DestajosServiciosMecanicos> Read()
            {
                List<DestajosServiciosMecanicos> list = new List<DestajosServiciosMecanicos>();
                DataTable dt = DB.Select("DestajosServiciosMecanicos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DestajosServiciosMecanicos(Convert.ToInt32(dr["Mecanico"]), DB.GetNullableInt32(dr["Categoria"]), Convert.ToInt32(dr["Año"]), Convert.ToInt32(dr["Semana"]), Convert.ToDateTime(dr["FechaInicial"]), Convert.ToDateTime(dr["FechaFinal"]), Convert.ToInt32(dr["TotalDeServicios"]), Convert.ToInt32(dr["ServiciosConEficiencia"]), Convert.ToInt32(dr["ServiciosSinEficiencia"]), Convert.ToInt32(dr["Retrabajos"]), Convert.ToDecimal(dr["PorcentajeEficiencia"]), Convert.ToDecimal(dr["PorcentajeCalidad"]), Convert.ToDecimal(dr["PorcentajeTotalComision"]), Convert.ToDecimal(dr["TotalManoObra"]), Convert.ToDecimal(dr["TotalDestajo"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static DestajosServiciosMecanicos Read(int mecanico, int año, int semana)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Mecanico", mecanico);
                w_params.Add("Año", año);
                w_params.Add("Semana", semana);
                DataTable dt = DB.Select("DestajosServiciosMecanicos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe DestajosServiciosMecanicos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new DestajosServiciosMecanicos(Convert.ToInt32(dr["Mecanico"]), DB.GetNullableInt32(dr["Categoria"]), Convert.ToInt32(dr["Año"]), Convert.ToInt32(dr["Semana"]), Convert.ToDateTime(dr["FechaInicial"]), Convert.ToDateTime(dr["FechaFinal"]), Convert.ToInt32(dr["TotalDeServicios"]), Convert.ToInt32(dr["ServiciosConEficiencia"]), Convert.ToInt32(dr["ServiciosSinEficiencia"]), Convert.ToInt32(dr["Retrabajos"]), Convert.ToDecimal(dr["PorcentajeEficiencia"]), Convert.ToDecimal(dr["PorcentajeCalidad"]), Convert.ToDecimal(dr["PorcentajeTotalComision"]), Convert.ToDecimal(dr["TotalManoObra"]), Convert.ToDecimal(dr["TotalDestajo"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Mecanico", this.Mecanico);
                if (!AppHelper.IsNullOrEmpty(this.Categoria)) m_params.Add("Categoria", this.Categoria);
                w_params.Add("Año", this.Año);
                w_params.Add("Semana", this.Semana);
                m_params.Add("FechaInicial", this.FechaInicial);
                m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("TotalDeServicios", this.TotalDeServicios);
                m_params.Add("ServiciosConEficiencia", this.ServiciosConEficiencia);
                m_params.Add("ServiciosSinEficiencia", this.ServiciosSinEficiencia);
                m_params.Add("Retrabajos", this.Retrabajos);
                m_params.Add("PorcentajeEficiencia", this.PorcentajeEficiencia);
                m_params.Add("PorcentajeCalidad", this.PorcentajeCalidad);
                m_params.Add("PorcentajeTotalComision", this.PorcentajeTotalComision);
                m_params.Add("TotalManoObra", this.TotalManoObra);
                m_params.Add("TotalDestajo", this.TotalDestajo);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("DestajosServiciosMecanicos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Mecanico", this.Mecanico);
                w_params.Add("Año", this.Año);
                w_params.Add("Semana", this.Semana);

                return DB.DeleteRow("DestajosServiciosMecanicos", w_params);
            } // End Delete

        } //End Class DestajosServiciosMecanicos

        public class DetalleAjusteKm
        {

            public DetalleAjusteKm()
            {
            }

            public DetalleAjusteKm(int ajuste, int unidad, int kilometreje, DateTime fecha)
            {
                this.Ajuste = ajuste;
                this.Unidad = unidad;
                this.Kilometreje = kilometreje;
                this.Fecha = fecha;
            }

            private int _Ajuste;
            public int Ajuste
            {
                get { return _Ajuste; }
                set { _Ajuste = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Kilometreje;
            public int Kilometreje
            {
                get { return _Kilometreje; }
                set { _Kilometreje = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Ajuste", this.Ajuste);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Kilometreje", this.Kilometreje);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("DetalleAjusteKm", m_params);
            } // End Create

            public static List<DetalleAjusteKm> Read()
            {
                List<DetalleAjusteKm> list = new List<DetalleAjusteKm>();
                DataTable dt = DB.Select("DetalleAjusteKm");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DetalleAjusteKm(Convert.ToInt32(dr["Ajuste"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Kilometreje"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Ajuste", this.Ajuste);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Kilometreje", this.Kilometreje);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("DetalleAjusteKm", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("DetalleAjusteKm", w_params);
            } // End Delete

        } //End Class DetalleAjusteKm

        public class DetalleConductor
        {

            public DetalleConductor()
            {
            }

            public DetalleConductor(int conductor, decimal saldoatratar, bool cronocasco, bool terminaldatos, bool bloquearconductor, string mensajeacaja)
            {
                this.Conductor = conductor;
                this.Conductor = conductor;
                this.SaldoATratar = saldoatratar;
                this.Cronocasco = cronocasco;
                this.TerminalDatos = terminaldatos;
                this.BloquearConductor = bloquearconductor;
                this.MensajeACaja = mensajeacaja;
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private decimal _SaldoATratar;
            public decimal SaldoATratar
            {
                get { return _SaldoATratar; }
                set { _SaldoATratar = value; }
            }

            private bool _Cronocasco;
            public bool Cronocasco
            {
                get { return _Cronocasco; }
                set { _Cronocasco = value; }
            }

            private bool _TerminalDatos;
            public bool TerminalDatos
            {
                get { return _TerminalDatos; }
                set { _TerminalDatos = value; }
            }

            private bool _BloquearConductor;
            public bool BloquearConductor
            {
                get { return _BloquearConductor; }
                set { _BloquearConductor = value; }
            }

            private string _MensajeACaja;
            public string MensajeACaja
            {
                get { return _MensajeACaja; }
                set { _MensajeACaja = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("SaldoATratar", this.SaldoATratar);
                m_params.Add("Cronocasco", this.Cronocasco);
                m_params.Add("TerminalDatos", this.TerminalDatos);
                m_params.Add("BloquearConductor", this.BloquearConductor);
                if (!AppHelper.IsNullOrEmpty(this.MensajeACaja)) m_params.Add("MensajeACaja", this.MensajeACaja);

                return DB.InsertRow("DetalleConductor", m_params);
            } // End Create

            public static List<DetalleConductor> Read()
            {
                List<DetalleConductor> list = new List<DetalleConductor>();
                DataTable dt = DB.Select("DetalleConductor");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DetalleConductor(Convert.ToInt32(dr["Conductor"]), Convert.ToDecimal(dr["SaldoATratar"]), Convert.ToBoolean(dr["Cronocasco"]), Convert.ToBoolean(dr["TerminalDatos"]), Convert.ToBoolean(dr["BloquearConductor"]), Convert.ToString(dr["MensajeACaja"])));
                }

                return list;
            } // End Read

            public static DetalleConductor Read(int conductor)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Conductor", conductor);
                DataTable dt = DB.Select("DetalleConductor", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe DetalleConductor con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new DetalleConductor(Convert.ToInt32(dr["Conductor"]), Convert.ToDecimal(dr["SaldoATratar"]), Convert.ToBoolean(dr["Cronocasco"]), Convert.ToBoolean(dr["TerminalDatos"]), Convert.ToBoolean(dr["BloquearConductor"]), Convert.ToString(dr["MensajeACaja"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                w_params.Add("Conductor", this.Conductor);
                m_params.Add("SaldoATratar", this.SaldoATratar);
                m_params.Add("Cronocasco", this.Cronocasco);
                m_params.Add("TerminalDatos", this.TerminalDatos);
                m_params.Add("BloquearConductor", this.BloquearConductor);
                if (!AppHelper.IsNullOrEmpty(this.MensajeACaja)) m_params.Add("MensajeACaja", this.MensajeACaja);

                return DB.UpdateRow("DetalleConductor", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Conductor", this.Conductor);

                return DB.DeleteRow("DetalleConductor", w_params);
            } // End Delete

        } //End Class DetalleConductor

        public class DiasPlanes
        {

            public DiasPlanes()
            {
            }

            public DiasPlanes(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("DiasPlanes", m_params);
            } // End Create

            public static List<DiasPlanes> Read()
            {
                List<DiasPlanes> list = new List<DiasPlanes>();
                DataTable dt = DB.Select("DiasPlanes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DiasPlanes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static DiasPlanes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("DiasPlanes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe DiasPlanes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new DiasPlanes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("DiasPlanes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("DiasPlanes", w_params);
            } // End Delete

        } //End Class DiasPlanes

        public class DIFERENCIAS_INV_0309
        {

            public DIFERENCIAS_INV_0309()
            {
            }

            public DIFERENCIAS_INV_0309(int? folio, string descripcion, decimal? cantidad, decimal? captura, decimal? diferencia, decimal? inventario, bool? caso)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Cantidad = cantidad;
                this.Captura = captura;
                this.Diferencia = diferencia;
                this.Inventario = inventario;
                this.Caso = caso;
            }

            private int? _Folio;
            public int? Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private decimal? _Cantidad;
            public decimal? Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal? _Captura;
            public decimal? Captura
            {
                get { return _Captura; }
                set { _Captura = value; }
            }

            private decimal? _Diferencia;
            public decimal? Diferencia
            {
                get { return _Diferencia; }
                set { _Diferencia = value; }
            }

            private decimal? _Inventario;
            public decimal? Inventario
            {
                get { return _Inventario; }
                set { _Inventario = value; }
            }

            private bool? _Caso;
            public bool? Caso
            {
                get { return _Caso; }
                set { _Caso = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Captura)) m_params.Add("Captura", this.Captura);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.Inventario)) m_params.Add("Inventario", this.Inventario);
                if (!AppHelper.IsNullOrEmpty(this.Caso)) m_params.Add("Caso", this.Caso);

                return DB.InsertRow("DIFERENCIAS_INV_0309", m_params);
            } // End Create

            public static List<DIFERENCIAS_INV_0309> Read()
            {
                List<DIFERENCIAS_INV_0309> list = new List<DIFERENCIAS_INV_0309>();
                DataTable dt = DB.Select("DIFERENCIAS_INV_0309");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DIFERENCIAS_INV_0309(DB.GetNullableInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableDecimal(dr["Cantidad"]), DB.GetNullableDecimal(dr["Captura"]), DB.GetNullableDecimal(dr["Diferencia"]), DB.GetNullableDecimal(dr["Inventario"]), DB.GetNullableBoolean(dr["Caso"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Captura)) m_params.Add("Captura", this.Captura);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.Inventario)) m_params.Add("Inventario", this.Inventario);
                if (!AppHelper.IsNullOrEmpty(this.Caso)) m_params.Add("Caso", this.Caso);

                return DB.UpdateRow("DIFERENCIAS_INV_0309", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("DIFERENCIAS_INV_0309", w_params);
            } // End Delete

        } //End Class DIFERENCIAS_INV_0309

        public class DIFERENCIASINV_0409
        {

            public DIFERENCIASINV_0409()
            {
            }

            public DIFERENCIASINV_0409(int? folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int? _Folio;
            public int? Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("DIFERENCIASINV_0409", m_params);
            } // End Create

            public static List<DIFERENCIASINV_0409> Read()
            {
                List<DIFERENCIASINV_0409> list = new List<DIFERENCIASINV_0409>();
                DataTable dt = DB.Select("DIFERENCIASINV_0409");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DIFERENCIASINV_0409(DB.GetNullableInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("DIFERENCIASINV_0409", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("DIFERENCIASINV_0409", w_params);
            } // End Delete

        } //End Class DIFERENCIASINV_0409

        public class DiferenciasRefacciones
        {

            public DiferenciasRefacciones()
            {
            }

            public DiferenciasRefacciones(string refaccion, string proveedor, decimal? diferencia, decimal? costounitario, int? folio, int? folioproveedor)
            {
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Diferencia = diferencia;
                this.CostoUnitario = costounitario;
                this.Folio = folio;
                this.FolioProveedor = folioproveedor;
            }

            private string _Refaccion;
            public string Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private string _Proveedor;
            public string Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private decimal? _Diferencia;
            public decimal? Diferencia
            {
                get { return _Diferencia; }
                set { _Diferencia = value; }
            }

            private decimal? _CostoUnitario;
            public decimal? CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private int? _Folio;
            public int? Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int? _FolioProveedor;
            public int? FolioProveedor
            {
                get { return _FolioProveedor; }
                set { _FolioProveedor = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.FolioProveedor)) m_params.Add("FolioProveedor", this.FolioProveedor);

                return DB.InsertRow("DiferenciasRefacciones", m_params);
            } // End Create

            public static List<DiferenciasRefacciones> Read()
            {
                List<DiferenciasRefacciones> list = new List<DiferenciasRefacciones>();
                DataTable dt = DB.Select("DiferenciasRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new DiferenciasRefacciones(Convert.ToString(dr["Refaccion"]), Convert.ToString(dr["Proveedor"]), DB.GetNullableDecimal(dr["Diferencia"]), DB.GetNullableDecimal(dr["CostoUnitario"]), DB.GetNullableInt32(dr["Folio"]), DB.GetNullableInt32(dr["FolioProveedor"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Diferencia)) m_params.Add("Diferencia", this.Diferencia);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.FolioProveedor)) m_params.Add("FolioProveedor", this.FolioProveedor);

                return DB.UpdateRow("DiferenciasRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("DiferenciasRefacciones", w_params);
            } // End Delete

        } //End Class DiferenciasRefacciones

        public class Documentacion
        {

            public Documentacion()
            {
            }

            public Documentacion(int conductor, string solicitud, string actanacimiento, string credencialelector, string cartanoantecedentes, string comprobantedomicilio, string credencialelectoraval, string comprobantedomicilioaval)
            {
                this.Conductor = conductor;
                this.Solicitud = solicitud;
                this.ActaNacimiento = actanacimiento;
                this.CredencialElector = credencialelector;
                this.CartaNoAntecedentes = cartanoantecedentes;
                this.ComprobanteDomicilio = comprobantedomicilio;
                this.CredencialElectorAval = credencialelectoraval;
                this.ComprobanteDomicilioAval = comprobantedomicilioaval;
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private string _Solicitud;
            public string Solicitud
            {
                get { return _Solicitud; }
                set { _Solicitud = value; }
            }

            private string _ActaNacimiento;
            public string ActaNacimiento
            {
                get { return _ActaNacimiento; }
                set { _ActaNacimiento = value; }
            }

            private string _CredencialElector;
            public string CredencialElector
            {
                get { return _CredencialElector; }
                set { _CredencialElector = value; }
            }

            private string _CartaNoAntecedentes;
            public string CartaNoAntecedentes
            {
                get { return _CartaNoAntecedentes; }
                set { _CartaNoAntecedentes = value; }
            }

            private string _ComprobanteDomicilio;
            public string ComprobanteDomicilio
            {
                get { return _ComprobanteDomicilio; }
                set { _ComprobanteDomicilio = value; }
            }

            private string _CredencialElectorAval;
            public string CredencialElectorAval
            {
                get { return _CredencialElectorAval; }
                set { _CredencialElectorAval = value; }
            }

            private string _ComprobanteDomicilioAval;
            public string ComprobanteDomicilioAval
            {
                get { return _ComprobanteDomicilioAval; }
                set { _ComprobanteDomicilioAval = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                if (!AppHelper.IsNullOrEmpty(this.Solicitud)) m_params.Add("Solicitud", this.Solicitud);
                if (!AppHelper.IsNullOrEmpty(this.ActaNacimiento)) m_params.Add("ActaNacimiento", this.ActaNacimiento);
                if (!AppHelper.IsNullOrEmpty(this.CredencialElector)) m_params.Add("CredencialElector", this.CredencialElector);
                if (!AppHelper.IsNullOrEmpty(this.CartaNoAntecedentes)) m_params.Add("CartaNoAntecedentes", this.CartaNoAntecedentes);
                if (!AppHelper.IsNullOrEmpty(this.ComprobanteDomicilio)) m_params.Add("ComprobanteDomicilio", this.ComprobanteDomicilio);
                if (!AppHelper.IsNullOrEmpty(this.CredencialElectorAval)) m_params.Add("CredencialElectorAval", this.CredencialElectorAval);
                if (!AppHelper.IsNullOrEmpty(this.ComprobanteDomicilioAval)) m_params.Add("ComprobanteDomicilioAval", this.ComprobanteDomicilioAval);

                return DB.InsertRow("Documentacion", m_params);
            } // End Create

            public static List<Documentacion> Read()
            {
                List<Documentacion> list = new List<Documentacion>();
                DataTable dt = DB.Select("Documentacion");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Documentacion(Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Solicitud"]), Convert.ToString(dr["ActaNacimiento"]), Convert.ToString(dr["CredencialElector"]), Convert.ToString(dr["CartaNoAntecedentes"]), Convert.ToString(dr["ComprobanteDomicilio"]), Convert.ToString(dr["CredencialElectorAval"]), Convert.ToString(dr["ComprobanteDomicilioAval"])));
                }

                return list;
            } // End Read

            public static Documentacion Read(int conductor)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Conductor", conductor);
                DataTable dt = DB.Select("Documentacion", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Documentacion con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Documentacion(Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Solicitud"]), Convert.ToString(dr["ActaNacimiento"]), Convert.ToString(dr["CredencialElector"]), Convert.ToString(dr["CartaNoAntecedentes"]), Convert.ToString(dr["ComprobanteDomicilio"]), Convert.ToString(dr["CredencialElectorAval"]), Convert.ToString(dr["ComprobanteDomicilioAval"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Conductor", this.Conductor);
                if (!AppHelper.IsNullOrEmpty(this.Solicitud)) m_params.Add("Solicitud", this.Solicitud);
                if (!AppHelper.IsNullOrEmpty(this.ActaNacimiento)) m_params.Add("ActaNacimiento", this.ActaNacimiento);
                if (!AppHelper.IsNullOrEmpty(this.CredencialElector)) m_params.Add("CredencialElector", this.CredencialElector);
                if (!AppHelper.IsNullOrEmpty(this.CartaNoAntecedentes)) m_params.Add("CartaNoAntecedentes", this.CartaNoAntecedentes);
                if (!AppHelper.IsNullOrEmpty(this.ComprobanteDomicilio)) m_params.Add("ComprobanteDomicilio", this.ComprobanteDomicilio);
                if (!AppHelper.IsNullOrEmpty(this.CredencialElectorAval)) m_params.Add("CredencialElectorAval", this.CredencialElectorAval);
                if (!AppHelper.IsNullOrEmpty(this.ComprobanteDomicilioAval)) m_params.Add("ComprobanteDomicilioAval", this.ComprobanteDomicilioAval);

                return DB.UpdateRow("Documentacion", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Conductor", this.Conductor);

                return DB.DeleteRow("Documentacion", w_params);
            } // End Delete

        } //End Class Documentacion

        public class EmpresasClientesTaller
        {

            public EmpresasClientesTaller()
            {
            }

            public EmpresasClientesTaller(int folio, string rfc, string razonsocial, string calle, string numero, string colonia, string municipio, string estado, string codigopostal, string telefono, string correoelectronico, int tipocliente, int status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Rfc = rfc;
                this.RazonSocial = razonsocial;
                this.Calle = calle;
                this.Numero = numero;
                this.Colonia = colonia;
                this.Municipio = municipio;
                this.Estado = estado;
                this.CodigoPostal = codigopostal;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.TipoCliente = tipocliente;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _Numero;
            public string Numero
            {
                get { return _Numero; }
                set { _Numero = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Municipio;
            public string Municipio
            {
                get { return _Municipio; }
                set { _Municipio = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Municipio", this.Municipio);
                m_params.Add("Estado", this.Estado);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("EmpresasClientesTaller", m_params);
            } // End Create

            public static List<EmpresasClientesTaller> Read()
            {
                List<EmpresasClientesTaller> list = new List<EmpresasClientesTaller>();
                DataTable dt = DB.Select("EmpresasClientesTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new EmpresasClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Municipio"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static EmpresasClientesTaller Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("EmpresasClientesTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe EmpresasClientesTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new EmpresasClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Municipio"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Municipio", this.Municipio);
                m_params.Add("Estado", this.Estado);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("EmpresasClientesTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("EmpresasClientesTaller", w_params);
            } // End Delete

        } //End Class EmpresasClientesTaller

        public class EmpresasConcesionarias
        {

            public EmpresasConcesionarias()
            {
            }

            public EmpresasConcesionarias(int folio, string descripcion, string razonsocial, string rfc, string direccion, string codigopostal, string telefono, string contacto, string correoelectronico, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.RazonSocial = razonsocial;
                this.RFC = rfc;
                this.Direccion = direccion;
                this.CodigoPostal = codigopostal;
                this.Telefono = telefono;
                this.Contacto = contacto;
                this.CorreoElectronico = correoelectronico;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _RFC;
            public string RFC
            {
                get { return _RFC; }
                set { _RFC = value; }
            }

            private string _Direccion;
            public string Direccion
            {
                get { return _Direccion; }
                set { _Direccion = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _Contacto;
            public string Contacto
            {
                get { return _Contacto; }
                set { _Contacto = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("EmpresasConcesionarias", m_params);
            } // End Create

            public static List<EmpresasConcesionarias> Read()
            {
                List<EmpresasConcesionarias> list = new List<EmpresasConcesionarias>();
                DataTable dt = DB.Select("EmpresasConcesionarias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new EmpresasConcesionarias(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static EmpresasConcesionarias Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("EmpresasConcesionarias", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe EmpresasConcesionarias con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new EmpresasConcesionarias(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("EmpresasConcesionarias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("EmpresasConcesionarias", w_params);
            } // End Delete

        } //End Class EmpresasConcesionarias

        public class EmpresasEstaciones
        {

            public EmpresasEstaciones()
            {
            }

            public EmpresasEstaciones(int folio, string descripcion, string razonsocial, string rfc, string direccion, string codigopostal, string telefono, string contacto, string correoelectronico, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.RazonSocial = razonsocial;
                this.RFC = rfc;
                this.Direccion = direccion;
                this.CodigoPostal = codigopostal;
                this.Telefono = telefono;
                this.Contacto = contacto;
                this.CorreoElectronico = correoelectronico;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _RFC;
            public string RFC
            {
                get { return _RFC; }
                set { _RFC = value; }
            }

            private string _Direccion;
            public string Direccion
            {
                get { return _Direccion; }
                set { _Direccion = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _Contacto;
            public string Contacto
            {
                get { return _Contacto; }
                set { _Contacto = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("EmpresasEstaciones", m_params);
            } // End Create

            public static List<EmpresasEstaciones> Read()
            {
                List<EmpresasEstaciones> list = new List<EmpresasEstaciones>();
                DataTable dt = DB.Select("EmpresasEstaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new EmpresasEstaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static EmpresasEstaciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("EmpresasEstaciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe EmpresasEstaciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new EmpresasEstaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("EmpresasEstaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("EmpresasEstaciones", w_params);
            } // End Delete

        } //End Class EmpresasEstaciones

        public class EmpresasOperativas
        {

            public EmpresasOperativas()
            {
            }

            public EmpresasOperativas(int folio, string descripcion, string razonsocial, string rfc, string direccion, string codigopostal, string telefono, string contacto, string correoelectronico, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.RazonSocial = razonsocial;
                this.RFC = rfc;
                this.Direccion = direccion;
                this.CodigoPostal = codigopostal;
                this.Telefono = telefono;
                this.Contacto = contacto;
                this.CorreoElectronico = correoelectronico;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _RFC;
            public string RFC
            {
                get { return _RFC; }
                set { _RFC = value; }
            }

            private string _Direccion;
            public string Direccion
            {
                get { return _Direccion; }
                set { _Direccion = value; }
            }

            private string _CodigoPostal;
            public string CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _Contacto;
            public string Contacto
            {
                get { return _Contacto; }
                set { _Contacto = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("EmpresasOperativas", m_params);
            } // End Create

            public static List<EmpresasOperativas> Read()
            {
                List<EmpresasOperativas> list = new List<EmpresasOperativas>();
                DataTable dt = DB.Select("EmpresasOperativas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new EmpresasOperativas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static EmpresasOperativas Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("EmpresasOperativas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe EmpresasOperativas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new EmpresasOperativas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["RFC"]), Convert.ToString(dr["Direccion"]), Convert.ToString(dr["CodigoPostal"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["Contacto"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("RFC", this.RFC);
                m_params.Add("Direccion", this.Direccion);
                if (!AppHelper.IsNullOrEmpty(this.CodigoPostal)) m_params.Add("CodigoPostal", this.CodigoPostal);
                if (!AppHelper.IsNullOrEmpty(this.Telefono)) m_params.Add("Telefono", this.Telefono);
                if (!AppHelper.IsNullOrEmpty(this.Contacto)) m_params.Add("Contacto", this.Contacto);
                if (!AppHelper.IsNullOrEmpty(this.CorreoElectronico)) m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("EmpresasOperativas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("EmpresasOperativas", w_params);
            } // End Delete

        } //End Class EmpresasOperativas

        public class Estaciones
        {

            public Estaciones()
            {
            }

            public Estaciones(int folio, string descripcion, int? status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Status;
            public int? Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Estaciones", m_params);
            } // End Create

            public static List<Estaciones> Read()
            {
                List<Estaciones> list = new List<Estaciones>();
                DataTable dt = DB.Select("Estaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Estaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Estaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Estaciones", w_params);
            } // End Delete

        } //End Class Estaciones

        public class Estados_PlanesDePagos
        {

            public Estados_PlanesDePagos()
            {
            }

            public Estados_PlanesDePagos(int estado_plandepagoid, string nombre)
            {
                this.Estado_PlanDePagoID = estado_plandepagoid;
                this.Nombre = nombre;
            }

            private int _Estado_PlanDePagoID;
            public int Estado_PlanDePagoID
            {
                get { return _Estado_PlanDePagoID; }
                set { _Estado_PlanDePagoID = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Nombre", this.Nombre);

                return DB.InsertRow("Estados_PlanesDePagos", m_params);
            } // End Create

            public static List<Estados_PlanesDePagos> Read()
            {
                List<Estados_PlanesDePagos> list = new List<Estados_PlanesDePagos>();
                DataTable dt = DB.Select("Estados_PlanesDePagos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Estados_PlanesDePagos(Convert.ToInt32(dr["Estado_PlanDePagoID"]), Convert.ToString(dr["Nombre"])));
                }

                return list;
            } // End Read

            public static Estados_PlanesDePagos Read(int estado_plandepagoid)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estado_PlanDePagoID", estado_plandepagoid);
                DataTable dt = DB.Select("Estados_PlanesDePagos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Estados_PlanesDePagos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Estados_PlanesDePagos(Convert.ToInt32(dr["Estado_PlanDePagoID"]), Convert.ToString(dr["Nombre"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Estado_PlanDePagoID", this.Estado_PlanDePagoID);
                m_params.Add("Nombre", this.Nombre);

                return DB.UpdateRow("Estados_PlanesDePagos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estado_PlanDePagoID", this.Estado_PlanDePagoID);

                return DB.DeleteRow("Estados_PlanesDePagos", w_params);
            } // End Delete

        } //End Class Estados_PlanesDePagos

        public class Familias
        {

            public Familias()
            {
            }

            public Familias(int folio, string descripcion, int? locacion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Locacion = locacion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Locacion;
            public int? Locacion
            {
                get { return _Locacion; }
                set { _Locacion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Locacion)) m_params.Add("Locacion", this.Locacion);

                return DB.InsertRow("Familias", m_params);
            } // End Create

            public static List<Familias> Read()
            {
                List<Familias> list = new List<Familias>();
                DataTable dt = DB.Select("Familias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Familias(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Locacion"])));
                }

                return list;
            } // End Read

            public static Familias Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Familias", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Familias con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Familias(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Locacion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Locacion)) m_params.Add("Locacion", this.Locacion);

                return DB.UpdateRow("Familias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Familias", w_params);
            } // End Delete

        } //End Class Familias

        public class FeedSICAS
        {

            public FeedSICAS()
            {
            }

            public FeedSICAS(string title, string link, string description, DateTime? pubdate)
            {
                this.Title = title;
                this.Link = link;
                this.Description = description;
                this.PubDate = pubdate;
            }

            private string _Title;
            public string Title
            {
                get { return _Title; }
                set { _Title = value; }
            }

            private string _Link;
            public string Link
            {
                get { return _Link; }
                set { _Link = value; }
            }

            private string _Description;
            public string Description
            {
                get { return _Description; }
                set { _Description = value; }
            }

            private DateTime? _PubDate;
            public DateTime? PubDate
            {
                get { return _PubDate; }
                set { _PubDate = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Title)) m_params.Add("Title", this.Title);
                if (!AppHelper.IsNullOrEmpty(this.Link)) m_params.Add("Link", this.Link);
                if (!AppHelper.IsNullOrEmpty(this.Description)) m_params.Add("Description", this.Description);
                if (!AppHelper.IsNullOrEmpty(this.PubDate)) m_params.Add("PubDate", this.PubDate);

                return DB.InsertRow("FeedSICAS", m_params);
            } // End Create

            public static List<FeedSICAS> Read()
            {
                List<FeedSICAS> list = new List<FeedSICAS>();
                DataTable dt = DB.Select("FeedSICAS");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new FeedSICAS(Convert.ToString(dr["Title"]), Convert.ToString(dr["Link"]), Convert.ToString(dr["Description"]), DB.GetNullableDateTime(dr["PubDate"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Title)) m_params.Add("Title", this.Title);
                if (!AppHelper.IsNullOrEmpty(this.Link)) m_params.Add("Link", this.Link);
                if (!AppHelper.IsNullOrEmpty(this.Description)) m_params.Add("Description", this.Description);
                if (!AppHelper.IsNullOrEmpty(this.PubDate)) m_params.Add("PubDate", this.PubDate);

                return DB.UpdateRow("FeedSICAS", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("FeedSICAS", w_params);
            } // End Delete

        } //End Class FeedSICAS

        public class FondosCaja
        {

            public FondosCaja()
            {
            }

            public FondosCaja(int folio, string empresa, string cuentabancaria)
            {
                this.Folio = folio;
                this.Empresa = empresa;
                this.CuentaBancaria = cuentabancaria;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Empresa;
            public string Empresa
            {
                get { return _Empresa; }
                set { _Empresa = value; }
            }

            private string _CuentaBancaria;
            public string CuentaBancaria
            {
                get { return _CuentaBancaria; }
                set { _CuentaBancaria = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Empresa", this.Empresa);
                m_params.Add("CuentaBancaria", this.CuentaBancaria);

                return DB.InsertRow("FondosCaja", m_params);
            } // End Create

            public static List<FondosCaja> Read()
            {
                List<FondosCaja> list = new List<FondosCaja>();
                DataTable dt = DB.Select("FondosCaja");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new FondosCaja(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Empresa"]), Convert.ToString(dr["CuentaBancaria"])));
                }

                return list;
            } // End Read

            public static FondosCaja Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("FondosCaja", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe FondosCaja con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new FondosCaja(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Empresa"]), Convert.ToString(dr["CuentaBancaria"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Empresa", this.Empresa);
                m_params.Add("CuentaBancaria", this.CuentaBancaria);

                return DB.UpdateRow("FondosCaja", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("FondosCaja", w_params);
            } // End Delete

        } //End Class FondosCaja

        public class FondosResiduales
        {

            public FondosResiduales()
            {
            }

            public FondosResiduales(int folio, int caja, int sesioncaja, int conductor, int unidad, int plancobro, decimal porcentaje, decimal monto, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Caja = caja;
                this.SesionCaja = sesioncaja;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.PlanCobro = plancobro;
                this.Porcentaje = porcentaje;
                this.Monto = monto;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Caja;
            public int Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private int _SesionCaja;
            public int SesionCaja
            {
                get { return _SesionCaja; }
                set { _SesionCaja = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _PlanCobro;
            public int PlanCobro
            {
                get { return _PlanCobro; }
                set { _PlanCobro = value; }
            }

            private decimal _Porcentaje;
            public decimal Porcentaje
            {
                get { return _Porcentaje; }
                set { _Porcentaje = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Caja", this.Caja);
                m_params.Add("SesionCaja", this.SesionCaja);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Porcentaje", this.Porcentaje);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("FondosResiduales", m_params);
            } // End Create

            public static List<FondosResiduales> Read()
            {
                List<FondosResiduales> list = new List<FondosResiduales>();
                DataTable dt = DB.Select("FondosResiduales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new FondosResiduales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Caja"]), Convert.ToInt32(dr["SesionCaja"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["PlanCobro"]), Convert.ToDecimal(dr["Porcentaje"]), Convert.ToDecimal(dr["Monto"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static FondosResiduales Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("FondosResiduales", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe FondosResiduales con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new FondosResiduales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Caja"]), Convert.ToInt32(dr["SesionCaja"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["PlanCobro"]), Convert.ToDecimal(dr["Porcentaje"]), Convert.ToDecimal(dr["Monto"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Caja", this.Caja);
                m_params.Add("SesionCaja", this.SesionCaja);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Porcentaje", this.Porcentaje);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("FondosResiduales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("FondosResiduales", w_params);
            } // End Delete

        } //End Class FondosResiduales

        public class HistorialConductor
        {

            public HistorialConductor()
            {
            }

            public HistorialConductor(int folio, int conductor, string accion, string comentario, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Accion = accion;
                this.Comentario = comentario;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private string _Accion;
            public string Accion
            {
                get { return _Accion; }
                set { _Accion = value; }
            }

            private string _Comentario;
            public string Comentario
            {
                get { return _Comentario; }
                set { _Comentario = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Accion", this.Accion);
                m_params.Add("Comentario", this.Comentario);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("HistorialConductor", m_params);
            } // End Create

            public static List<HistorialConductor> Read()
            {
                List<HistorialConductor> list = new List<HistorialConductor>();
                DataTable dt = DB.Select("HistorialConductor");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new HistorialConductor(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Accion"]), Convert.ToString(dr["Comentario"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static HistorialConductor Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("HistorialConductor", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe HistorialConductor con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new HistorialConductor(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToString(dr["Accion"]), Convert.ToString(dr["Comentario"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Accion", this.Accion);
                m_params.Add("Comentario", this.Comentario);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("HistorialConductor", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("HistorialConductor", w_params);
            } // End Delete

        } //End Class HistorialConductor

        public class HistorialInventario
        {

            public HistorialInventario()
            {
            }

            public HistorialInventario(string movimiento, string clase, string tipo, string folio, DateTime fecha, int refaccion, int marca, int proveedor, int tipoinva, decimal cantidadprev, decimal valorprev, decimal cantidad, decimal costounitario, decimal valor, decimal cantidadpost, decimal valorpost, int? notaalmacen, string usuario, string facturaproveedor)
            {
                this.Movimiento = movimiento;
                this.Clase = clase;
                this.Tipo = tipo;
                this.Folio = folio;
                this.Fecha = fecha;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.TipoInva = tipoinva;
                this.CantidadPrev = cantidadprev;
                this.ValorPrev = valorprev;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.CantidadPost = cantidadpost;
                this.ValorPost = valorpost;
                this.NotaAlmacen = notaalmacen;
                this.Usuario = usuario;
                this.FacturaProveedor = facturaproveedor;
            }

            private string _Movimiento;
            public string Movimiento
            {
                get { return _Movimiento; }
                set { _Movimiento = value; }
            }

            private string _Clase;
            public string Clase
            {
                get { return _Clase; }
                set { _Clase = value; }
            }

            private string _Tipo;
            public string Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private string _Folio;
            public string Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _TipoInva;
            public int TipoInva
            {
                get { return _TipoInva; }
                set { _TipoInva = value; }
            }

            private decimal _CantidadPrev;
            public decimal CantidadPrev
            {
                get { return _CantidadPrev; }
                set { _CantidadPrev = value; }
            }

            private decimal _ValorPrev;
            public decimal ValorPrev
            {
                get { return _ValorPrev; }
                set { _ValorPrev = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal _Valor;
            public decimal Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private decimal _CantidadPost;
            public decimal CantidadPost
            {
                get { return _CantidadPost; }
                set { _CantidadPost = value; }
            }

            private decimal _ValorPost;
            public decimal ValorPost
            {
                get { return _ValorPost; }
                set { _ValorPost = value; }
            }

            private int? _NotaAlmacen;
            public int? NotaAlmacen
            {
                get { return _NotaAlmacen; }
                set { _NotaAlmacen = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _FacturaProveedor;
            public string FacturaProveedor
            {
                get { return _FacturaProveedor; }
                set { _FacturaProveedor = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Clase", this.Clase);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("TipoInva", this.TipoInva);
                m_params.Add("CantidadPrev", this.CantidadPrev);
                m_params.Add("ValorPrev", this.ValorPrev);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("CantidadPost", this.CantidadPost);
                m_params.Add("ValorPost", this.ValorPost);
                if (!AppHelper.IsNullOrEmpty(this.NotaAlmacen)) m_params.Add("NotaAlmacen", this.NotaAlmacen);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.FacturaProveedor)) m_params.Add("FacturaProveedor", this.FacturaProveedor);

                return DB.InsertRow("HistorialInventario", m_params);
            } // End Create

            public static List<HistorialInventario> Read()
            {
                List<HistorialInventario> list = new List<HistorialInventario>();
                DataTable dt = DB.Select("HistorialInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new HistorialInventario(Convert.ToString(dr["Movimiento"]), Convert.ToString(dr["Clase"]), Convert.ToString(dr["Tipo"]), Convert.ToString(dr["Folio"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["TipoInva"]), Convert.ToDecimal(dr["CantidadPrev"]), Convert.ToDecimal(dr["ValorPrev"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), Convert.ToDecimal(dr["CantidadPost"]), Convert.ToDecimal(dr["ValorPost"]), DB.GetNullableInt32(dr["NotaAlmacen"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["FacturaProveedor"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Movimiento", this.Movimiento);
                m_params.Add("Clase", this.Clase);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("TipoInva", this.TipoInva);
                m_params.Add("CantidadPrev", this.CantidadPrev);
                m_params.Add("ValorPrev", this.ValorPrev);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("CantidadPost", this.CantidadPost);
                m_params.Add("ValorPost", this.ValorPost);
                if (!AppHelper.IsNullOrEmpty(this.NotaAlmacen)) m_params.Add("NotaAlmacen", this.NotaAlmacen);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.FacturaProveedor)) m_params.Add("FacturaProveedor", this.FacturaProveedor);

                return DB.UpdateRow("HistorialInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("HistorialInventario", w_params);
            } // End Delete

        } //End Class HistorialInventario

        public class HoraComida
        {

            public HoraComida()
            {
            }

            public HoraComida(char? horainicio, char? horafin)
            {
                this.HoraInicio = horainicio;
                this.HoraFin = horafin;
            }

            private char? _HoraInicio;
            public char? HoraInicio
            {
                get { return _HoraInicio; }
                set { _HoraInicio = value; }
            }

            private char? _HoraFin;
            public char? HoraFin
            {
                get { return _HoraFin; }
                set { _HoraFin = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.HoraInicio)) m_params.Add("HoraInicio", this.HoraInicio);
                if (!AppHelper.IsNullOrEmpty(this.HoraFin)) m_params.Add("HoraFin", this.HoraFin);

                return DB.InsertRow("HoraComida", m_params);
            } // End Create

            public static List<HoraComida> Read()
            {
                List<HoraComida> list = new List<HoraComida>();
                DataTable dt = DB.Select("HoraComida");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new HoraComida(DB.GetNullableChar(dr["HoraInicio"]), DB.GetNullableChar(dr["HoraFin"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.HoraInicio)) m_params.Add("HoraInicio", this.HoraInicio);
                if (!AppHelper.IsNullOrEmpty(this.HoraFin)) m_params.Add("HoraFin", this.HoraFin);

                return DB.UpdateRow("HoraComida", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("HoraComida", w_params);
            } // End Delete

        } //End Class HoraComida

        public class Impuestos
        {

            public Impuestos()
            {
            }

            public Impuestos(decimal iva)
            {
                this.IVA = iva;
            }

            private decimal _IVA;
            public decimal IVA
            {
                get { return _IVA; }
                set { _IVA = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("IVA", this.IVA);

                return DB.InsertRow("Impuestos", m_params);
            } // End Create

            public static List<Impuestos> Read()
            {
                List<Impuestos> list = new List<Impuestos>();
                DataTable dt = DB.Select("Impuestos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Impuestos(Convert.ToDecimal(dr["IVA"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("IVA", this.IVA);

                return DB.UpdateRow("Impuestos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Impuestos", w_params);
            } // End Delete

        } //End Class Impuestos

        public class Inventario
        {

            public Inventario()
            {
            }

            public Inventario(string refaccion, int proveedor, int marca, int tipo, decimal cantidad, decimal costo)
            {
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.Costo = costo;
            }

            private string _Refaccion;
            public string Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _Costo;
            public decimal Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Costo", this.Costo);

                return DB.InsertRow("Inventario", m_params);
            } // End Create

            public static List<Inventario> Read()
            {
                List<Inventario> list = new List<Inventario>();
                DataTable dt = DB.Select("Inventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Inventario(Convert.ToString(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["Costo"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Costo", this.Costo);

                return DB.UpdateRow("Inventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Inventario", w_params);
            } // End Delete

        } //End Class Inventario

        public class InventarioPEPS
        {

            public InventarioPEPS()
            {
            }

            public InventarioPEPS(int refaccion, int marca, int proveedor, int tipo, decimal cantidad, decimal costounitario, decimal valor, int anno, int mes, DateTime? fechaentrada)
            {
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.Anno = anno;
                this.Mes = mes;
                this.FechaEntrada = fechaentrada;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal _Valor;
            public decimal Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private int _Anno;
            public int Anno
            {
                get { return _Anno; }
                set { _Anno = value; }
            }

            private int _Mes;
            public int Mes
            {
                get { return _Mes; }
                set { _Mes = value; }
            }

            private DateTime? _FechaEntrada;
            public DateTime? FechaEntrada
            {
                get { return _FechaEntrada; }
                set { _FechaEntrada = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.FechaEntrada)) m_params.Add("FechaEntrada", this.FechaEntrada);

                return DB.InsertRow("InventarioPEPS", m_params);
            } // End Create

            public static List<InventarioPEPS> Read()
            {
                List<InventarioPEPS> list = new List<InventarioPEPS>();
                DataTable dt = DB.Select("InventarioPEPS");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new InventarioPEPS(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), DB.GetNullableDateTime(dr["FechaEntrada"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.FechaEntrada)) m_params.Add("FechaEntrada", this.FechaEntrada);

                return DB.UpdateRow("InventarioPEPS", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("InventarioPEPS", w_params);
            } // End Delete

        } //End Class InventarioPEPS

        public class InventarioPromedio
        {

            public InventarioPromedio()
            {
            }

            public InventarioPromedio(int refaccion, int marca, int proveedor, int tipo, decimal cantidad, decimal costounitario, decimal valor, int anno, int mes, DateTime? fechamovimiento)
            {
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.Anno = anno;
                this.Mes = mes;
                this.FechaMovimiento = fechamovimiento;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal _Valor;
            public decimal Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private int _Anno;
            public int Anno
            {
                get { return _Anno; }
                set { _Anno = value; }
            }

            private int _Mes;
            public int Mes
            {
                get { return _Mes; }
                set { _Mes = value; }
            }

            private DateTime? _FechaMovimiento;
            public DateTime? FechaMovimiento
            {
                get { return _FechaMovimiento; }
                set { _FechaMovimiento = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.FechaMovimiento)) m_params.Add("FechaMovimiento", this.FechaMovimiento);

                return DB.InsertRow("InventarioPromedio", m_params);
            } // End Create

            public static List<InventarioPromedio> Read()
            {
                List<InventarioPromedio> list = new List<InventarioPromedio>();
                DataTable dt = DB.Select("InventarioPromedio");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new InventarioPromedio(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToDecimal(dr["Valor"]), Convert.ToInt32(dr["Anno"]), Convert.ToInt32(dr["Mes"]), DB.GetNullableDateTime(dr["FechaMovimiento"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Valor", this.Valor);
                m_params.Add("Anno", this.Anno);
                m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.FechaMovimiento)) m_params.Add("FechaMovimiento", this.FechaMovimiento);

                return DB.UpdateRow("InventarioPromedio", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("InventarioPromedio", w_params);
            } // End Delete

        } //End Class InventarioPromedio

        public class InventariosIniciales
        {

            public InventariosIniciales()
            {
            }

            public InventariosIniciales(int? anno, int? mes, int? refaccion, int? marca, int? proveedor, int? tipo, decimal? cantidad, decimal? costounitario, decimal? valor, DateTime? fecha)
            {
                this.Anno = anno;
                this.Mes = mes;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Valor = valor;
                this.Fecha = fecha;
            }

            private int? _Anno;
            public int? Anno
            {
                get { return _Anno; }
                set { _Anno = value; }
            }

            private int? _Mes;
            public int? Mes
            {
                get { return _Mes; }
                set { _Mes = value; }
            }

            private int? _Refaccion;
            public int? Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int? _Proveedor;
            public int? Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int? _Tipo;
            public int? Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal? _Cantidad;
            public decimal? Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal? _CostoUnitario;
            public decimal? CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal? _Valor;
            public decimal? Valor
            {
                get { return _Valor; }
                set { _Valor = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Anno)) m_params.Add("Anno", this.Anno);
                if (!AppHelper.IsNullOrEmpty(this.Mes)) m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Valor)) m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("InventariosIniciales", m_params);
            } // End Create

            public static List<InventariosIniciales> Read()
            {
                List<InventariosIniciales> list = new List<InventariosIniciales>();
                DataTable dt = DB.Select("InventariosIniciales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new InventariosIniciales(DB.GetNullableInt32(dr["Anno"]), DB.GetNullableInt32(dr["Mes"]), DB.GetNullableInt32(dr["Refaccion"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableInt32(dr["Proveedor"]), DB.GetNullableInt32(dr["Tipo"]), DB.GetNullableDecimal(dr["Cantidad"]), DB.GetNullableDecimal(dr["CostoUnitario"]), DB.GetNullableDecimal(dr["Valor"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Anno)) m_params.Add("Anno", this.Anno);
                if (!AppHelper.IsNullOrEmpty(this.Mes)) m_params.Add("Mes", this.Mes);
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Valor)) m_params.Add("Valor", this.Valor);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("InventariosIniciales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("InventariosIniciales", w_params);
            } // End Delete

        } //End Class InventariosIniciales

        public class Inversionistas
        {

            public Inversionistas()
            {
            }

            public Inversionistas(int folio, string rfc, string razonsocial, string curp, string calle, string numerocasa, string colonia, string ciudad, string estado, string pais, int cp, string telefono, string correoelectronico, int status, DateTime fechaalta, string usuarioalta, int personafiscal, int tipo)
            {
                this.Folio = folio;
                this.Rfc = rfc;
                this.RazonSocial = razonsocial;
                this.Curp = curp;
                this.Calle = calle;
                this.NumeroCasa = numerocasa;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CP = cp;
                this.Telefono = telefono;
                this.CorreoElectronico = correoelectronico;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.PersonaFiscal = personafiscal;
                this.Tipo = tipo;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _NumeroCasa;
            public string NumeroCasa
            {
                get { return _NumeroCasa; }
                set { _NumeroCasa = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CP;
            public int CP
            {
                get { return _CP; }
                set { _CP = value; }
            }

            private string _Telefono;
            public string Telefono
            {
                get { return _Telefono; }
                set { _Telefono = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int _PersonaFiscal;
            public int PersonaFiscal
            {
                get { return _PersonaFiscal; }
                set { _PersonaFiscal = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("PersonaFiscal", this.PersonaFiscal);
                m_params.Add("Tipo", this.Tipo);

                return DB.InsertRow("Inversionistas", m_params);
            } // End Create

            public static List<Inversionistas> Read()
            {
                List<Inversionistas> list = new List<Inversionistas>();
                DataTable dt = DB.Select("Inversionistas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Inversionistas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToInt32(dr["PersonaFiscal"]), Convert.ToInt32(dr["Tipo"])));
                }

                return list;
            } // End Read

            public static Inversionistas Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Inversionistas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Inversionistas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Inversionistas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["NumeroCasa"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CP"]), Convert.ToString(dr["Telefono"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToInt32(dr["PersonaFiscal"]), Convert.ToInt32(dr["Tipo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Curp", this.Curp);
                m_params.Add("Calle", this.Calle);
                m_params.Add("NumeroCasa", this.NumeroCasa);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CP", this.CP);
                m_params.Add("Telefono", this.Telefono);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                m_params.Add("PersonaFiscal", this.PersonaFiscal);
                m_params.Add("Tipo", this.Tipo);

                return DB.UpdateRow("Inversionistas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Inversionistas", w_params);
            } // End Delete

        } //End Class Inversionistas

        public class INVNEG18NOV09
        {

            public INVNEG18NOV09()
            {
            }

            public INVNEG18NOV09(int? refaccion, int? proveedor, int? marca, int? tipo, decimal? cantidad, decimal? costo, DateTime? fecha)
            {
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.Costo = costo;
                this.Fecha = fecha;
            }

            private int? _Refaccion;
            public int? Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int? _Proveedor;
            public int? Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int? _Tipo;
            public int? Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal? _Cantidad;
            public decimal? Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal? _Costo;
            public decimal? Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("INVNEG18NOV09", m_params);
            } // End Create

            public static List<INVNEG18NOV09> Read()
            {
                List<INVNEG18NOV09> list = new List<INVNEG18NOV09>();
                DataTable dt = DB.Select("INVNEG18NOV09");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new INVNEG18NOV09(DB.GetNullableInt32(dr["Refaccion"]), DB.GetNullableInt32(dr["Proveedor"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableInt32(dr["Tipo"]), DB.GetNullableDecimal(dr["Cantidad"]), DB.GetNullableDecimal(dr["Costo"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("INVNEG18NOV09", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("INVNEG18NOV09", w_params);
            } // End Delete

        } //End Class INVNEG18NOV09

        //public class IVA
        //{

        //    public IVA()
        //    {
        //    }

        //    public IVA(decimal? iva)
        //    {
        //        this.IVA = iva;
        //    }

        //    private decimal? _IVA;
        //    public decimal? IVA
        //    {
        //        get { return _IVA; }
        //        set { _IVA = value; }
        //    }

        //    public int Create()
        //    {
        //        Hashtable m_params = new Hashtable();
        //        if (!AppHelper.IsNullOrEmpty(this.IVA)) m_params.Add("IVA", this.IVA);

        //        return DB.InsertRow("IVA", m_params);
        //    } // End Create

        //    public static List<IVA> Read()
        //    {
        //        List<IVA> list = new List<IVA>();
        //        DataTable dt = DB.Select("IVA");
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            list.Add(new IVA(DB.GetNullableDecimal(dr["IVA"])));
        //        }

        //        return list;
        //    } // End Read

        //    public int Update()
        //    {
        //        Hashtable m_params = new Hashtable();
        //        Hashtable w_params = new Hashtable();
        //        if (!AppHelper.IsNullOrEmpty(this.IVA)) m_params.Add("IVA", this.IVA);

        //        return DB.UpdateRow("IVA", m_params, w_params);
        //    } // End Update

        //    public int Delete()
        //    {
        //        Hashtable w_params = new Hashtable();

        //        return DB.DeleteRow("IVA", w_params);
        //    } // End Delete

        //} //End Class IVA

        public class KilometrajesRecorridos
        {

            public KilometrajesRecorridos()
            {
            }

            public KilometrajesRecorridos(int? unidad, int? kilometraje, char? fecha)
            {
                this.Unidad = unidad;
                this.Kilometraje = kilometraje;
                this.Fecha = fecha;
            }

            private int? _Unidad;
            public int? Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int? _Kilometraje;
            public int? Kilometraje
            {
                get { return _Kilometraje; }
                set { _Kilometraje = value; }
            }

            private char? _Fecha;
            public char? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Unidad)) m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.Kilometraje)) m_params.Add("Kilometraje", this.Kilometraje);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("KilometrajesRecorridos", m_params);
            } // End Create

            public static List<KilometrajesRecorridos> Read()
            {
                List<KilometrajesRecorridos> list = new List<KilometrajesRecorridos>();
                DataTable dt = DB.Select("KilometrajesRecorridos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new KilometrajesRecorridos(DB.GetNullableInt32(dr["Unidad"]), DB.GetNullableInt32(dr["Kilometraje"]), DB.GetNullableChar(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Unidad)) m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.Kilometraje)) m_params.Add("Kilometraje", this.Kilometraje);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("KilometrajesRecorridos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("KilometrajesRecorridos", w_params);
            } // End Delete

        } //End Class KilometrajesRecorridos

        public class LimiteCrediticio
        {

            public LimiteCrediticio()
            {
            }

            public LimiteCrediticio(int dias)
            {
                this.Dias = dias;
            }

            private int _Dias;
            public int Dias
            {
                get { return _Dias; }
                set { _Dias = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Dias", this.Dias);

                return DB.InsertRow("LimiteCrediticio", m_params);
            } // End Create

            public static List<LimiteCrediticio> Read()
            {
                List<LimiteCrediticio> list = new List<LimiteCrediticio>();
                DataTable dt = DB.Select("LimiteCrediticio");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new LimiteCrediticio(Convert.ToInt32(dr["Dias"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Dias", this.Dias);

                return DB.UpdateRow("LimiteCrediticio", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("LimiteCrediticio", w_params);
            } // End Delete

        } //End Class LimiteCrediticio

        public class LocacionesUnidades
        {

            public LocacionesUnidades()
            {
            }

            public LocacionesUnidades(int folio, string descripcion, int status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("LocacionesUnidades", m_params);
            } // End Create

            public static List<LocacionesUnidades> Read()
            {
                List<LocacionesUnidades> list = new List<LocacionesUnidades>();
                DataTable dt = DB.Select("LocacionesUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new LocacionesUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static LocacionesUnidades Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("LocacionesUnidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe LocacionesUnidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new LocacionesUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("LocacionesUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("LocacionesUnidades", w_params);
            } // End Delete

        } //End Class LocacionesUnidades

        public class Marcas
        {

            public Marcas()
            {
            }

            public Marcas(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Marcas", m_params);
            } // End Create

            public static List<Marcas> Read()
            {
                List<Marcas> list = new List<Marcas>();
                DataTable dt = DB.Select("Marcas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Marcas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Marcas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Marcas", w_params);
            } // End Delete

        } //End Class Marcas

        public class MarcasRefacciones
        {

            public MarcasRefacciones()
            {
            }

            public MarcasRefacciones(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("MarcasRefacciones", m_params);
            } // End Create

            public static List<MarcasRefacciones> Read()
            {
                List<MarcasRefacciones> list = new List<MarcasRefacciones>();
                DataTable dt = DB.Select("MarcasRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MarcasRefacciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static MarcasRefacciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MarcasRefacciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MarcasRefacciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MarcasRefacciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("MarcasRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MarcasRefacciones", w_params);
            } // End Delete

        } //End Class MarcasRefacciones

        public class MarcasRefaccionesMargenes
        {

            public MarcasRefaccionesMargenes()
            {
            }

            public MarcasRefaccionesMargenes(int marcarefaccion, int tipocliente, decimal margenutilidad)
            {
                this.MarcaRefaccion = marcarefaccion;
                this.MarcaRefaccion = marcarefaccion;
                this.TipoCliente = tipocliente;
                this.TipoCliente = tipocliente;
                this.MargenUtilidad = margenutilidad;
            }

            private int _MarcaRefaccion;
            public int MarcaRefaccion
            {
                get { return _MarcaRefaccion; }
                set { _MarcaRefaccion = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private decimal _MargenUtilidad;
            public decimal MargenUtilidad
            {
                get { return _MargenUtilidad; }
                set { _MargenUtilidad = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("MarcaRefaccion", this.MarcaRefaccion);
                m_params.Add("MarcaRefaccion", this.MarcaRefaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("MargenUtilidad", this.MargenUtilidad);

                return DB.InsertRow("MarcasRefaccionesMargenes", m_params);
            } // End Create

            public static List<MarcasRefaccionesMargenes> Read()
            {
                List<MarcasRefaccionesMargenes> list = new List<MarcasRefaccionesMargenes>();
                DataTable dt = DB.Select("MarcasRefaccionesMargenes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MarcasRefaccionesMargenes(Convert.ToInt32(dr["MarcaRefaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["MargenUtilidad"])));
                }

                return list;
            } // End Read

            public static MarcasRefaccionesMargenes Read(int marcarefaccion, int tipocliente)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("MarcaRefaccion", marcarefaccion);
                w_params.Add("TipoCliente", tipocliente);
                DataTable dt = DB.Select("MarcasRefaccionesMargenes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MarcasRefaccionesMargenes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MarcasRefaccionesMargenes(Convert.ToInt32(dr["MarcaRefaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["MargenUtilidad"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("MarcaRefaccion", this.MarcaRefaccion);
                w_params.Add("MarcaRefaccion", this.MarcaRefaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                w_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("MargenUtilidad", this.MargenUtilidad);

                return DB.UpdateRow("MarcasRefaccionesMargenes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("MarcaRefaccion", this.MarcaRefaccion);
                w_params.Add("TipoCliente", this.TipoCliente);

                return DB.DeleteRow("MarcasRefaccionesMargenes", w_params);
            } // End Delete

        } //End Class MarcasRefaccionesMargenes

        public class Mecanicos
        {

            public Mecanicos()
            {
            }

            public Mecanicos(int folio, string codigobarras, string nombre, string apellidopaterno, string apellidomaterno, string rfc, string curp, string numerosegurosocial, string calle, string numero, string colonia, string ciudad, string estado, string pais, int codigopostal, string telefonos, string correoelectronico, int categoria, decimal salariodiario, char horarioentrada, char horariosalida, int status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.CodigoBarras = codigobarras;
                this.Nombre = nombre;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Rfc = rfc;
                this.Curp = curp;
                this.NumeroSeguroSocial = numerosegurosocial;
                this.Calle = calle;
                this.Numero = numero;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.Pais = pais;
                this.CodigoPostal = codigopostal;
                this.Telefonos = telefonos;
                this.CorreoElectronico = correoelectronico;
                this.Categoria = categoria;
                this.SalarioDiario = salariodiario;
                this.HorarioEntrada = horarioentrada;
                this.HorarioSalida = horariosalida;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _CodigoBarras;
            public string CodigoBarras
            {
                get { return _CodigoBarras; }
                set { _CodigoBarras = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _Curp;
            public string Curp
            {
                get { return _Curp; }
                set { _Curp = value; }
            }

            private string _NumeroSeguroSocial;
            public string NumeroSeguroSocial
            {
                get { return _NumeroSeguroSocial; }
                set { _NumeroSeguroSocial = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _Numero;
            public string Numero
            {
                get { return _Numero; }
                set { _Numero = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Pais;
            public string Pais
            {
                get { return _Pais; }
                set { _Pais = value; }
            }

            private int _CodigoPostal;
            public int CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefonos;
            public string Telefonos
            {
                get { return _Telefonos; }
                set { _Telefonos = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private int _Categoria;
            public int Categoria
            {
                get { return _Categoria; }
                set { _Categoria = value; }
            }

            private decimal _SalarioDiario;
            public decimal SalarioDiario
            {
                get { return _SalarioDiario; }
                set { _SalarioDiario = value; }
            }

            private char _HorarioEntrada;
            public char HorarioEntrada
            {
                get { return _HorarioEntrada; }
                set { _HorarioEntrada = value; }
            }

            private char _HorarioSalida;
            public char HorarioSalida
            {
                get { return _HorarioSalida; }
                set { _HorarioSalida = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.CodigoBarras)) m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("Curp", this.Curp);
                m_params.Add("NumeroSeguroSocial", this.NumeroSeguroSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Categoria", this.Categoria);
                m_params.Add("SalarioDiario", this.SalarioDiario);
                m_params.Add("HorarioEntrada", this.HorarioEntrada);
                m_params.Add("HorarioSalida", this.HorarioSalida);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Mecanicos", m_params);
            } // End Create

            public static List<Mecanicos> Read()
            {
                List<Mecanicos> list = new List<Mecanicos>();
                DataTable dt = DB.Select("Mecanicos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Mecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["NumeroSeguroSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Categoria"]), Convert.ToDecimal(dr["SalarioDiario"]), Convert.ToChar(dr["HorarioEntrada"]), Convert.ToChar(dr["HorarioSalida"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Mecanicos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Mecanicos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Mecanicos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Mecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToString(dr["Nombre"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["Curp"]), Convert.ToString(dr["NumeroSeguroSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToString(dr["Pais"]), Convert.ToInt32(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToInt32(dr["Categoria"]), Convert.ToDecimal(dr["SalarioDiario"]), Convert.ToChar(dr["HorarioEntrada"]), Convert.ToChar(dr["HorarioSalida"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.CodigoBarras)) m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("Curp", this.Curp);
                m_params.Add("NumeroSeguroSocial", this.NumeroSeguroSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Pais", this.Pais);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Categoria", this.Categoria);
                m_params.Add("SalarioDiario", this.SalarioDiario);
                m_params.Add("HorarioEntrada", this.HorarioEntrada);
                m_params.Add("HorarioSalida", this.HorarioSalida);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Mecanicos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Mecanicos", w_params);
            } // End Delete

        } //End Class Mecanicos

        public class MediosPublicitarios
        {

            public MediosPublicitarios()
            {
            }

            public MediosPublicitarios(int folio, int clasepublicidad, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.ClasePublicidad = clasepublicidad;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _ClasePublicidad;
            public int ClasePublicidad
            {
                get { return _ClasePublicidad; }
                set { _ClasePublicidad = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("ClasePublicidad", this.ClasePublicidad);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("MediosPublicitarios", m_params);
            } // End Create

            public static List<MediosPublicitarios> Read()
            {
                List<MediosPublicitarios> list = new List<MediosPublicitarios>();
                DataTable dt = DB.Select("MediosPublicitarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MediosPublicitarios(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["ClasePublicidad"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static MediosPublicitarios Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MediosPublicitarios", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MediosPublicitarios con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MediosPublicitarios(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["ClasePublicidad"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("ClasePublicidad", this.ClasePublicidad);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("MediosPublicitarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MediosPublicitarios", w_params);
            } // End Delete

        } //End Class MediosPublicitarios

        public class Modelos
        {

            public Modelos()
            {
            }

            public Modelos(int folio, string marca, string descripcion, decimal? preciolista, int año, decimal? deposito, int? status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Marca = marca;
                this.Descripcion = descripcion;
                this.PrecioLista = preciolista;
                this.Año = año;
                this.Deposito = deposito;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Marca;
            public string Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private decimal? _PrecioLista;
            public decimal? PrecioLista
            {
                get { return _PrecioLista; }
                set { _PrecioLista = value; }
            }

            private int _Año;
            public int Año
            {
                get { return _Año; }
                set { _Año = value; }
            }

            private decimal? _Deposito;
            public decimal? Deposito
            {
                get { return _Deposito; }
                set { _Deposito = value; }
            }

            private int? _Status;
            public int? Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.PrecioLista)) m_params.Add("PrecioLista", this.PrecioLista);
                m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Deposito)) m_params.Add("Deposito", this.Deposito);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Modelos", m_params);
            } // End Create

            public static List<Modelos> Read()
            {
                List<Modelos> list = new List<Modelos>();
                DataTable dt = DB.Select("Modelos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Modelos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Marca"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableDecimal(dr["PrecioLista"]), Convert.ToInt32(dr["Año"]), DB.GetNullableDecimal(dr["Deposito"]), DB.GetNullableInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.PrecioLista)) m_params.Add("PrecioLista", this.PrecioLista);
                m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Deposito)) m_params.Add("Deposito", this.Deposito);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Modelos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Modelos", w_params);
            } // End Delete

        } //End Class Modelos

        public class ModelosTaller
        {

            public ModelosTaller()
            {
            }

            public ModelosTaller(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("ModelosTaller", m_params);
            } // End Create

            public static List<ModelosTaller> Read()
            {
                List<ModelosTaller> list = new List<ModelosTaller>();
                DataTable dt = DB.Select("ModelosTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ModelosTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static ModelosTaller Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ModelosTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ModelosTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ModelosTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("ModelosTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ModelosTaller", w_params);
            } // End Delete

        } //End Class ModelosTaller

        public class MonitorInventario
        {

            public MonitorInventario()
            {
            }

            public MonitorInventario(int folio, DateTime fecha, int? refaccionoldvalue, int? proveedoroldvalue, int? marcaoldvalue, int? tipooldvalue, int? cantidadoldvalue, decimal? costooldvalue, int refaccionnewvalue, int proveedornewvalue, int marcanewvalue, int tiponewvalue, int cantidadnewvalue, decimal costonewvalue)
            {
                this.Folio = folio;
                this.Fecha = fecha;
                this.RefaccionOldValue = refaccionoldvalue;
                this.ProveedorOldValue = proveedoroldvalue;
                this.MarcaOldValue = marcaoldvalue;
                this.TipoOldValue = tipooldvalue;
                this.CantidadOldValue = cantidadoldvalue;
                this.CostoOldValue = costooldvalue;
                this.RefaccionNewValue = refaccionnewvalue;
                this.ProveedorNewValue = proveedornewvalue;
                this.MarcaNewValue = marcanewvalue;
                this.TipoNewValue = tiponewvalue;
                this.CantidadNewValue = cantidadnewvalue;
                this.CostoNewValue = costonewvalue;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private int? _RefaccionOldValue;
            public int? RefaccionOldValue
            {
                get { return _RefaccionOldValue; }
                set { _RefaccionOldValue = value; }
            }

            private int? _ProveedorOldValue;
            public int? ProveedorOldValue
            {
                get { return _ProveedorOldValue; }
                set { _ProveedorOldValue = value; }
            }

            private int? _MarcaOldValue;
            public int? MarcaOldValue
            {
                get { return _MarcaOldValue; }
                set { _MarcaOldValue = value; }
            }

            private int? _TipoOldValue;
            public int? TipoOldValue
            {
                get { return _TipoOldValue; }
                set { _TipoOldValue = value; }
            }

            private int? _CantidadOldValue;
            public int? CantidadOldValue
            {
                get { return _CantidadOldValue; }
                set { _CantidadOldValue = value; }
            }

            private decimal? _CostoOldValue;
            public decimal? CostoOldValue
            {
                get { return _CostoOldValue; }
                set { _CostoOldValue = value; }
            }

            private int _RefaccionNewValue;
            public int RefaccionNewValue
            {
                get { return _RefaccionNewValue; }
                set { _RefaccionNewValue = value; }
            }

            private int _ProveedorNewValue;
            public int ProveedorNewValue
            {
                get { return _ProveedorNewValue; }
                set { _ProveedorNewValue = value; }
            }

            private int _MarcaNewValue;
            public int MarcaNewValue
            {
                get { return _MarcaNewValue; }
                set { _MarcaNewValue = value; }
            }

            private int _TipoNewValue;
            public int TipoNewValue
            {
                get { return _TipoNewValue; }
                set { _TipoNewValue = value; }
            }

            private int _CantidadNewValue;
            public int CantidadNewValue
            {
                get { return _CantidadNewValue; }
                set { _CantidadNewValue = value; }
            }

            private decimal _CostoNewValue;
            public decimal CostoNewValue
            {
                get { return _CostoNewValue; }
                set { _CostoNewValue = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.RefaccionOldValue)) m_params.Add("RefaccionOldValue", this.RefaccionOldValue);
                if (!AppHelper.IsNullOrEmpty(this.ProveedorOldValue)) m_params.Add("ProveedorOldValue", this.ProveedorOldValue);
                if (!AppHelper.IsNullOrEmpty(this.MarcaOldValue)) m_params.Add("MarcaOldValue", this.MarcaOldValue);
                if (!AppHelper.IsNullOrEmpty(this.TipoOldValue)) m_params.Add("TipoOldValue", this.TipoOldValue);
                if (!AppHelper.IsNullOrEmpty(this.CantidadOldValue)) m_params.Add("CantidadOldValue", this.CantidadOldValue);
                if (!AppHelper.IsNullOrEmpty(this.CostoOldValue)) m_params.Add("CostoOldValue", this.CostoOldValue);
                m_params.Add("RefaccionNewValue", this.RefaccionNewValue);
                m_params.Add("ProveedorNewValue", this.ProveedorNewValue);
                m_params.Add("MarcaNewValue", this.MarcaNewValue);
                m_params.Add("TipoNewValue", this.TipoNewValue);
                m_params.Add("CantidadNewValue", this.CantidadNewValue);
                m_params.Add("CostoNewValue", this.CostoNewValue);

                return DB.InsertRow("MonitorInventario", m_params);
            } // End Create

            public static List<MonitorInventario> Read()
            {
                List<MonitorInventario> list = new List<MonitorInventario>();
                DataTable dt = DB.Select("MonitorInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MonitorInventario(Convert.ToInt32(dr["Folio"]), Convert.ToDateTime(dr["Fecha"]), DB.GetNullableInt32(dr["RefaccionOldValue"]), DB.GetNullableInt32(dr["ProveedorOldValue"]), DB.GetNullableInt32(dr["MarcaOldValue"]), DB.GetNullableInt32(dr["TipoOldValue"]), DB.GetNullableInt32(dr["CantidadOldValue"]), DB.GetNullableDecimal(dr["CostoOldValue"]), Convert.ToInt32(dr["RefaccionNewValue"]), Convert.ToInt32(dr["ProveedorNewValue"]), Convert.ToInt32(dr["MarcaNewValue"]), Convert.ToInt32(dr["TipoNewValue"]), Convert.ToInt32(dr["CantidadNewValue"]), Convert.ToDecimal(dr["CostoNewValue"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.RefaccionOldValue)) m_params.Add("RefaccionOldValue", this.RefaccionOldValue);
                if (!AppHelper.IsNullOrEmpty(this.ProveedorOldValue)) m_params.Add("ProveedorOldValue", this.ProveedorOldValue);
                if (!AppHelper.IsNullOrEmpty(this.MarcaOldValue)) m_params.Add("MarcaOldValue", this.MarcaOldValue);
                if (!AppHelper.IsNullOrEmpty(this.TipoOldValue)) m_params.Add("TipoOldValue", this.TipoOldValue);
                if (!AppHelper.IsNullOrEmpty(this.CantidadOldValue)) m_params.Add("CantidadOldValue", this.CantidadOldValue);
                if (!AppHelper.IsNullOrEmpty(this.CostoOldValue)) m_params.Add("CostoOldValue", this.CostoOldValue);
                m_params.Add("RefaccionNewValue", this.RefaccionNewValue);
                m_params.Add("ProveedorNewValue", this.ProveedorNewValue);
                m_params.Add("MarcaNewValue", this.MarcaNewValue);
                m_params.Add("TipoNewValue", this.TipoNewValue);
                m_params.Add("CantidadNewValue", this.CantidadNewValue);
                m_params.Add("CostoNewValue", this.CostoNewValue);

                return DB.UpdateRow("MonitorInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("MonitorInventario", w_params);
            } // End Delete

        } //End Class MonitorInventario

        public class MotivosBajasConductores
        {

            public MotivosBajasConductores()
            {
            }

            public MotivosBajasConductores(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("MotivosBajasConductores", m_params);
            } // End Create

            public static List<MotivosBajasConductores> Read()
            {
                List<MotivosBajasConductores> list = new List<MotivosBajasConductores>();
                DataTable dt = DB.Select("MotivosBajasConductores");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MotivosBajasConductores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static MotivosBajasConductores Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MotivosBajasConductores", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MotivosBajasConductores con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MotivosBajasConductores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("MotivosBajasConductores", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MotivosBajasConductores", w_params);
            } // End Delete

        } //End Class MotivosBajasConductores

        public class MotivosMovimientosInventario
        {

            public MotivosMovimientosInventario()
            {
            }

            public MotivosMovimientosInventario(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("MotivosMovimientosInventario", m_params);
            } // End Create

            public static List<MotivosMovimientosInventario> Read()
            {
                List<MotivosMovimientosInventario> list = new List<MotivosMovimientosInventario>();
                DataTable dt = DB.Select("MotivosMovimientosInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MotivosMovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static MotivosMovimientosInventario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MotivosMovimientosInventario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MotivosMovimientosInventario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MotivosMovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("MotivosMovimientosInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MotivosMovimientosInventario", w_params);
            } // End Delete

        } //End Class MotivosMovimientosInventario

        public class MotivosReasignacion
        {

            public MotivosReasignacion()
            {
            }

            public MotivosReasignacion(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("MotivosReasignacion", m_params);
            } // End Create

            public static List<MotivosReasignacion> Read()
            {
                List<MotivosReasignacion> list = new List<MotivosReasignacion>();
                DataTable dt = DB.Select("MotivosReasignacion");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MotivosReasignacion(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("MotivosReasignacion", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("MotivosReasignacion", w_params);
            } // End Delete

        } //End Class MotivosReasignacion

        public class MovimientosCaja
        {

            public MovimientosCaja()
            {
            }

            public MovimientosCaja(int folio, int sesion, int fondo, int tipopago, decimal monto, DateTime fecha, string usuario)
            {
                this.Folio = folio;
                this.Sesion = sesion;
                this.Fondo = fondo;
                this.TipoPago = tipopago;
                this.Monto = monto;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Sesion;
            public int Sesion
            {
                get { return _Sesion; }
                set { _Sesion = value; }
            }

            private int _Fondo;
            public int Fondo
            {
                get { return _Fondo; }
                set { _Fondo = value; }
            }

            private int _TipoPago;
            public int TipoPago
            {
                get { return _TipoPago; }
                set { _TipoPago = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Sesion", this.Sesion);
                m_params.Add("Fondo", this.Fondo);
                m_params.Add("TipoPago", this.TipoPago);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("MovimientosCaja", m_params);
            } // End Create

            public static List<MovimientosCaja> Read()
            {
                List<MovimientosCaja> list = new List<MovimientosCaja>();
                DataTable dt = DB.Select("MovimientosCaja");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MovimientosCaja(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Sesion"]), Convert.ToInt32(dr["Fondo"]), Convert.ToInt32(dr["TipoPago"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public static MovimientosCaja Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MovimientosCaja", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MovimientosCaja con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MovimientosCaja(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Sesion"]), Convert.ToInt32(dr["Fondo"]), Convert.ToInt32(dr["TipoPago"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Sesion", this.Sesion);
                m_params.Add("Fondo", this.Fondo);
                m_params.Add("TipoPago", this.TipoPago);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("MovimientosCaja", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MovimientosCaja", w_params);
            } // End Delete

        } //End Class MovimientosCaja

        public class MovimientosDirectosAInventario
        {

            public MovimientosDirectosAInventario()
            {
            }

            public MovimientosDirectosAInventario(int folio, char? tipomovimiento, int? refaccion, int? marca, int? proveedor, int? tipo, decimal? cantidad, decimal? costounitario, decimal? total, DateTime? fecha, string usuario, string comentarios)
            {
                this.Folio = folio;
                this.TipoMovimiento = tipomovimiento;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.CostoUnitario = costounitario;
                this.Total = total;
                this.Fecha = fecha;
                this.Usuario = usuario;
                this.Comentarios = comentarios;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private char? _TipoMovimiento;
            public char? TipoMovimiento
            {
                get { return _TipoMovimiento; }
                set { _TipoMovimiento = value; }
            }

            private int? _Refaccion;
            public int? Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int? _Proveedor;
            public int? Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int? _Tipo;
            public int? Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal? _Cantidad;
            public decimal? Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal? _CostoUnitario;
            public decimal? CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal? _Total;
            public decimal? Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.TipoMovimiento)) m_params.Add("TipoMovimiento", this.TipoMovimiento);
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Total)) m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);

                return DB.InsertRow("MovimientosDirectosAInventario", m_params);
            } // End Create

            public static List<MovimientosDirectosAInventario> Read()
            {
                List<MovimientosDirectosAInventario> list = new List<MovimientosDirectosAInventario>();
                DataTable dt = DB.Select("MovimientosDirectosAInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MovimientosDirectosAInventario(Convert.ToInt32(dr["Folio"]), DB.GetNullableChar(dr["TipoMovimiento"]), DB.GetNullableInt32(dr["Refaccion"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableInt32(dr["Proveedor"]), DB.GetNullableInt32(dr["Tipo"]), DB.GetNullableDecimal(dr["Cantidad"]), DB.GetNullableDecimal(dr["CostoUnitario"]), DB.GetNullableDecimal(dr["Total"]), DB.GetNullableDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"])));
                }

                return list;
            } // End Read

            public static MovimientosDirectosAInventario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MovimientosDirectosAInventario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MovimientosDirectosAInventario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MovimientosDirectosAInventario(Convert.ToInt32(dr["Folio"]), DB.GetNullableChar(dr["TipoMovimiento"]), DB.GetNullableInt32(dr["Refaccion"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableInt32(dr["Proveedor"]), DB.GetNullableInt32(dr["Tipo"]), DB.GetNullableDecimal(dr["Cantidad"]), DB.GetNullableDecimal(dr["CostoUnitario"]), DB.GetNullableDecimal(dr["Total"]), DB.GetNullableDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.TipoMovimiento)) m_params.Add("TipoMovimiento", this.TipoMovimiento);
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.Total)) m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);

                return DB.UpdateRow("MovimientosDirectosAInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MovimientosDirectosAInventario", w_params);
            } // End Delete

        } //End Class MovimientosDirectosAInventario

        public class MovimientosInventario
        {

            public MovimientosInventario()
            {
            }

            public MovimientosInventario(int folio, string refaccion, int proveedor, int marca, int tipo, int cantidad, decimal costo, int motivo, int referencia, int tiporeferencia, DateTime fecha, string usuarioalta)
            {
                this.Folio = folio;
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.Costo = costo;
                this.Motivo = motivo;
                this.Referencia = referencia;
                this.TipoReferencia = tiporeferencia;
                this.Fecha = fecha;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Refaccion;
            public string Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _Costo;
            public decimal Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            private int _Motivo;
            public int Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private int _Referencia;
            public int Referencia
            {
                get { return _Referencia; }
                set { _Referencia = value; }
            }

            private int _TipoReferencia;
            public int TipoReferencia
            {
                get { return _TipoReferencia; }
                set { _TipoReferencia = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Costo", this.Costo);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("TipoReferencia", this.TipoReferencia);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("MovimientosInventario", m_params);
            } // End Create

            public static List<MovimientosInventario> Read()
            {
                List<MovimientosInventario> list = new List<MovimientosInventario>();
                DataTable dt = DB.Select("MovimientosInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new MovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToDecimal(dr["Costo"]), Convert.ToInt32(dr["Motivo"]), Convert.ToInt32(dr["Referencia"]), Convert.ToInt32(dr["TipoReferencia"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static MovimientosInventario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("MovimientosInventario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe MovimientosInventario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new MovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToDecimal(dr["Costo"]), Convert.ToInt32(dr["Motivo"]), Convert.ToInt32(dr["Referencia"]), Convert.ToInt32(dr["TipoReferencia"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Costo", this.Costo);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("TipoReferencia", this.TipoReferencia);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("MovimientosInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("MovimientosInventario", w_params);
            } // End Delete

        } //End Class MovimientosInventario

        public class NotasAlmacen
        {

            public NotasAlmacen()
            {
            }

            public NotasAlmacen(int notaalmacenid, string tipo, int? ordencompra, int? ordentrabajo, string usuario, DateTime fecha)
            {
                this.NotaAlmacenID = notaalmacenid;
                this.Tipo = tipo;
                this.OrdenCompra = ordencompra;
                this.OrdenTrabajo = ordentrabajo;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _NotaAlmacenID;
            public int NotaAlmacenID
            {
                get { return _NotaAlmacenID; }
                set { _NotaAlmacenID = value; }
            }

            private string _Tipo;
            public string Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int? _OrdenCompra;
            public int? OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private int? _OrdenTrabajo;
            public int? OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("NotasAlmacen", m_params);
            } // End Create

            public static List<NotasAlmacen> Read()
            {
                List<NotasAlmacen> list = new List<NotasAlmacen>();
                DataTable dt = DB.Select("NotasAlmacen");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new NotasAlmacen(Convert.ToInt32(dr["NotaAlmacenID"]), Convert.ToString(dr["Tipo"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static NotasAlmacen Read(int notaalmacenid)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("NotaAlmacenID", notaalmacenid);
                DataTable dt = DB.Select("NotasAlmacen", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe NotasAlmacen con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new NotasAlmacen(Convert.ToInt32(dr["NotaAlmacenID"]), Convert.ToString(dr["Tipo"]), DB.GetNullableInt32(dr["OrdenCompra"]), DB.GetNullableInt32(dr["OrdenTrabajo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("NotaAlmacenID", this.NotaAlmacenID);
                m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.OrdenCompra)) m_params.Add("OrdenCompra", this.OrdenCompra);
                if (!AppHelper.IsNullOrEmpty(this.OrdenTrabajo)) m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("NotasAlmacen", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("NotaAlmacenID", this.NotaAlmacenID);

                return DB.DeleteRow("NotasAlmacen", w_params);
            } // End Delete

        } //End Class NotasAlmacen

        public class NumeroEconomicoOT
        {

            public NumeroEconomicoOT()
            {
            }

            public NumeroEconomicoOT(int? ot, int? cliente, int? unidad, int? numeroeconomico)
            {
                this.OT = ot;
                this.Cliente = cliente;
                this.Unidad = unidad;
                this.NumeroEconomico = numeroeconomico;
            }

            private int? _OT;
            public int? OT
            {
                get { return _OT; }
                set { _OT = value; }
            }

            private int? _Cliente;
            public int? Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private int? _Unidad;
            public int? Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int? _NumeroEconomico;
            public int? NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.OT)) m_params.Add("OT", this.OT);
                if (!AppHelper.IsNullOrEmpty(this.Cliente)) m_params.Add("Cliente", this.Cliente);
                if (!AppHelper.IsNullOrEmpty(this.Unidad)) m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);

                return DB.InsertRow("NumeroEconomicoOT", m_params);
            } // End Create

            public static List<NumeroEconomicoOT> Read()
            {
                List<NumeroEconomicoOT> list = new List<NumeroEconomicoOT>();
                DataTable dt = DB.Select("NumeroEconomicoOT");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new NumeroEconomicoOT(DB.GetNullableInt32(dr["OT"]), DB.GetNullableInt32(dr["Cliente"]), DB.GetNullableInt32(dr["Unidad"]), DB.GetNullableInt32(dr["NumeroEconomico"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.OT)) m_params.Add("OT", this.OT);
                if (!AppHelper.IsNullOrEmpty(this.Cliente)) m_params.Add("Cliente", this.Cliente);
                if (!AppHelper.IsNullOrEmpty(this.Unidad)) m_params.Add("Unidad", this.Unidad);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);

                return DB.UpdateRow("NumeroEconomicoOT", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("NumeroEconomicoOT", w_params);
            } // End Delete

        } //End Class NumeroEconomicoOT

        public class OperacionesCaja
        {

            public OperacionesCaja()
            {
            }

            public OperacionesCaja(int folio, int tipoconcepto, int fondocaja, string descripcion)
            {
                this.Folio = folio;
                this.TipoConcepto = tipoconcepto;
                this.FondoCaja = fondocaja;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _TipoConcepto;
            public int TipoConcepto
            {
                get { return _TipoConcepto; }
                set { _TipoConcepto = value; }
            }

            private int _FondoCaja;
            public int FondoCaja
            {
                get { return _FondoCaja; }
                set { _FondoCaja = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("TipoConcepto", this.TipoConcepto);
                m_params.Add("FondoCaja", this.FondoCaja);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("OperacionesCaja", m_params);
            } // End Create

            public static List<OperacionesCaja> Read()
            {
                List<OperacionesCaja> list = new List<OperacionesCaja>();
                DataTable dt = DB.Select("OperacionesCaja");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OperacionesCaja(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["TipoConcepto"]), Convert.ToInt32(dr["FondoCaja"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static OperacionesCaja Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("OperacionesCaja", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OperacionesCaja con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OperacionesCaja(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["TipoConcepto"]), Convert.ToInt32(dr["FondoCaja"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("TipoConcepto", this.TipoConcepto);
                m_params.Add("FondoCaja", this.FondoCaja);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("OperacionesCaja", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("OperacionesCaja", w_params);
            } // End Delete

        } //End Class OperacionesCaja

        public class OrdenesCompras
        {

            public OrdenesCompras()
            {
            }

            public OrdenesCompras(int folio, int tipo, int proveedor, string factura, decimal subtotal, decimal iva, decimal total, DateTime fechaalta, string usuarioalta, int? status)
            {
                this.Folio = folio;
                this.Tipo = tipo;
                this.Proveedor = proveedor;
                this.Factura = factura;
                this.SubTotal = subtotal;
                this.IVA = iva;
                this.Total = total;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.Status = status;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private string _Factura;
            public string Factura
            {
                get { return _Factura; }
                set { _Factura = value; }
            }

            private decimal _SubTotal;
            public decimal SubTotal
            {
                get { return _SubTotal; }
                set { _SubTotal = value; }
            }

            private decimal _IVA;
            public decimal IVA
            {
                get { return _IVA; }
                set { _IVA = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _Status;
            public int? Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Factura", this.Factura);
                m_params.Add("SubTotal", this.SubTotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);

                return DB.InsertRow("OrdenesCompras", m_params);
            } // End Create

            public static List<OrdenesCompras> Read()
            {
                List<OrdenesCompras> list = new List<OrdenesCompras>();
                DataTable dt = DB.Select("OrdenesCompras");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesCompras(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToString(dr["Factura"]), Convert.ToDecimal(dr["SubTotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public static OrdenesCompras Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("OrdenesCompras", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesCompras con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesCompras(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToString(dr["Factura"]), Convert.ToDecimal(dr["SubTotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["Status"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Factura", this.Factura);
                m_params.Add("SubTotal", this.SubTotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Status)) m_params.Add("Status", this.Status);

                return DB.UpdateRow("OrdenesCompras", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("OrdenesCompras", w_params);
            } // End Delete

        } //End Class OrdenesCompras

        public class OrdenesComprasCanceladas
        {

            public OrdenesComprasCanceladas()
            {
            }

            public OrdenesComprasCanceladas(int ordencompra, DateTime fecha, string usuario, string motivos, bool correoenviado)
            {
                this.OrdenCompra = ordencompra;
                this.Fecha = fecha;
                this.Usuario = usuario;
                this.Motivos = motivos;
                this.CorreoEnviado = correoenviado;
            }

            private int _OrdenCompra;
            public int OrdenCompra
            {
                get { return _OrdenCompra; }
                set { _OrdenCompra = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Motivos;
            public string Motivos
            {
                get { return _Motivos; }
                set { _Motivos = value; }
            }

            private bool _CorreoEnviado;
            public bool CorreoEnviado
            {
                get { return _CorreoEnviado; }
                set { _CorreoEnviado = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivos", this.Motivos);
                m_params.Add("CorreoEnviado", this.CorreoEnviado);

                return DB.InsertRow("OrdenesComprasCanceladas", m_params);
            } // End Create

            public static List<OrdenesComprasCanceladas> Read()
            {
                List<OrdenesComprasCanceladas> list = new List<OrdenesComprasCanceladas>();
                DataTable dt = DB.Select("OrdenesComprasCanceladas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesComprasCanceladas(Convert.ToInt32(dr["OrdenCompra"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Motivos"]), Convert.ToBoolean(dr["CorreoEnviado"])));
                }

                return list;
            } // End Read

            public static OrdenesComprasCanceladas Read(int ordencompra)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenCompra", ordencompra);
                DataTable dt = DB.Select("OrdenesComprasCanceladas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesComprasCanceladas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesComprasCanceladas(Convert.ToInt32(dr["OrdenCompra"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Motivos"]), Convert.ToBoolean(dr["CorreoEnviado"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenCompra", this.OrdenCompra);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivos", this.Motivos);
                m_params.Add("CorreoEnviado", this.CorreoEnviado);

                return DB.UpdateRow("OrdenesComprasCanceladas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenCompra", this.OrdenCompra);

                return DB.DeleteRow("OrdenesComprasCanceladas", w_params);
            } // End Delete

        } //End Class OrdenesComprasCanceladas

        public class OrdenesConsesion
        {

            public OrdenesConsesion()
            {
            }

            public OrdenesConsesion(int folio, int proveedor, string folioconsesion, decimal subtotal, decimal iva, decimal total, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Proveedor = proveedor;
                this.FolioConsesion = folioconsesion;
                this.Subtotal = subtotal;
                this.IVA = iva;
                this.Total = total;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private string _FolioConsesion;
            public string FolioConsesion
            {
                get { return _FolioConsesion; }
                set { _FolioConsesion = value; }
            }

            private decimal _Subtotal;
            public decimal Subtotal
            {
                get { return _Subtotal; }
                set { _Subtotal = value; }
            }

            private decimal _IVA;
            public decimal IVA
            {
                get { return _IVA; }
                set { _IVA = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("FolioConsesion", this.FolioConsesion);
                m_params.Add("Subtotal", this.Subtotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("OrdenesConsesion", m_params);
            } // End Create

            public static List<OrdenesConsesion> Read()
            {
                List<OrdenesConsesion> list = new List<OrdenesConsesion>();
                DataTable dt = DB.Select("OrdenesConsesion");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesConsesion(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToString(dr["FolioConsesion"]), Convert.ToDecimal(dr["Subtotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static OrdenesConsesion Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("OrdenesConsesion", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesConsesion con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesConsesion(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToString(dr["FolioConsesion"]), Convert.ToDecimal(dr["Subtotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("FolioConsesion", this.FolioConsesion);
                m_params.Add("Subtotal", this.Subtotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("OrdenesConsesion", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("OrdenesConsesion", w_params);
            } // End Delete

        } //End Class OrdenesConsesion

        public class OrdenesServicio
        {

            public OrdenesServicio()
            {
            }

            public OrdenesServicio(int folio, string codigobarras, int ordentrabajo, int servicio, int mecanico, decimal cantidad, decimal preciounitario, decimal total, int status, DateTime? fechasurtida)
            {
                this.Folio = folio;
                this.CodigoBarras = codigobarras;
                this.OrdenTrabajo = ordentrabajo;
                this.Servicio = servicio;
                this.Mecanico = mecanico;
                this.Cantidad = cantidad;
                this.PrecioUnitario = preciounitario;
                this.Total = total;
                this.Status = status;
                this.FechaSurtida = fechasurtida;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _CodigoBarras;
            public string CodigoBarras
            {
                get { return _CodigoBarras; }
                set { _CodigoBarras = value; }
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _PrecioUnitario;
            public decimal PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime? _FechaSurtida;
            public DateTime? FechaSurtida
            {
                get { return _FechaSurtida; }
                set { _FechaSurtida = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);
                m_params.Add("Status", this.Status);
                if (!AppHelper.IsNullOrEmpty(this.FechaSurtida)) m_params.Add("FechaSurtida", this.FechaSurtida);

                return DB.InsertRow("OrdenesServicio", m_params);
            } // End Create

            public static List<OrdenesServicio> Read()
            {
                List<OrdenesServicio> list = new List<OrdenesServicio>();
                DataTable dt = DB.Select("OrdenesServicio");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesServicio(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToDecimal(dr["Total"]), Convert.ToInt32(dr["Status"]), DB.GetNullableDateTime(dr["FechaSurtida"])));
                }

                return list;
            } // End Read

            public static OrdenesServicio Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("OrdenesServicio", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesServicio con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesServicio(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToDecimal(dr["Total"]), Convert.ToInt32(dr["Status"]), DB.GetNullableDateTime(dr["FechaSurtida"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);
                m_params.Add("Status", this.Status);
                if (!AppHelper.IsNullOrEmpty(this.FechaSurtida)) m_params.Add("FechaSurtida", this.FechaSurtida);

                return DB.UpdateRow("OrdenesServicio", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("OrdenesServicio", w_params);
            } // End Delete

        } //End Class OrdenesServicio

        public class OrdenesServicioRefacciones
        {

            public OrdenesServicioRefacciones()
            {
            }

            public OrdenesServicioRefacciones(int ordenservicio, int refaccion, int marca, int proveedor, int tipo, decimal cantidad, decimal preciounitario, decimal total, decimal? costounitario, decimal? refsurtidas)
            {
                this.OrdenServicio = ordenservicio;
                this.Refaccion = refaccion;
                this.Marca = marca;
                this.Proveedor = proveedor;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.PrecioUnitario = preciounitario;
                this.Total = total;
                this.CostoUnitario = costounitario;
                this.RefSurtidas = refsurtidas;
            }

            private int _OrdenServicio;
            public int OrdenServicio
            {
                get { return _OrdenServicio; }
                set { _OrdenServicio = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _PrecioUnitario;
            public decimal PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private decimal? _CostoUnitario;
            public decimal? CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private decimal? _RefSurtidas;
            public decimal? RefSurtidas
            {
                get { return _RefSurtidas; }
                set { _RefSurtidas = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.RefSurtidas)) m_params.Add("RefSurtidas", this.RefSurtidas);

                return DB.InsertRow("OrdenesServicioRefacciones", m_params);
            } // End Create

            public static List<OrdenesServicioRefacciones> Read()
            {
                List<OrdenesServicioRefacciones> list = new List<OrdenesServicioRefacciones>();
                DataTable dt = DB.Select("OrdenesServicioRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesServicioRefacciones(Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToDecimal(dr["Total"]), DB.GetNullableDecimal(dr["CostoUnitario"]), DB.GetNullableDecimal(dr["RefSurtidas"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.CostoUnitario)) m_params.Add("CostoUnitario", this.CostoUnitario);
                if (!AppHelper.IsNullOrEmpty(this.RefSurtidas)) m_params.Add("RefSurtidas", this.RefSurtidas);

                return DB.UpdateRow("OrdenesServicioRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("OrdenesServicioRefacciones", w_params);
            } // End Delete

        } //End Class OrdenesServicioRefacciones

        public class OrdenesTrabajo
        {

            public OrdenesTrabajo()
            {
            }

            public OrdenesTrabajo(int folio, string codigobarras, int cliente, int unidad, int tipocobro, decimal subtotal, decimal iva, decimal total, int? caja, int status, DateTime fechaalta, DateTime? fechaterminacion, DateTime? fechapago, string usuarioalta, int? tipomantenimiento, int? numeroeconomico, DateTime? fechainicioreparacion, decimal? manoobra, decimal? ivamanoobra, decimal? refacciones, decimal? ivarefacciones, int? empresacobro, int? foliofacturacion, string factura, DateTime? fechafacturacion, string usuariofacturacion, decimal? kilometraje, string comentarios, decimal? costorefacciones, decimal? costomanoobra, bool? cargocond, string cb, bool? cb_activo)
            {
                this.Folio = folio;
                this.CodigoBarras = codigobarras;
                this.Cliente = cliente;
                this.Unidad = unidad;
                this.TipoCobro = tipocobro;
                this.Subtotal = subtotal;
                this.IVA = iva;
                this.Total = total;
                this.Caja = caja;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.FechaTerminacion = fechaterminacion;
                this.FechaPago = fechapago;
                this.UsuarioAlta = usuarioalta;
                this.TipoMantenimiento = tipomantenimiento;
                this.NumeroEconomico = numeroeconomico;
                this.FechaInicioReparacion = fechainicioreparacion;
                this.ManoObra = manoobra;
                this.IVAManoObra = ivamanoobra;
                this.Refacciones = refacciones;
                this.IVARefacciones = ivarefacciones;
                this.EmpresaCobro = empresacobro;
                this.FolioFacturacion = foliofacturacion;
                this.Factura = factura;
                this.FechaFacturacion = fechafacturacion;
                this.UsuarioFacturacion = usuariofacturacion;
                this.Kilometraje = kilometraje;
                this.Comentarios = comentarios;
                this.CostoRefacciones = costorefacciones;
                this.CostoManoObra = costomanoobra;
                this.CargoCond = cargocond;
                this.CB = cb;
                this.CB_Activo = cb_activo;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _CodigoBarras;
            public string CodigoBarras
            {
                get { return _CodigoBarras; }
                set { _CodigoBarras = value; }
            }

            private int _Cliente;
            public int Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _TipoCobro;
            public int TipoCobro
            {
                get { return _TipoCobro; }
                set { _TipoCobro = value; }
            }

            private decimal _Subtotal;
            public decimal Subtotal
            {
                get { return _Subtotal; }
                set { _Subtotal = value; }
            }

            private decimal _IVA;
            public decimal IVA
            {
                get { return _IVA; }
                set { _IVA = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            private int? _Caja;
            public int? Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private DateTime? _FechaTerminacion;
            public DateTime? FechaTerminacion
            {
                get { return _FechaTerminacion; }
                set { _FechaTerminacion = value; }
            }

            private DateTime? _FechaPago;
            public DateTime? FechaPago
            {
                get { return _FechaPago; }
                set { _FechaPago = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _TipoMantenimiento;
            public int? TipoMantenimiento
            {
                get { return _TipoMantenimiento; }
                set { _TipoMantenimiento = value; }
            }

            private int? _NumeroEconomico;
            public int? NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            private DateTime? _FechaInicioReparacion;
            public DateTime? FechaInicioReparacion
            {
                get { return _FechaInicioReparacion; }
                set { _FechaInicioReparacion = value; }
            }

            private decimal? _ManoObra;
            public decimal? ManoObra
            {
                get { return _ManoObra; }
                set { _ManoObra = value; }
            }

            private decimal? _IVAManoObra;
            public decimal? IVAManoObra
            {
                get { return _IVAManoObra; }
                set { _IVAManoObra = value; }
            }

            private decimal? _Refacciones;
            public decimal? Refacciones
            {
                get { return _Refacciones; }
                set { _Refacciones = value; }
            }

            private decimal? _IVARefacciones;
            public decimal? IVARefacciones
            {
                get { return _IVARefacciones; }
                set { _IVARefacciones = value; }
            }

            private int? _EmpresaCobro;
            public int? EmpresaCobro
            {
                get { return _EmpresaCobro; }
                set { _EmpresaCobro = value; }
            }

            private int? _FolioFacturacion;
            public int? FolioFacturacion
            {
                get { return _FolioFacturacion; }
                set { _FolioFacturacion = value; }
            }

            private string _Factura;
            public string Factura
            {
                get { return _Factura; }
                set { _Factura = value; }
            }

            private DateTime? _FechaFacturacion;
            public DateTime? FechaFacturacion
            {
                get { return _FechaFacturacion; }
                set { _FechaFacturacion = value; }
            }

            private string _UsuarioFacturacion;
            public string UsuarioFacturacion
            {
                get { return _UsuarioFacturacion; }
                set { _UsuarioFacturacion = value; }
            }

            private decimal? _Kilometraje;
            public decimal? Kilometraje
            {
                get { return _Kilometraje; }
                set { _Kilometraje = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private decimal? _CostoRefacciones;
            public decimal? CostoRefacciones
            {
                get { return _CostoRefacciones; }
                set { _CostoRefacciones = value; }
            }

            private decimal? _CostoManoObra;
            public decimal? CostoManoObra
            {
                get { return _CostoManoObra; }
                set { _CostoManoObra = value; }
            }

            private bool? _CargoCond;
            public bool? CargoCond
            {
                get { return _CargoCond; }
                set { _CargoCond = value; }
            }

            private string _CB;
            public string CB
            {
                get { return _CB; }
                set { _CB = value; }
            }

            private bool? _CB_Activo;
            public bool? CB_Activo
            {
                get { return _CB_Activo; }
                set { _CB_Activo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("TipoCobro", this.TipoCobro);
                m_params.Add("Subtotal", this.Subtotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                if (!AppHelper.IsNullOrEmpty(this.FechaTerminacion)) m_params.Add("FechaTerminacion", this.FechaTerminacion);
                if (!AppHelper.IsNullOrEmpty(this.FechaPago)) m_params.Add("FechaPago", this.FechaPago);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.TipoMantenimiento)) m_params.Add("TipoMantenimiento", this.TipoMantenimiento);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);
                if (!AppHelper.IsNullOrEmpty(this.FechaInicioReparacion)) m_params.Add("FechaInicioReparacion", this.FechaInicioReparacion);
                if (!AppHelper.IsNullOrEmpty(this.ManoObra)) m_params.Add("ManoObra", this.ManoObra);
                if (!AppHelper.IsNullOrEmpty(this.IVAManoObra)) m_params.Add("IVAManoObra", this.IVAManoObra);
                if (!AppHelper.IsNullOrEmpty(this.Refacciones)) m_params.Add("Refacciones", this.Refacciones);
                if (!AppHelper.IsNullOrEmpty(this.IVARefacciones)) m_params.Add("IVARefacciones", this.IVARefacciones);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaCobro)) m_params.Add("EmpresaCobro", this.EmpresaCobro);
                if (!AppHelper.IsNullOrEmpty(this.FolioFacturacion)) m_params.Add("FolioFacturacion", this.FolioFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.Factura)) m_params.Add("Factura", this.Factura);
                if (!AppHelper.IsNullOrEmpty(this.FechaFacturacion)) m_params.Add("FechaFacturacion", this.FechaFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.UsuarioFacturacion)) m_params.Add("UsuarioFacturacion", this.UsuarioFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.Kilometraje)) m_params.Add("Kilometraje", this.Kilometraje);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.CostoRefacciones)) m_params.Add("CostoRefacciones", this.CostoRefacciones);
                if (!AppHelper.IsNullOrEmpty(this.CostoManoObra)) m_params.Add("CostoManoObra", this.CostoManoObra);
                if (!AppHelper.IsNullOrEmpty(this.CargoCond)) m_params.Add("CargoCond", this.CargoCond);
                if (!AppHelper.IsNullOrEmpty(this.CB)) m_params.Add("CB", this.CB);
                if (!AppHelper.IsNullOrEmpty(this.CB_Activo)) m_params.Add("CB_Activo", this.CB_Activo);

                return DB.InsertRow("OrdenesTrabajo", m_params);
            } // End Create

            public static List<OrdenesTrabajo> Read()
            {
                List<OrdenesTrabajo> list = new List<OrdenesTrabajo>();
                DataTable dt = DB.Select("OrdenesTrabajo");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesTrabajo(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToInt32(dr["Cliente"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["TipoCobro"]), Convert.ToDecimal(dr["Subtotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), DB.GetNullableInt32(dr["Caja"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), DB.GetNullableDateTime(dr["FechaTerminacion"]), DB.GetNullableDateTime(dr["FechaPago"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["TipoMantenimiento"]), DB.GetNullableInt32(dr["NumeroEconomico"]), DB.GetNullableDateTime(dr["FechaInicioReparacion"]), DB.GetNullableDecimal(dr["ManoObra"]), DB.GetNullableDecimal(dr["IVAManoObra"]), DB.GetNullableDecimal(dr["Refacciones"]), DB.GetNullableDecimal(dr["IVARefacciones"]), DB.GetNullableInt32(dr["EmpresaCobro"]), DB.GetNullableInt32(dr["FolioFacturacion"]), Convert.ToString(dr["Factura"]), DB.GetNullableDateTime(dr["FechaFacturacion"]), Convert.ToString(dr["UsuarioFacturacion"]), DB.GetNullableDecimal(dr["Kilometraje"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableDecimal(dr["CostoRefacciones"]), DB.GetNullableDecimal(dr["CostoManoObra"]), DB.GetNullableBoolean(dr["CargoCond"]), Convert.ToString(dr["CB"]), DB.GetNullableBoolean(dr["CB_Activo"])));
                }

                return list;
            } // End Read

            public static OrdenesTrabajo Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("OrdenesTrabajo", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesTrabajo con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesTrabajo(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["CodigoBarras"]), Convert.ToInt32(dr["Cliente"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["TipoCobro"]), Convert.ToDecimal(dr["Subtotal"]), Convert.ToDecimal(dr["IVA"]), Convert.ToDecimal(dr["Total"]), DB.GetNullableInt32(dr["Caja"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), DB.GetNullableDateTime(dr["FechaTerminacion"]), DB.GetNullableDateTime(dr["FechaPago"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["TipoMantenimiento"]), DB.GetNullableInt32(dr["NumeroEconomico"]), DB.GetNullableDateTime(dr["FechaInicioReparacion"]), DB.GetNullableDecimal(dr["ManoObra"]), DB.GetNullableDecimal(dr["IVAManoObra"]), DB.GetNullableDecimal(dr["Refacciones"]), DB.GetNullableDecimal(dr["IVARefacciones"]), DB.GetNullableInt32(dr["EmpresaCobro"]), DB.GetNullableInt32(dr["FolioFacturacion"]), Convert.ToString(dr["Factura"]), DB.GetNullableDateTime(dr["FechaFacturacion"]), Convert.ToString(dr["UsuarioFacturacion"]), DB.GetNullableDecimal(dr["Kilometraje"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableDecimal(dr["CostoRefacciones"]), DB.GetNullableDecimal(dr["CostoManoObra"]), DB.GetNullableBoolean(dr["CargoCond"]), Convert.ToString(dr["CB"]), DB.GetNullableBoolean(dr["CB_Activo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("CodigoBarras", this.CodigoBarras);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("TipoCobro", this.TipoCobro);
                m_params.Add("Subtotal", this.Subtotal);
                m_params.Add("IVA", this.IVA);
                m_params.Add("Total", this.Total);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                if (!AppHelper.IsNullOrEmpty(this.FechaTerminacion)) m_params.Add("FechaTerminacion", this.FechaTerminacion);
                if (!AppHelper.IsNullOrEmpty(this.FechaPago)) m_params.Add("FechaPago", this.FechaPago);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.TipoMantenimiento)) m_params.Add("TipoMantenimiento", this.TipoMantenimiento);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);
                if (!AppHelper.IsNullOrEmpty(this.FechaInicioReparacion)) m_params.Add("FechaInicioReparacion", this.FechaInicioReparacion);
                if (!AppHelper.IsNullOrEmpty(this.ManoObra)) m_params.Add("ManoObra", this.ManoObra);
                if (!AppHelper.IsNullOrEmpty(this.IVAManoObra)) m_params.Add("IVAManoObra", this.IVAManoObra);
                if (!AppHelper.IsNullOrEmpty(this.Refacciones)) m_params.Add("Refacciones", this.Refacciones);
                if (!AppHelper.IsNullOrEmpty(this.IVARefacciones)) m_params.Add("IVARefacciones", this.IVARefacciones);
                if (!AppHelper.IsNullOrEmpty(this.EmpresaCobro)) m_params.Add("EmpresaCobro", this.EmpresaCobro);
                if (!AppHelper.IsNullOrEmpty(this.FolioFacturacion)) m_params.Add("FolioFacturacion", this.FolioFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.Factura)) m_params.Add("Factura", this.Factura);
                if (!AppHelper.IsNullOrEmpty(this.FechaFacturacion)) m_params.Add("FechaFacturacion", this.FechaFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.UsuarioFacturacion)) m_params.Add("UsuarioFacturacion", this.UsuarioFacturacion);
                if (!AppHelper.IsNullOrEmpty(this.Kilometraje)) m_params.Add("Kilometraje", this.Kilometraje);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.CostoRefacciones)) m_params.Add("CostoRefacciones", this.CostoRefacciones);
                if (!AppHelper.IsNullOrEmpty(this.CostoManoObra)) m_params.Add("CostoManoObra", this.CostoManoObra);
                if (!AppHelper.IsNullOrEmpty(this.CargoCond)) m_params.Add("CargoCond", this.CargoCond);
                if (!AppHelper.IsNullOrEmpty(this.CB)) m_params.Add("CB", this.CB);
                if (!AppHelper.IsNullOrEmpty(this.CB_Activo)) m_params.Add("CB_Activo", this.CB_Activo);

                return DB.UpdateRow("OrdenesTrabajo", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("OrdenesTrabajo", w_params);
            } // End Delete

        } //End Class OrdenesTrabajo

        public class OrdenesTrabajoCanceladas
        {

            public OrdenesTrabajoCanceladas()
            {
            }

            public OrdenesTrabajoCanceladas(int ordentrabajo, DateTime fecha, string usuario, string motivos, bool correoenviado)
            {
                this.OrdenTrabajo = ordentrabajo;
                this.Fecha = fecha;
                this.Usuario = usuario;
                this.Motivos = motivos;
                this.CorreoEnviado = correoenviado;
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Motivos;
            public string Motivos
            {
                get { return _Motivos; }
                set { _Motivos = value; }
            }

            private bool _CorreoEnviado;
            public bool CorreoEnviado
            {
                get { return _CorreoEnviado; }
                set { _CorreoEnviado = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivos", this.Motivos);
                m_params.Add("CorreoEnviado", this.CorreoEnviado);

                return DB.InsertRow("OrdenesTrabajoCanceladas", m_params);
            } // End Create

            public static List<OrdenesTrabajoCanceladas> Read()
            {
                List<OrdenesTrabajoCanceladas> list = new List<OrdenesTrabajoCanceladas>();
                DataTable dt = DB.Select("OrdenesTrabajoCanceladas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesTrabajoCanceladas(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Motivos"]), Convert.ToBoolean(dr["CorreoEnviado"])));
                }

                return list;
            } // End Read

            public static OrdenesTrabajoCanceladas Read(int ordentrabajo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", ordentrabajo);
                DataTable dt = DB.Select("OrdenesTrabajoCanceladas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesTrabajoCanceladas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesTrabajoCanceladas(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Motivos"]), Convert.ToBoolean(dr["CorreoEnviado"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Motivos", this.Motivos);
                m_params.Add("CorreoEnviado", this.CorreoEnviado);

                return DB.UpdateRow("OrdenesTrabajoCanceladas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);

                return DB.DeleteRow("OrdenesTrabajoCanceladas", w_params);
            } // End Delete

        } //End Class OrdenesTrabajoCanceladas

        public class OrdenesTrabajoCerradas
        {

            public OrdenesTrabajoCerradas()
            {
            }

            public OrdenesTrabajoCerradas(int ordentrabajo, decimal manodeobra, decimal ivamanodeobra, decimal refacciones, decimal ivarefacciones)
            {
                this.OrdenTrabajo = ordentrabajo;
                this.ManoDeObra = manodeobra;
                this.IVAManoDeObra = ivamanodeobra;
                this.Refacciones = refacciones;
                this.IVARefacciones = ivarefacciones;
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private decimal _ManoDeObra;
            public decimal ManoDeObra
            {
                get { return _ManoDeObra; }
                set { _ManoDeObra = value; }
            }

            private decimal _IVAManoDeObra;
            public decimal IVAManoDeObra
            {
                get { return _IVAManoDeObra; }
                set { _IVAManoDeObra = value; }
            }

            private decimal _Refacciones;
            public decimal Refacciones
            {
                get { return _Refacciones; }
                set { _Refacciones = value; }
            }

            private decimal _IVARefacciones;
            public decimal IVARefacciones
            {
                get { return _IVARefacciones; }
                set { _IVARefacciones = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("ManoDeObra", this.ManoDeObra);
                m_params.Add("IVAManoDeObra", this.IVAManoDeObra);
                m_params.Add("Refacciones", this.Refacciones);
                m_params.Add("IVARefacciones", this.IVARefacciones);

                return DB.InsertRow("OrdenesTrabajoCerradas", m_params);
            } // End Create

            public static List<OrdenesTrabajoCerradas> Read()
            {
                List<OrdenesTrabajoCerradas> list = new List<OrdenesTrabajoCerradas>();
                DataTable dt = DB.Select("OrdenesTrabajoCerradas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new OrdenesTrabajoCerradas(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToDecimal(dr["ManoDeObra"]), Convert.ToDecimal(dr["IVAManoDeObra"]), Convert.ToDecimal(dr["Refacciones"]), Convert.ToDecimal(dr["IVARefacciones"])));
                }

                return list;
            } // End Read

            public static OrdenesTrabajoCerradas Read(int ordentrabajo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", ordentrabajo);
                DataTable dt = DB.Select("OrdenesTrabajoCerradas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe OrdenesTrabajoCerradas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new OrdenesTrabajoCerradas(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToDecimal(dr["ManoDeObra"]), Convert.ToDecimal(dr["IVAManoDeObra"]), Convert.ToDecimal(dr["Refacciones"]), Convert.ToDecimal(dr["IVARefacciones"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("ManoDeObra", this.ManoDeObra);
                m_params.Add("IVAManoDeObra", this.IVAManoDeObra);
                m_params.Add("Refacciones", this.Refacciones);
                m_params.Add("IVARefacciones", this.IVARefacciones);

                return DB.UpdateRow("OrdenesTrabajoCerradas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);

                return DB.DeleteRow("OrdenesTrabajoCerradas", w_params);
            } // End Delete

        } //End Class OrdenesTrabajoCerradas

        public class PersonasFiscales
        {

            public PersonasFiscales()
            {
            }

            public PersonasFiscales(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("PersonasFiscales", m_params);
            } // End Create

            public static List<PersonasFiscales> Read()
            {
                List<PersonasFiscales> list = new List<PersonasFiscales>();
                DataTable dt = DB.Select("PersonasFiscales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PersonasFiscales(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("PersonasFiscales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("PersonasFiscales", w_params);
            } // End Delete

        } //End Class PersonasFiscales

        public class Planes
        {

            public Planes()
            {
            }

            public Planes(int folio, string descripcion, int? modelo, decimal rentabase, int? diasdecobro, int status, DateTime fechaalta, string usuarioalta, decimal? fondoresidual)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Modelo = modelo;
                this.RentaBase = rentabase;
                this.DiasDeCobro = diasdecobro;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.FondoResidual = fondoresidual;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Modelo;
            public int? Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private decimal _RentaBase;
            public decimal RentaBase
            {
                get { return _RentaBase; }
                set { _RentaBase = value; }
            }

            private int? _DiasDeCobro;
            public int? DiasDeCobro
            {
                get { return _DiasDeCobro; }
                set { _DiasDeCobro = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private decimal? _FondoResidual;
            public decimal? FondoResidual
            {
                get { return _FondoResidual; }
                set { _FondoResidual = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Modelo)) m_params.Add("Modelo", this.Modelo);
                m_params.Add("RentaBase", this.RentaBase);
                if (!AppHelper.IsNullOrEmpty(this.DiasDeCobro)) m_params.Add("DiasDeCobro", this.DiasDeCobro);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.FondoResidual)) m_params.Add("FondoResidual", this.FondoResidual);

                return DB.InsertRow("Planes", m_params);
            } // End Create

            public static List<Planes> Read()
            {
                List<Planes> list = new List<Planes>();
                DataTable dt = DB.Select("Planes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Planes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Modelo"]), Convert.ToDecimal(dr["RentaBase"]), DB.GetNullableInt32(dr["DiasDeCobro"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableDecimal(dr["FondoResidual"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Modelo)) m_params.Add("Modelo", this.Modelo);
                m_params.Add("RentaBase", this.RentaBase);
                if (!AppHelper.IsNullOrEmpty(this.DiasDeCobro)) m_params.Add("DiasDeCobro", this.DiasDeCobro);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.FondoResidual)) m_params.Add("FondoResidual", this.FondoResidual);

                return DB.UpdateRow("Planes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Planes", w_params);
            } // End Delete

        } //End Class Planes

        public class PlanesBeneficios
        {

            public PlanesBeneficios()
            {
            }

            public PlanesBeneficios(int plancobro, int beneficio)
            {
                this.PlanCobro = plancobro;
                this.Beneficio = beneficio;
                this.Beneficio = beneficio;
            }

            private int _PlanCobro;
            public int PlanCobro
            {
                get { return _PlanCobro; }
                set { _PlanCobro = value; }
            }

            private int _Beneficio;
            public int Beneficio
            {
                get { return _Beneficio; }
                set { _Beneficio = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Beneficio", this.Beneficio);
                m_params.Add("Beneficio", this.Beneficio);

                return DB.InsertRow("PlanesBeneficios", m_params);
            } // End Create

            public static List<PlanesBeneficios> Read()
            {
                List<PlanesBeneficios> list = new List<PlanesBeneficios>();
                DataTable dt = DB.Select("PlanesBeneficios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PlanesBeneficios(Convert.ToInt32(dr["PlanCobro"]), Convert.ToInt32(dr["Beneficio"])));
                }

                return list;
            } // End Read

            public static PlanesBeneficios Read(int plancobro, int beneficio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanCobro", plancobro);
                w_params.Add("Beneficio", beneficio);
                DataTable dt = DB.Select("PlanesBeneficios", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PlanesBeneficios con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PlanesBeneficios(Convert.ToInt32(dr["PlanCobro"]), Convert.ToInt32(dr["Beneficio"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanCobro", this.PlanCobro);
                m_params.Add("Beneficio", this.Beneficio);
                w_params.Add("Beneficio", this.Beneficio);

                return DB.UpdateRow("PlanesBeneficios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanCobro", this.PlanCobro);
                w_params.Add("Beneficio", this.Beneficio);

                return DB.DeleteRow("PlanesBeneficios", w_params);
            } // End Delete

        } //End Class PlanesBeneficios

        public class PlanesDePagos
        {

            public PlanesDePagos()
            {
            }

            public PlanesDePagos(int plandepagoid, int conductor, int unidad, int numeroeconomico, int conceptocobro, string comentarios, decimal montodiario, DateTime fechainicial, DateTime? fechafinal, int estado, string usuario, DateTime fecha)
            {
                this.PlanDePagoID = plandepagoid;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.NumeroEconomico = numeroeconomico;
                this.ConceptoCobro = conceptocobro;
                this.Comentarios = comentarios;
                this.MontoDiario = montodiario;
                this.FechaInicial = fechainicial;
                this.FechaFinal = fechafinal;
                this.Estado = estado;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _PlanDePagoID;
            public int PlanDePagoID
            {
                get { return _PlanDePagoID; }
                set { _PlanDePagoID = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _NumeroEconomico;
            public int NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            private int _ConceptoCobro;
            public int ConceptoCobro
            {
                get { return _ConceptoCobro; }
                set { _ConceptoCobro = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private decimal _MontoDiario;
            public decimal MontoDiario
            {
                get { return _MontoDiario; }
                set { _MontoDiario = value; }
            }

            private DateTime _FechaInicial;
            public DateTime FechaInicial
            {
                get { return _FechaInicial; }
                set { _FechaInicial = value; }
            }

            private DateTime? _FechaFinal;
            public DateTime? FechaFinal
            {
                get { return _FechaFinal; }
                set { _FechaFinal = value; }
            }

            private int _Estado;
            public int Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("ConceptoCobro", this.ConceptoCobro);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("MontoDiario", this.MontoDiario);
                m_params.Add("FechaInicial", this.FechaInicial);
                if (!AppHelper.IsNullOrEmpty(this.FechaFinal)) m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("PlanesDePagos", m_params);
            } // End Create

            public static List<PlanesDePagos> Read()
            {
                List<PlanesDePagos> list = new List<PlanesDePagos>();
                DataTable dt = DB.Select("PlanesDePagos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PlanesDePagos(Convert.ToInt32(dr["PlanDePagoID"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["ConceptoCobro"]), Convert.ToString(dr["Comentarios"]), Convert.ToDecimal(dr["MontoDiario"]), Convert.ToDateTime(dr["FechaInicial"]), DB.GetNullableDateTime(dr["FechaFinal"]), Convert.ToInt32(dr["Estado"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static PlanesDePagos Read(int plandepagoid)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanDePagoID", plandepagoid);
                DataTable dt = DB.Select("PlanesDePagos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PlanesDePagos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PlanesDePagos(Convert.ToInt32(dr["PlanDePagoID"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["ConceptoCobro"]), Convert.ToString(dr["Comentarios"]), Convert.ToDecimal(dr["MontoDiario"]), Convert.ToDateTime(dr["FechaInicial"]), DB.GetNullableDateTime(dr["FechaFinal"]), Convert.ToInt32(dr["Estado"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanDePagoID", this.PlanDePagoID);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("ConceptoCobro", this.ConceptoCobro);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("MontoDiario", this.MontoDiario);
                m_params.Add("FechaInicial", this.FechaInicial);
                if (!AppHelper.IsNullOrEmpty(this.FechaFinal)) m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("Estado", this.Estado);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("PlanesDePagos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("PlanDePagoID", this.PlanDePagoID);

                return DB.DeleteRow("PlanesDePagos", w_params);
            } // End Delete

        } //End Class PlanesDePagos

        public class PlanesEmpresariales
        {

            public PlanesEmpresariales()
            {
            }

            public PlanesEmpresariales(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("PlanesEmpresariales", m_params);
            } // End Create

            public static List<PlanesEmpresariales> Read()
            {
                List<PlanesEmpresariales> list = new List<PlanesEmpresariales>();
                DataTable dt = DB.Select("PlanesEmpresariales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PlanesEmpresariales(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static PlanesEmpresariales Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("PlanesEmpresariales", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PlanesEmpresariales con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PlanesEmpresariales(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("PlanesEmpresariales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("PlanesEmpresariales", w_params);
            } // End Delete

        } //End Class PlanesEmpresariales

        public class PlanillasFiscales
        {

            public PlanillasFiscales()
            {
            }

            public PlanillasFiscales(int folio, int estacion, decimal precio, DateTime fechaalta, int status, string serie)
            {
                this.Folio = folio;
                this.Estacion = estacion;
                this.Precio = precio;
                this.FechaAlta = fechaalta;
                this.Status = status;
                this.Serie = serie;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private string _Serie;
            public string Serie
            {
                get { return _Serie; }
                set { _Serie = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Precio", this.Precio);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("Status", this.Status);
                m_params.Add("Serie", this.Serie);

                return DB.InsertRow("PlanillasFiscales", m_params);
            } // End Create

            public static List<PlanillasFiscales> Read()
            {
                List<PlanillasFiscales> list = new List<PlanillasFiscales>();
                DataTable dt = DB.Select("PlanillasFiscales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PlanillasFiscales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToDecimal(dr["Precio"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToInt32(dr["Status"]), Convert.ToString(dr["Serie"])));
                }

                return list;
            } // End Read

            public static PlanillasFiscales Read(int folio, int estacion, string serie)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                w_params.Add("Estacion", estacion);
                w_params.Add("Serie", serie);
                DataTable dt = DB.Select("PlanillasFiscales", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PlanillasFiscales con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PlanillasFiscales(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Estacion"]), Convert.ToDecimal(dr["Precio"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToInt32(dr["Status"]), Convert.ToString(dr["Serie"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                w_params.Add("Estacion", this.Estacion);
                m_params.Add("Precio", this.Precio);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("Status", this.Status);
                w_params.Add("Serie", this.Serie);

                return DB.UpdateRow("PlanillasFiscales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Serie", this.Serie);

                return DB.DeleteRow("PlanillasFiscales", w_params);
            } // End Delete

        } //End Class PlanillasFiscales

        public class PrecioPlanillasFiscales
        {

            public PrecioPlanillasFiscales()
            {
            }

            public PrecioPlanillasFiscales(decimal? precio)
            {
                this.Precio = precio;
            }

            private decimal? _Precio;
            public decimal? Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Precio)) m_params.Add("Precio", this.Precio);

                return DB.InsertRow("PrecioPlanillasFiscales", m_params);
            } // End Create

            public static List<PrecioPlanillasFiscales> Read()
            {
                List<PrecioPlanillasFiscales> list = new List<PrecioPlanillasFiscales>();
                DataTable dt = DB.Select("PrecioPlanillasFiscales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PrecioPlanillasFiscales(DB.GetNullableDecimal(dr["Precio"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Precio)) m_params.Add("Precio", this.Precio);

                return DB.UpdateRow("PrecioPlanillasFiscales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("PrecioPlanillasFiscales", w_params);
            } // End Delete

        } //End Class PrecioPlanillasFiscales

        public class PreciosRefacciones
        {

            public PreciosRefacciones()
            {
            }

            public PreciosRefacciones(int refaccion, int tipocliente, decimal precio)
            {
                this.Refaccion = refaccion;
                this.TipoCliente = tipocliente;
                this.Precio = precio;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Precio", this.Precio);

                return DB.InsertRow("PreciosRefacciones", m_params);
            } // End Create

            public static List<PreciosRefacciones> Read()
            {
                List<PreciosRefacciones> list = new List<PreciosRefacciones>();
                DataTable dt = DB.Select("PreciosRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PreciosRefacciones(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["Precio"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Precio", this.Precio);

                return DB.UpdateRow("PreciosRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("PreciosRefacciones", w_params);
            } // End Delete

        } //End Class PreciosRefacciones

        public class PresupuestosColisiones
        {

            public PresupuestosColisiones()
            {
            }

            public PresupuestosColisiones(int folio, int unidad, int cliente, DateTime fecha, string usuario, string comentarios, bool? activo, string numerosiniestro, string numerocolision)
            {
                this.Folio = folio;
                this.Unidad = unidad;
                this.Cliente = cliente;
                this.Fecha = fecha;
                this.Usuario = usuario;
                this.Comentarios = comentarios;
                this.Activo = activo;
                this.NumeroSiniestro = numerosiniestro;
                this.NumeroColision = numerocolision;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Cliente;
            public int Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private bool? _Activo;
            public bool? Activo
            {
                get { return _Activo; }
                set { _Activo = value; }
            }

            private string _NumeroSiniestro;
            public string NumeroSiniestro
            {
                get { return _NumeroSiniestro; }
                set { _NumeroSiniestro = value; }
            }

            private string _NumeroColision;
            public string NumeroColision
            {
                get { return _NumeroColision; }
                set { _NumeroColision = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);
                if (!AppHelper.IsNullOrEmpty(this.NumeroSiniestro)) m_params.Add("NumeroSiniestro", this.NumeroSiniestro);
                if (!AppHelper.IsNullOrEmpty(this.NumeroColision)) m_params.Add("NumeroColision", this.NumeroColision);

                return DB.InsertRow("PresupuestosColisiones", m_params);
            } // End Create

            public static List<PresupuestosColisiones> Read()
            {
                List<PresupuestosColisiones> list = new List<PresupuestosColisiones>();
                DataTable dt = DB.Select("PresupuestosColisiones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PresupuestosColisiones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Cliente"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableBoolean(dr["Activo"]), Convert.ToString(dr["NumeroSiniestro"]), Convert.ToString(dr["NumeroColision"])));
                }

                return list;
            } // End Read

            public static PresupuestosColisiones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("PresupuestosColisiones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PresupuestosColisiones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PresupuestosColisiones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Cliente"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]), Convert.ToString(dr["Comentarios"]), DB.GetNullableBoolean(dr["Activo"]), Convert.ToString(dr["NumeroSiniestro"]), Convert.ToString(dr["NumeroColision"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Comentarios", this.Comentarios);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);
                if (!AppHelper.IsNullOrEmpty(this.NumeroSiniestro)) m_params.Add("NumeroSiniestro", this.NumeroSiniestro);
                if (!AppHelper.IsNullOrEmpty(this.NumeroColision)) m_params.Add("NumeroColision", this.NumeroColision);

                return DB.UpdateRow("PresupuestosColisiones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("PresupuestosColisiones", w_params);
            } // End Delete

        } //End Class PresupuestosColisiones

        public class PresupuestosColisionesOrdenesTrabajo
        {

            public PresupuestosColisionesOrdenesTrabajo()
            {
            }

            public PresupuestosColisionesOrdenesTrabajo(int presupuesto, int ordentrabajo)
            {
                this.Presupuesto = presupuesto;
                this.OrdenTrabajo = ordentrabajo;
            }

            private int _Presupuesto;
            public int Presupuesto
            {
                get { return _Presupuesto; }
                set { _Presupuesto = value; }
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Presupuesto", this.Presupuesto);
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);

                return DB.InsertRow("PresupuestosColisionesOrdenesTrabajo", m_params);
            } // End Create

            public static List<PresupuestosColisionesOrdenesTrabajo> Read()
            {
                List<PresupuestosColisionesOrdenesTrabajo> list = new List<PresupuestosColisionesOrdenesTrabajo>();
                DataTable dt = DB.Select("PresupuestosColisionesOrdenesTrabajo");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new PresupuestosColisionesOrdenesTrabajo(Convert.ToInt32(dr["Presupuesto"]), Convert.ToInt32(dr["OrdenTrabajo"])));
                }

                return list;
            } // End Read

            public static PresupuestosColisionesOrdenesTrabajo Read(int presupuesto, int ordentrabajo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Presupuesto", presupuesto);
                w_params.Add("OrdenTrabajo", ordentrabajo);
                DataTable dt = DB.Select("PresupuestosColisionesOrdenesTrabajo", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe PresupuestosColisionesOrdenesTrabajo con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new PresupuestosColisionesOrdenesTrabajo(Convert.ToInt32(dr["Presupuesto"]), Convert.ToInt32(dr["OrdenTrabajo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Presupuesto", this.Presupuesto);
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);

                return DB.UpdateRow("PresupuestosColisionesOrdenesTrabajo", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Presupuesto", this.Presupuesto);
                w_params.Add("OrdenTrabajo", this.OrdenTrabajo);

                return DB.DeleteRow("PresupuestosColisionesOrdenesTrabajo", w_params);
            } // End Delete

        } //End Class PresupuestosColisionesOrdenesTrabajo

        public class Productos
        {

            public Productos()
            {
            }

            public Productos(int folio, string descripcion, decimal precio, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Precio = precio;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Precio", this.Precio);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Productos", m_params);
            } // End Create

            public static List<Productos> Read()
            {
                List<Productos> list = new List<Productos>();
                DataTable dt = DB.Select("Productos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Productos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDecimal(dr["Precio"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Productos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Productos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Productos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Productos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDecimal(dr["Precio"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Precio", this.Precio);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Productos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Productos", w_params);
            } // End Delete

        } //End Class Productos

        public class Proveedores
        {

            public Proveedores()
            {
            }

            public Proveedores(int folio, string rfc, string razonsocial, string calle, string numero, string colonia, string ciudad, string estado, int codigopostal, string telefonos, string fax, string correoelectronico, string contactos, int status, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Rfc = rfc;
                this.RazonSocial = razonsocial;
                this.Calle = calle;
                this.Numero = numero;
                this.Colonia = colonia;
                this.Ciudad = ciudad;
                this.Estado = estado;
                this.CodigoPostal = codigopostal;
                this.Telefonos = telefonos;
                this.Fax = fax;
                this.CorreoElectronico = correoelectronico;
                this.Contactos = contactos;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Rfc;
            public string Rfc
            {
                get { return _Rfc; }
                set { _Rfc = value; }
            }

            private string _RazonSocial;
            public string RazonSocial
            {
                get { return _RazonSocial; }
                set { _RazonSocial = value; }
            }

            private string _Calle;
            public string Calle
            {
                get { return _Calle; }
                set { _Calle = value; }
            }

            private string _Numero;
            public string Numero
            {
                get { return _Numero; }
                set { _Numero = value; }
            }

            private string _Colonia;
            public string Colonia
            {
                get { return _Colonia; }
                set { _Colonia = value; }
            }

            private string _Ciudad;
            public string Ciudad
            {
                get { return _Ciudad; }
                set { _Ciudad = value; }
            }

            private string _Estado;
            public string Estado
            {
                get { return _Estado; }
                set { _Estado = value; }
            }

            private int _CodigoPostal;
            public int CodigoPostal
            {
                get { return _CodigoPostal; }
                set { _CodigoPostal = value; }
            }

            private string _Telefonos;
            public string Telefonos
            {
                get { return _Telefonos; }
                set { _Telefonos = value; }
            }

            private string _Fax;
            public string Fax
            {
                get { return _Fax; }
                set { _Fax = value; }
            }

            private string _CorreoElectronico;
            public string CorreoElectronico
            {
                get { return _CorreoElectronico; }
                set { _CorreoElectronico = value; }
            }

            private string _Contactos;
            public string Contactos
            {
                get { return _Contactos; }
                set { _Contactos = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("Fax", this.Fax);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Contactos", this.Contactos);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Proveedores", m_params);
            } // End Create

            public static List<Proveedores> Read()
            {
                List<Proveedores> list = new List<Proveedores>();
                DataTable dt = DB.Select("Proveedores");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Proveedores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToInt32(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToString(dr["Fax"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Contactos"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Proveedores Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Proveedores", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Proveedores con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Proveedores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Rfc"]), Convert.ToString(dr["RazonSocial"]), Convert.ToString(dr["Calle"]), Convert.ToString(dr["Numero"]), Convert.ToString(dr["Colonia"]), Convert.ToString(dr["Ciudad"]), Convert.ToString(dr["Estado"]), Convert.ToInt32(dr["CodigoPostal"]), Convert.ToString(dr["Telefonos"]), Convert.ToString(dr["Fax"]), Convert.ToString(dr["CorreoElectronico"]), Convert.ToString(dr["Contactos"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Rfc", this.Rfc);
                m_params.Add("RazonSocial", this.RazonSocial);
                m_params.Add("Calle", this.Calle);
                m_params.Add("Numero", this.Numero);
                m_params.Add("Colonia", this.Colonia);
                m_params.Add("Ciudad", this.Ciudad);
                m_params.Add("Estado", this.Estado);
                m_params.Add("CodigoPostal", this.CodigoPostal);
                m_params.Add("Telefonos", this.Telefonos);
                m_params.Add("Fax", this.Fax);
                m_params.Add("CorreoElectronico", this.CorreoElectronico);
                m_params.Add("Contactos", this.Contactos);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Proveedores", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Proveedores", w_params);
            } // End Delete

        } //End Class Proveedores

        public class ReasignacioesUnidades
        {

            public ReasignacioesUnidades()
            {
            }

            public ReasignacioesUnidades(int folio, int conductor, int unidadanterior, int unidadactual, string motivo, int tipo, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.UnidadAnterior = unidadanterior;
                this.UnidadActual = unidadactual;
                this.Motivo = motivo;
                this.Tipo = tipo;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _UnidadAnterior;
            public int UnidadAnterior
            {
                get { return _UnidadAnterior; }
                set { _UnidadAnterior = value; }
            }

            private int _UnidadActual;
            public int UnidadActual
            {
                get { return _UnidadActual; }
                set { _UnidadActual = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("UnidadAnterior", this.UnidadAnterior);
                m_params.Add("UnidadActual", this.UnidadActual);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("ReasignacioesUnidades", m_params);
            } // End Create

            public static List<ReasignacioesUnidades> Read()
            {
                List<ReasignacioesUnidades> list = new List<ReasignacioesUnidades>();
                DataTable dt = DB.Select("ReasignacioesUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ReasignacioesUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["UnidadAnterior"]), Convert.ToInt32(dr["UnidadActual"]), Convert.ToString(dr["Motivo"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static ReasignacioesUnidades Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("ReasignacioesUnidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ReasignacioesUnidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ReasignacioesUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["UnidadAnterior"]), Convert.ToInt32(dr["UnidadActual"]), Convert.ToString(dr["Motivo"]), Convert.ToInt32(dr["Tipo"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("UnidadAnterior", this.UnidadAnterior);
                m_params.Add("UnidadActual", this.UnidadActual);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("ReasignacioesUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("ReasignacioesUnidades", w_params);
            } // End Delete

        } //End Class ReasignacioesUnidades

        public class Recibos
        {

            public Recibos()
            {
            }

            public Recibos(int estacion, int? caja, int folio, int conductor, int unidad, DateTime fecha, decimal totalapagar, decimal pagoefectivo, decimal pagovales, string usuarioalta)
            {
                this.Estacion = estacion;
                this.Caja = caja;
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Fecha = fecha;
                this.TotalAPagar = totalapagar;
                this.PagoEfectivo = pagoefectivo;
                this.PagoVales = pagovales;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int? _Caja;
            public int? Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private decimal _TotalAPagar;
            public decimal TotalAPagar
            {
                get { return _TotalAPagar; }
                set { _TotalAPagar = value; }
            }

            private decimal _PagoEfectivo;
            public decimal PagoEfectivo
            {
                get { return _PagoEfectivo; }
                set { _PagoEfectivo = value; }
            }

            private decimal _PagoVales;
            public decimal PagoVales
            {
                get { return _PagoVales; }
                set { _PagoVales = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("TotalAPagar", this.TotalAPagar);
                m_params.Add("PagoEfectivo", this.PagoEfectivo);
                m_params.Add("PagoVales", this.PagoVales);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Recibos", m_params);
            } // End Create

            public static List<Recibos> Read()
            {
                List<Recibos> list = new List<Recibos>();
                DataTable dt = DB.Select("Recibos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Recibos(Convert.ToInt32(dr["Estacion"]), DB.GetNullableInt32(dr["Caja"]), Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToDecimal(dr["TotalAPagar"]), Convert.ToDecimal(dr["PagoEfectivo"]), Convert.ToDecimal(dr["PagoVales"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Caja)) m_params.Add("Caja", this.Caja);
                m_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("TotalAPagar", this.TotalAPagar);
                m_params.Add("PagoEfectivo", this.PagoEfectivo);
                m_params.Add("PagoVales", this.PagoVales);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Recibos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Recibos", w_params);
            } // End Delete

        } //End Class Recibos

        public class RecibosCancelados
        {

            public RecibosCancelados()
            {
            }

            public RecibosCancelados(int estacion, int recibo, string motivo, string usuario, DateTime? fecha)
            {
                this.Estacion = estacion;
                this.Recibo = recibo;
                this.Motivo = motivo;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Recibo;
            public int Recibo
            {
                get { return _Recibo; }
                set { _Recibo = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Recibo", this.Recibo);
                if (!AppHelper.IsNullOrEmpty(this.Motivo)) m_params.Add("Motivo", this.Motivo);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("RecibosCancelados", m_params);
            } // End Create

            public static List<RecibosCancelados> Read()
            {
                List<RecibosCancelados> list = new List<RecibosCancelados>();
                DataTable dt = DB.Select("RecibosCancelados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosCancelados(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToString(dr["Motivo"]), Convert.ToString(dr["Usuario"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static RecibosCancelados Read(int estacion, int recibo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", estacion);
                w_params.Add("Recibo", recibo);
                DataTable dt = DB.Select("RecibosCancelados", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RecibosCancelados con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RecibosCancelados(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToString(dr["Motivo"]), Convert.ToString(dr["Usuario"]), DB.GetNullableDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);
                if (!AppHelper.IsNullOrEmpty(this.Motivo)) m_params.Add("Motivo", this.Motivo);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("RecibosCancelados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);

                return DB.DeleteRow("RecibosCancelados", w_params);
            } // End Delete

        } //End Class RecibosCancelados

        public class RecibosMovimientos
        {

            public RecibosMovimientos()
            {
            }

            public RecibosMovimientos(int? estacion, int? recibo, int? movimiento)
            {
                this.Estacion = estacion;
                this.Recibo = recibo;
                this.Movimiento = movimiento;
            }

            private int? _Estacion;
            public int? Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int? _Recibo;
            public int? Recibo
            {
                get { return _Recibo; }
                set { _Recibo = value; }
            }

            private int? _Movimiento;
            public int? Movimiento
            {
                get { return _Movimiento; }
                set { _Movimiento = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Estacion)) m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Recibo)) m_params.Add("Recibo", this.Recibo);
                if (!AppHelper.IsNullOrEmpty(this.Movimiento)) m_params.Add("Movimiento", this.Movimiento);

                return DB.InsertRow("RecibosMovimientos", m_params);
            } // End Create

            public static List<RecibosMovimientos> Read()
            {
                List<RecibosMovimientos> list = new List<RecibosMovimientos>();
                DataTable dt = DB.Select("RecibosMovimientos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosMovimientos(DB.GetNullableInt32(dr["Estacion"]), DB.GetNullableInt32(dr["Recibo"]), DB.GetNullableInt32(dr["Movimiento"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Estacion)) m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.Recibo)) m_params.Add("Recibo", this.Recibo);
                if (!AppHelper.IsNullOrEmpty(this.Movimiento)) m_params.Add("Movimiento", this.Movimiento);

                return DB.UpdateRow("RecibosMovimientos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RecibosMovimientos", w_params);
            } // End Delete

        } //End Class RecibosMovimientos

        public class RecibosPlanillas
        {

            public RecibosPlanillas()
            {
            }

            public RecibosPlanillas(int estacion, int recibo, int planilla, int caja, decimal precio, string serie)
            {
                this.Estacion = estacion;
                this.Recibo = recibo;
                this.Planilla = planilla;
                this.Caja = caja;
                this.Precio = precio;
                this.Serie = serie;
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Recibo;
            public int Recibo
            {
                get { return _Recibo; }
                set { _Recibo = value; }
            }

            private int _Planilla;
            public int Planilla
            {
                get { return _Planilla; }
                set { _Planilla = value; }
            }

            private int _Caja;
            public int Caja
            {
                get { return _Caja; }
                set { _Caja = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            private string _Serie;
            public string Serie
            {
                get { return _Serie; }
                set { _Serie = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Recibo", this.Recibo);
                m_params.Add("Planilla", this.Planilla);
                m_params.Add("Caja", this.Caja);
                m_params.Add("Precio", this.Precio);
                if (!AppHelper.IsNullOrEmpty(this.Serie)) m_params.Add("Serie", this.Serie);

                return DB.InsertRow("RecibosPlanillas", m_params);
            } // End Create

            public static List<RecibosPlanillas> Read()
            {
                List<RecibosPlanillas> list = new List<RecibosPlanillas>();
                DataTable dt = DB.Select("RecibosPlanillas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosPlanillas(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToInt32(dr["Planilla"]), Convert.ToInt32(dr["Caja"]), Convert.ToDecimal(dr["Precio"]), Convert.ToString(dr["Serie"])));
                }

                return list;
            } // End Read

            public static RecibosPlanillas Read(int estacion, int recibo, int planilla)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", estacion);
                w_params.Add("Recibo", recibo);
                w_params.Add("Planilla", planilla);
                DataTable dt = DB.Select("RecibosPlanillas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RecibosPlanillas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RecibosPlanillas(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToInt32(dr["Planilla"]), Convert.ToInt32(dr["Caja"]), Convert.ToDecimal(dr["Precio"]), Convert.ToString(dr["Serie"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);
                w_params.Add("Planilla", this.Planilla);
                m_params.Add("Caja", this.Caja);
                m_params.Add("Precio", this.Precio);
                if (!AppHelper.IsNullOrEmpty(this.Serie)) m_params.Add("Serie", this.Serie);

                return DB.UpdateRow("RecibosPlanillas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);
                w_params.Add("Planilla", this.Planilla);

                return DB.DeleteRow("RecibosPlanillas", w_params);
            } // End Delete

        } //End Class RecibosPlanillas

        public class RecibosSaldos
        {

            public RecibosSaldos()
            {
            }

            public RecibosSaldos(int estacion, int recibo, int cuenta, decimal saldoanterior, decimal abono, decimal saldoactual)
            {
                this.Estacion = estacion;
                this.Recibo = recibo;
                this.Cuenta = cuenta;
                this.SaldoAnterior = saldoanterior;
                this.Abono = abono;
                this.SaldoActual = saldoactual;
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Recibo;
            public int Recibo
            {
                get { return _Recibo; }
                set { _Recibo = value; }
            }

            private int _Cuenta;
            public int Cuenta
            {
                get { return _Cuenta; }
                set { _Cuenta = value; }
            }

            private decimal _SaldoAnterior;
            public decimal SaldoAnterior
            {
                get { return _SaldoAnterior; }
                set { _SaldoAnterior = value; }
            }

            private decimal _Abono;
            public decimal Abono
            {
                get { return _Abono; }
                set { _Abono = value; }
            }

            private decimal _SaldoActual;
            public decimal SaldoActual
            {
                get { return _SaldoActual; }
                set { _SaldoActual = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Recibo", this.Recibo);
                m_params.Add("Cuenta", this.Cuenta);
                m_params.Add("SaldoAnterior", this.SaldoAnterior);
                m_params.Add("Abono", this.Abono);
                m_params.Add("SaldoActual", this.SaldoActual);

                return DB.InsertRow("RecibosSaldos", m_params);
            } // End Create

            public static List<RecibosSaldos> Read()
            {
                List<RecibosSaldos> list = new List<RecibosSaldos>();
                DataTable dt = DB.Select("RecibosSaldos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosSaldos(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToInt32(dr["Cuenta"]), Convert.ToDecimal(dr["SaldoAnterior"]), Convert.ToDecimal(dr["Abono"]), Convert.ToDecimal(dr["SaldoActual"])));
                }

                return list;
            } // End Read

            public static RecibosSaldos Read(int estacion, int recibo, int cuenta)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", estacion);
                w_params.Add("Recibo", recibo);
                w_params.Add("Cuenta", cuenta);
                DataTable dt = DB.Select("RecibosSaldos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RecibosSaldos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RecibosSaldos(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToInt32(dr["Cuenta"]), Convert.ToDecimal(dr["SaldoAnterior"]), Convert.ToDecimal(dr["Abono"]), Convert.ToDecimal(dr["SaldoActual"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);
                w_params.Add("Cuenta", this.Cuenta);
                m_params.Add("SaldoAnterior", this.SaldoAnterior);
                m_params.Add("Abono", this.Abono);
                m_params.Add("SaldoActual", this.SaldoActual);

                return DB.UpdateRow("RecibosSaldos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Estacion", this.Estacion);
                w_params.Add("Recibo", this.Recibo);
                w_params.Add("Cuenta", this.Cuenta);

                return DB.DeleteRow("RecibosSaldos", w_params);
            } // End Delete

        } //End Class RecibosSaldos

        public class RecibosSarec
        {

            public RecibosSarec()
            {
            }

            public RecibosSarec(char folio, char fecha, char hora, char unidad, char cvecliente, int odometro, int odometroanterior, string comentarios, decimal pasaje, decimal valesgas, decimal callcenter, decimal otroscargos, decimal pagacon, decimal valesprepagados, decimal ajuste, char? autorizacion, decimal saldopasaje, decimal saldocallcenter, decimal saldootroscargos, decimal saldocuotavales, char mantenimpend, char altausr, char altafecha, char altahora, char? modiffecha, char? modifhora, char? modifusr, char? folioempate, decimal? planilla, decimal? recibogas, char? estacion, decimal? servicecenter, decimal? saldoservicecent, decimal? pagoequipo, decimal? saldoequipo, decimal? carnet, decimal? saldocarnet, decimal? pagounidad, decimal? saldopagounidad, decimal? mantenimientoconductor, decimal? saldomantenimientoconductor)
            {
                this.Folio = folio;
                this.Fecha = fecha;
                this.Hora = hora;
                this.Unidad = unidad;
                this.CveCliente = cvecliente;
                this.Odometro = odometro;
                this.OdometroAnterior = odometroanterior;
                this.Comentarios = comentarios;
                this.Pasaje = pasaje;
                this.ValesGas = valesgas;
                this.CallCenter = callcenter;
                this.OtrosCargos = otroscargos;
                this.PagaCon = pagacon;
                this.ValesPrePagados = valesprepagados;
                this.Ajuste = ajuste;
                this.Autorizacion = autorizacion;
                this.SaldoPasaje = saldopasaje;
                this.SaldoCallCenter = saldocallcenter;
                this.SaldoOtrosCargos = saldootroscargos;
                this.SaldoCuotaVales = saldocuotavales;
                this.MantenimPend = mantenimpend;
                this.AltaUsr = altausr;
                this.AltaFecha = altafecha;
                this.AltaHora = altahora;
                this.ModifFecha = modiffecha;
                this.ModifHora = modifhora;
                this.ModifUsr = modifusr;
                this.FolioEmpate = folioempate;
                this.Planilla = planilla;
                this.ReciboGas = recibogas;
                this.Estacion = estacion;
                this.ServiceCenter = servicecenter;
                this.SaldoServiceCent = saldoservicecent;
                this.PagoEquipo = pagoequipo;
                this.SaldoEquipo = saldoequipo;
                this.Carnet = carnet;
                this.SaldoCarnet = saldocarnet;
                this.PAGOUNIDAD = pagounidad;
                this.SALDOPAGOUNIDAD = saldopagounidad;
                this.MANTENIMIENTOCONDUCTOR = mantenimientoconductor;
                this.SALDOMANTENIMIENTOCONDUCTOR = saldomantenimientoconductor;
            }

            private char _Folio;
            public char Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private char _Fecha;
            public char Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private char _Hora;
            public char Hora
            {
                get { return _Hora; }
                set { _Hora = value; }
            }

            private char _Unidad;
            public char Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private char _CveCliente;
            public char CveCliente
            {
                get { return _CveCliente; }
                set { _CveCliente = value; }
            }

            private int _Odometro;
            public int Odometro
            {
                get { return _Odometro; }
                set { _Odometro = value; }
            }

            private int _OdometroAnterior;
            public int OdometroAnterior
            {
                get { return _OdometroAnterior; }
                set { _OdometroAnterior = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private decimal _Pasaje;
            public decimal Pasaje
            {
                get { return _Pasaje; }
                set { _Pasaje = value; }
            }

            private decimal _ValesGas;
            public decimal ValesGas
            {
                get { return _ValesGas; }
                set { _ValesGas = value; }
            }

            private decimal _CallCenter;
            public decimal CallCenter
            {
                get { return _CallCenter; }
                set { _CallCenter = value; }
            }

            private decimal _OtrosCargos;
            public decimal OtrosCargos
            {
                get { return _OtrosCargos; }
                set { _OtrosCargos = value; }
            }

            private decimal _PagaCon;
            public decimal PagaCon
            {
                get { return _PagaCon; }
                set { _PagaCon = value; }
            }

            private decimal _ValesPrePagados;
            public decimal ValesPrePagados
            {
                get { return _ValesPrePagados; }
                set { _ValesPrePagados = value; }
            }

            private decimal _Ajuste;
            public decimal Ajuste
            {
                get { return _Ajuste; }
                set { _Ajuste = value; }
            }

            private char? _Autorizacion;
            public char? Autorizacion
            {
                get { return _Autorizacion; }
                set { _Autorizacion = value; }
            }

            private decimal _SaldoPasaje;
            public decimal SaldoPasaje
            {
                get { return _SaldoPasaje; }
                set { _SaldoPasaje = value; }
            }

            private decimal _SaldoCallCenter;
            public decimal SaldoCallCenter
            {
                get { return _SaldoCallCenter; }
                set { _SaldoCallCenter = value; }
            }

            private decimal _SaldoOtrosCargos;
            public decimal SaldoOtrosCargos
            {
                get { return _SaldoOtrosCargos; }
                set { _SaldoOtrosCargos = value; }
            }

            private decimal _SaldoCuotaVales;
            public decimal SaldoCuotaVales
            {
                get { return _SaldoCuotaVales; }
                set { _SaldoCuotaVales = value; }
            }

            private char _MantenimPend;
            public char MantenimPend
            {
                get { return _MantenimPend; }
                set { _MantenimPend = value; }
            }

            private char _AltaUsr;
            public char AltaUsr
            {
                get { return _AltaUsr; }
                set { _AltaUsr = value; }
            }

            private char _AltaFecha;
            public char AltaFecha
            {
                get { return _AltaFecha; }
                set { _AltaFecha = value; }
            }

            private char _AltaHora;
            public char AltaHora
            {
                get { return _AltaHora; }
                set { _AltaHora = value; }
            }

            private char? _ModifFecha;
            public char? ModifFecha
            {
                get { return _ModifFecha; }
                set { _ModifFecha = value; }
            }

            private char? _ModifHora;
            public char? ModifHora
            {
                get { return _ModifHora; }
                set { _ModifHora = value; }
            }

            private char? _ModifUsr;
            public char? ModifUsr
            {
                get { return _ModifUsr; }
                set { _ModifUsr = value; }
            }

            private char? _FolioEmpate;
            public char? FolioEmpate
            {
                get { return _FolioEmpate; }
                set { _FolioEmpate = value; }
            }

            private decimal? _Planilla;
            public decimal? Planilla
            {
                get { return _Planilla; }
                set { _Planilla = value; }
            }

            private decimal? _ReciboGas;
            public decimal? ReciboGas
            {
                get { return _ReciboGas; }
                set { _ReciboGas = value; }
            }

            private char? _Estacion;
            public char? Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private decimal? _ServiceCenter;
            public decimal? ServiceCenter
            {
                get { return _ServiceCenter; }
                set { _ServiceCenter = value; }
            }

            private decimal? _SaldoServiceCent;
            public decimal? SaldoServiceCent
            {
                get { return _SaldoServiceCent; }
                set { _SaldoServiceCent = value; }
            }

            private decimal? _PagoEquipo;
            public decimal? PagoEquipo
            {
                get { return _PagoEquipo; }
                set { _PagoEquipo = value; }
            }

            private decimal? _SaldoEquipo;
            public decimal? SaldoEquipo
            {
                get { return _SaldoEquipo; }
                set { _SaldoEquipo = value; }
            }

            private decimal? _Carnet;
            public decimal? Carnet
            {
                get { return _Carnet; }
                set { _Carnet = value; }
            }

            private decimal? _SaldoCarnet;
            public decimal? SaldoCarnet
            {
                get { return _SaldoCarnet; }
                set { _SaldoCarnet = value; }
            }

            private decimal? _PAGOUNIDAD;
            public decimal? PAGOUNIDAD
            {
                get { return _PAGOUNIDAD; }
                set { _PAGOUNIDAD = value; }
            }

            private decimal? _SALDOPAGOUNIDAD;
            public decimal? SALDOPAGOUNIDAD
            {
                get { return _SALDOPAGOUNIDAD; }
                set { _SALDOPAGOUNIDAD = value; }
            }

            private decimal? _MANTENIMIENTOCONDUCTOR;
            public decimal? MANTENIMIENTOCONDUCTOR
            {
                get { return _MANTENIMIENTOCONDUCTOR; }
                set { _MANTENIMIENTOCONDUCTOR = value; }
            }

            private decimal? _SALDOMANTENIMIENTOCONDUCTOR;
            public decimal? SALDOMANTENIMIENTOCONDUCTOR
            {
                get { return _SALDOMANTENIMIENTOCONDUCTOR; }
                set { _SALDOMANTENIMIENTOCONDUCTOR = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Hora", this.Hora);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("CveCliente", this.CveCliente);
                m_params.Add("Odometro", this.Odometro);
                m_params.Add("OdometroAnterior", this.OdometroAnterior);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("Pasaje", this.Pasaje);
                m_params.Add("ValesGas", this.ValesGas);
                m_params.Add("CallCenter", this.CallCenter);
                m_params.Add("OtrosCargos", this.OtrosCargos);
                m_params.Add("PagaCon", this.PagaCon);
                m_params.Add("ValesPrePagados", this.ValesPrePagados);
                m_params.Add("Ajuste", this.Ajuste);
                if (!AppHelper.IsNullOrEmpty(this.Autorizacion)) m_params.Add("Autorizacion", this.Autorizacion);
                m_params.Add("SaldoPasaje", this.SaldoPasaje);
                m_params.Add("SaldoCallCenter", this.SaldoCallCenter);
                m_params.Add("SaldoOtrosCargos", this.SaldoOtrosCargos);
                m_params.Add("SaldoCuotaVales", this.SaldoCuotaVales);
                m_params.Add("MantenimPend", this.MantenimPend);
                m_params.Add("AltaUsr", this.AltaUsr);
                m_params.Add("AltaFecha", this.AltaFecha);
                m_params.Add("AltaHora", this.AltaHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifFecha)) m_params.Add("ModifFecha", this.ModifFecha);
                if (!AppHelper.IsNullOrEmpty(this.ModifHora)) m_params.Add("ModifHora", this.ModifHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifUsr)) m_params.Add("ModifUsr", this.ModifUsr);
                if (!AppHelper.IsNullOrEmpty(this.FolioEmpate)) m_params.Add("FolioEmpate", this.FolioEmpate);
                if (!AppHelper.IsNullOrEmpty(this.Planilla)) m_params.Add("Planilla", this.Planilla);
                if (!AppHelper.IsNullOrEmpty(this.ReciboGas)) m_params.Add("ReciboGas", this.ReciboGas);
                if (!AppHelper.IsNullOrEmpty(this.Estacion)) m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.ServiceCenter)) m_params.Add("ServiceCenter", this.ServiceCenter);
                if (!AppHelper.IsNullOrEmpty(this.SaldoServiceCent)) m_params.Add("SaldoServiceCent", this.SaldoServiceCent);
                if (!AppHelper.IsNullOrEmpty(this.PagoEquipo)) m_params.Add("PagoEquipo", this.PagoEquipo);
                if (!AppHelper.IsNullOrEmpty(this.SaldoEquipo)) m_params.Add("SaldoEquipo", this.SaldoEquipo);
                if (!AppHelper.IsNullOrEmpty(this.Carnet)) m_params.Add("Carnet", this.Carnet);
                if (!AppHelper.IsNullOrEmpty(this.SaldoCarnet)) m_params.Add("SaldoCarnet", this.SaldoCarnet);
                if (!AppHelper.IsNullOrEmpty(this.PAGOUNIDAD)) m_params.Add("PAGOUNIDAD", this.PAGOUNIDAD);
                if (!AppHelper.IsNullOrEmpty(this.SALDOPAGOUNIDAD)) m_params.Add("SALDOPAGOUNIDAD", this.SALDOPAGOUNIDAD);
                if (!AppHelper.IsNullOrEmpty(this.MANTENIMIENTOCONDUCTOR)) m_params.Add("MANTENIMIENTOCONDUCTOR", this.MANTENIMIENTOCONDUCTOR);
                if (!AppHelper.IsNullOrEmpty(this.SALDOMANTENIMIENTOCONDUCTOR)) m_params.Add("SALDOMANTENIMIENTOCONDUCTOR", this.SALDOMANTENIMIENTOCONDUCTOR);

                return DB.InsertRow("RecibosSarec", m_params);
            } // End Create

            public static List<RecibosSarec> Read()
            {
                List<RecibosSarec> list = new List<RecibosSarec>();
                DataTable dt = DB.Select("RecibosSarec");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosSarec(Convert.ToChar(dr["Folio"]), Convert.ToChar(dr["Fecha"]), Convert.ToChar(dr["Hora"]), Convert.ToChar(dr["Unidad"]), Convert.ToChar(dr["CveCliente"]), Convert.ToInt32(dr["Odometro"]), Convert.ToInt32(dr["OdometroAnterior"]), Convert.ToString(dr["Comentarios"]), Convert.ToDecimal(dr["Pasaje"]), Convert.ToDecimal(dr["ValesGas"]), Convert.ToDecimal(dr["CallCenter"]), Convert.ToDecimal(dr["OtrosCargos"]), Convert.ToDecimal(dr["PagaCon"]), Convert.ToDecimal(dr["ValesPrePagados"]), Convert.ToDecimal(dr["Ajuste"]), DB.GetNullableChar(dr["Autorizacion"]), Convert.ToDecimal(dr["SaldoPasaje"]), Convert.ToDecimal(dr["SaldoCallCenter"]), Convert.ToDecimal(dr["SaldoOtrosCargos"]), Convert.ToDecimal(dr["SaldoCuotaVales"]), Convert.ToChar(dr["MantenimPend"]), Convert.ToChar(dr["AltaUsr"]), Convert.ToChar(dr["AltaFecha"]), Convert.ToChar(dr["AltaHora"]), DB.GetNullableChar(dr["ModifFecha"]), DB.GetNullableChar(dr["ModifHora"]), DB.GetNullableChar(dr["ModifUsr"]), DB.GetNullableChar(dr["FolioEmpate"]), DB.GetNullableDecimal(dr["Planilla"]), DB.GetNullableDecimal(dr["ReciboGas"]), DB.GetNullableChar(dr["Estacion"]), DB.GetNullableDecimal(dr["ServiceCenter"]), DB.GetNullableDecimal(dr["SaldoServiceCent"]), DB.GetNullableDecimal(dr["PagoEquipo"]), DB.GetNullableDecimal(dr["SaldoEquipo"]), DB.GetNullableDecimal(dr["Carnet"]), DB.GetNullableDecimal(dr["SaldoCarnet"]), DB.GetNullableDecimal(dr["PAGOUNIDAD"]), DB.GetNullableDecimal(dr["SALDOPAGOUNIDAD"]), DB.GetNullableDecimal(dr["MANTENIMIENTOCONDUCTOR"]), DB.GetNullableDecimal(dr["SALDOMANTENIMIENTOCONDUCTOR"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Hora", this.Hora);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("CveCliente", this.CveCliente);
                m_params.Add("Odometro", this.Odometro);
                m_params.Add("OdometroAnterior", this.OdometroAnterior);
                if (!AppHelper.IsNullOrEmpty(this.Comentarios)) m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("Pasaje", this.Pasaje);
                m_params.Add("ValesGas", this.ValesGas);
                m_params.Add("CallCenter", this.CallCenter);
                m_params.Add("OtrosCargos", this.OtrosCargos);
                m_params.Add("PagaCon", this.PagaCon);
                m_params.Add("ValesPrePagados", this.ValesPrePagados);
                m_params.Add("Ajuste", this.Ajuste);
                if (!AppHelper.IsNullOrEmpty(this.Autorizacion)) m_params.Add("Autorizacion", this.Autorizacion);
                m_params.Add("SaldoPasaje", this.SaldoPasaje);
                m_params.Add("SaldoCallCenter", this.SaldoCallCenter);
                m_params.Add("SaldoOtrosCargos", this.SaldoOtrosCargos);
                m_params.Add("SaldoCuotaVales", this.SaldoCuotaVales);
                m_params.Add("MantenimPend", this.MantenimPend);
                m_params.Add("AltaUsr", this.AltaUsr);
                m_params.Add("AltaFecha", this.AltaFecha);
                m_params.Add("AltaHora", this.AltaHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifFecha)) m_params.Add("ModifFecha", this.ModifFecha);
                if (!AppHelper.IsNullOrEmpty(this.ModifHora)) m_params.Add("ModifHora", this.ModifHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifUsr)) m_params.Add("ModifUsr", this.ModifUsr);
                if (!AppHelper.IsNullOrEmpty(this.FolioEmpate)) m_params.Add("FolioEmpate", this.FolioEmpate);
                if (!AppHelper.IsNullOrEmpty(this.Planilla)) m_params.Add("Planilla", this.Planilla);
                if (!AppHelper.IsNullOrEmpty(this.ReciboGas)) m_params.Add("ReciboGas", this.ReciboGas);
                if (!AppHelper.IsNullOrEmpty(this.Estacion)) m_params.Add("Estacion", this.Estacion);
                if (!AppHelper.IsNullOrEmpty(this.ServiceCenter)) m_params.Add("ServiceCenter", this.ServiceCenter);
                if (!AppHelper.IsNullOrEmpty(this.SaldoServiceCent)) m_params.Add("SaldoServiceCent", this.SaldoServiceCent);
                if (!AppHelper.IsNullOrEmpty(this.PagoEquipo)) m_params.Add("PagoEquipo", this.PagoEquipo);
                if (!AppHelper.IsNullOrEmpty(this.SaldoEquipo)) m_params.Add("SaldoEquipo", this.SaldoEquipo);
                if (!AppHelper.IsNullOrEmpty(this.Carnet)) m_params.Add("Carnet", this.Carnet);
                if (!AppHelper.IsNullOrEmpty(this.SaldoCarnet)) m_params.Add("SaldoCarnet", this.SaldoCarnet);
                if (!AppHelper.IsNullOrEmpty(this.PAGOUNIDAD)) m_params.Add("PAGOUNIDAD", this.PAGOUNIDAD);
                if (!AppHelper.IsNullOrEmpty(this.SALDOPAGOUNIDAD)) m_params.Add("SALDOPAGOUNIDAD", this.SALDOPAGOUNIDAD);
                if (!AppHelper.IsNullOrEmpty(this.MANTENIMIENTOCONDUCTOR)) m_params.Add("MANTENIMIENTOCONDUCTOR", this.MANTENIMIENTOCONDUCTOR);
                if (!AppHelper.IsNullOrEmpty(this.SALDOMANTENIMIENTOCONDUCTOR)) m_params.Add("SALDOMANTENIMIENTOCONDUCTOR", this.SALDOMANTENIMIENTOCONDUCTOR);

                return DB.UpdateRow("RecibosSarec", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RecibosSarec", w_params);
            } // End Delete

        } //End Class RecibosSarec

        public class RecibosValesPrepagados
        {

            public RecibosValesPrepagados()
            {
            }

            public RecibosValesPrepagados(int estacion, int recibo, string vale)
            {
                this.Estacion = estacion;
                this.Recibo = recibo;
                this.Vale = vale;
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Recibo;
            public int Recibo
            {
                get { return _Recibo; }
                set { _Recibo = value; }
            }

            private string _Vale;
            public string Vale
            {
                get { return _Vale; }
                set { _Vale = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Recibo", this.Recibo);
                m_params.Add("Vale", this.Vale);

                return DB.InsertRow("RecibosValesPrepagados", m_params);
            } // End Create

            public static List<RecibosValesPrepagados> Read()
            {
                List<RecibosValesPrepagados> list = new List<RecibosValesPrepagados>();
                DataTable dt = DB.Select("RecibosValesPrepagados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RecibosValesPrepagados(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToString(dr["Vale"])));
                }

                return list;
            } // End Read

            public static RecibosValesPrepagados Read(string vale)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Vale", vale);
                DataTable dt = DB.Select("RecibosValesPrepagados", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RecibosValesPrepagados con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RecibosValesPrepagados(Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Recibo"]), Convert.ToString(dr["Vale"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Recibo", this.Recibo);
                w_params.Add("Vale", this.Vale);

                return DB.UpdateRow("RecibosValesPrepagados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Vale", this.Vale);

                return DB.DeleteRow("RecibosValesPrepagados", w_params);
            } // End Delete

        } //End Class RecibosValesPrepagados

        public class Refacciones
        {

            public Refacciones()
            {
            }

            public Refacciones(int folio, int tipo, int modelo, int? año, string pasillo, string estante, string nivel, string seccion, DateTime fechaalta, string usuarioalta, string numerodeparte, decimal? costo, string descripcion, int? marca, decimal? precioint, decimal? margenint, decimal? precioext, decimal? margenext)
            {
                this.Folio = folio;
                this.Tipo = tipo;
                this.Modelo = modelo;
                this.Año = año;
                this.Pasillo = pasillo;
                this.Estante = estante;
                this.Nivel = nivel;
                this.Seccion = seccion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.NumeroDeParte = numerodeparte;
                this.Costo = costo;
                this.Descripcion = descripcion;
                this.Marca = marca;
                this.PrecioInt = precioint;
                this.MargenInt = margenint;
                this.PrecioExt = precioext;
                this.MargenExt = margenext;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Modelo;
            public int Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private int? _Año;
            public int? Año
            {
                get { return _Año; }
                set { _Año = value; }
            }

            private string _Pasillo;
            public string Pasillo
            {
                get { return _Pasillo; }
                set { _Pasillo = value; }
            }

            private string _Estante;
            public string Estante
            {
                get { return _Estante; }
                set { _Estante = value; }
            }

            private string _Nivel;
            public string Nivel
            {
                get { return _Nivel; }
                set { _Nivel = value; }
            }

            private string _Seccion;
            public string Seccion
            {
                get { return _Seccion; }
                set { _Seccion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private string _NumeroDeParte;
            public string NumeroDeParte
            {
                get { return _NumeroDeParte; }
                set { _NumeroDeParte = value; }
            }

            private decimal? _Costo;
            public decimal? Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private decimal? _PrecioInt;
            public decimal? PrecioInt
            {
                get { return _PrecioInt; }
                set { _PrecioInt = value; }
            }

            private decimal? _MargenInt;
            public decimal? MargenInt
            {
                get { return _MargenInt; }
                set { _MargenInt = value; }
            }

            private decimal? _PrecioExt;
            public decimal? PrecioExt
            {
                get { return _PrecioExt; }
                set { _PrecioExt = value; }
            }

            private decimal? _MargenExt;
            public decimal? MargenExt
            {
                get { return _MargenExt; }
                set { _MargenExt = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Modelo", this.Modelo);
                if (!AppHelper.IsNullOrEmpty(this.Año)) m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Pasillo)) m_params.Add("Pasillo", this.Pasillo);
                if (!AppHelper.IsNullOrEmpty(this.Estante)) m_params.Add("Estante", this.Estante);
                if (!AppHelper.IsNullOrEmpty(this.Nivel)) m_params.Add("Nivel", this.Nivel);
                if (!AppHelper.IsNullOrEmpty(this.Seccion)) m_params.Add("Seccion", this.Seccion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.NumeroDeParte)) m_params.Add("NumeroDeParte", this.NumeroDeParte);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.PrecioInt)) m_params.Add("PrecioInt", this.PrecioInt);
                if (!AppHelper.IsNullOrEmpty(this.MargenInt)) m_params.Add("MargenInt", this.MargenInt);
                if (!AppHelper.IsNullOrEmpty(this.PrecioExt)) m_params.Add("PrecioExt", this.PrecioExt);
                if (!AppHelper.IsNullOrEmpty(this.MargenExt)) m_params.Add("MargenExt", this.MargenExt);

                return DB.InsertRow("Refacciones", m_params);
            } // End Create

            public static List<Refacciones> Read()
            {
                List<Refacciones> list = new List<Refacciones>();
                DataTable dt = DB.Select("Refacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Refacciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Modelo"]), DB.GetNullableInt32(dr["Año"]), Convert.ToString(dr["Pasillo"]), Convert.ToString(dr["Estante"]), Convert.ToString(dr["Nivel"]), Convert.ToString(dr["Seccion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["NumeroDeParte"]), DB.GetNullableDecimal(dr["Costo"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableDecimal(dr["PrecioInt"]), DB.GetNullableDecimal(dr["MargenInt"]), DB.GetNullableDecimal(dr["PrecioExt"]), DB.GetNullableDecimal(dr["MargenExt"])));
                }

                return list;
            } // End Read

            public static Refacciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Refacciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Refacciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Refacciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Modelo"]), DB.GetNullableInt32(dr["Año"]), Convert.ToString(dr["Pasillo"]), Convert.ToString(dr["Estante"]), Convert.ToString(dr["Nivel"]), Convert.ToString(dr["Seccion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["NumeroDeParte"]), DB.GetNullableDecimal(dr["Costo"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableDecimal(dr["PrecioInt"]), DB.GetNullableDecimal(dr["MargenInt"]), DB.GetNullableDecimal(dr["PrecioExt"]), DB.GetNullableDecimal(dr["MargenExt"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Modelo", this.Modelo);
                if (!AppHelper.IsNullOrEmpty(this.Año)) m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Pasillo)) m_params.Add("Pasillo", this.Pasillo);
                if (!AppHelper.IsNullOrEmpty(this.Estante)) m_params.Add("Estante", this.Estante);
                if (!AppHelper.IsNullOrEmpty(this.Nivel)) m_params.Add("Nivel", this.Nivel);
                if (!AppHelper.IsNullOrEmpty(this.Seccion)) m_params.Add("Seccion", this.Seccion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.NumeroDeParte)) m_params.Add("NumeroDeParte", this.NumeroDeParte);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.PrecioInt)) m_params.Add("PrecioInt", this.PrecioInt);
                if (!AppHelper.IsNullOrEmpty(this.MargenInt)) m_params.Add("MargenInt", this.MargenInt);
                if (!AppHelper.IsNullOrEmpty(this.PrecioExt)) m_params.Add("PrecioExt", this.PrecioExt);
                if (!AppHelper.IsNullOrEmpty(this.MargenExt)) m_params.Add("MargenExt", this.MargenExt);

                return DB.UpdateRow("Refacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Refacciones", w_params);
            } // End Delete

        } //End Class Refacciones

        public class RefaccionesCostos
        {

            public RefaccionesCostos()
            {
            }

            public RefaccionesCostos(int refaccion, int proveedor, int marca, int costounitario)
            {
                this.Refaccion = refaccion;
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Marca = marca;
                this.CostoUnitario = costounitario;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int _CostoUnitario;
            public int CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);

                return DB.InsertRow("RefaccionesCostos", m_params);
            } // End Create

            public static List<RefaccionesCostos> Read()
            {
                List<RefaccionesCostos> list = new List<RefaccionesCostos>();
                DataTable dt = DB.Select("RefaccionesCostos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesCostos(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["CostoUnitario"])));
                }

                return list;
            } // End Read

            public static RefaccionesCostos Read(int refaccion, int proveedor, int marca)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", refaccion);
                w_params.Add("Proveedor", proveedor);
                w_params.Add("Marca", marca);
                DataTable dt = DB.Select("RefaccionesCostos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RefaccionesCostos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RefaccionesCostos(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToInt32(dr["CostoUnitario"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                w_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                w_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                w_params.Add("Marca", this.Marca);
                m_params.Add("CostoUnitario", this.CostoUnitario);

                return DB.UpdateRow("RefaccionesCostos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", this.Refaccion);
                w_params.Add("Proveedor", this.Proveedor);
                w_params.Add("Marca", this.Marca);

                return DB.DeleteRow("RefaccionesCostos", w_params);
            } // End Delete

        } //End Class RefaccionesCostos

        public class RefaccionesCotizacion
        {

            public RefaccionesCotizacion()
            {
            }

            public RefaccionesCotizacion(int cotizacion, int servicio, string refaccion, decimal preciounitario, int cantidad)
            {
                this.Cotizacion = cotizacion;
                this.Servicio = servicio;
                this.Refaccion = refaccion;
                this.PrecioUnitario = preciounitario;
                this.Cantidad = cantidad;
            }

            private int _Cotizacion;
            public int Cotizacion
            {
                get { return _Cotizacion; }
                set { _Cotizacion = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private string _Refaccion;
            public string Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private decimal _PrecioUnitario;
            public decimal PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Cotizacion", this.Cotizacion);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.InsertRow("RefaccionesCotizacion", m_params);
            } // End Create

            public static List<RefaccionesCotizacion> Read()
            {
                List<RefaccionesCotizacion> list = new List<RefaccionesCotizacion>();
                DataTable dt = DB.Select("RefaccionesCotizacion");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesCotizacion(Convert.ToInt32(dr["Cotizacion"]), Convert.ToInt32(dr["Servicio"]), Convert.ToString(dr["Refaccion"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToInt32(dr["Cantidad"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Cotizacion", this.Cotizacion);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.UpdateRow("RefaccionesCotizacion", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RefaccionesCotizacion", w_params);
            } // End Delete

        } //End Class RefaccionesCotizacion

        public class RefaccionesMargenes
        {

            public RefaccionesMargenes()
            {
            }

            public RefaccionesMargenes(int refaccion, int tipocliente, decimal margenutilidad)
            {
                this.Refaccion = refaccion;
                this.Refaccion = refaccion;
                this.TipoCliente = tipocliente;
                this.TipoCliente = tipocliente;
                this.MargenUtilidad = margenutilidad;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private decimal _MargenUtilidad;
            public decimal MargenUtilidad
            {
                get { return _MargenUtilidad; }
                set { _MargenUtilidad = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("MargenUtilidad", this.MargenUtilidad);

                return DB.InsertRow("RefaccionesMargenes", m_params);
            } // End Create

            public static List<RefaccionesMargenes> Read()
            {
                List<RefaccionesMargenes> list = new List<RefaccionesMargenes>();
                DataTable dt = DB.Select("RefaccionesMargenes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesMargenes(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["MargenUtilidad"])));
                }

                return list;
            } // End Read

            public static RefaccionesMargenes Read(int refaccion, int tipocliente)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", refaccion);
                w_params.Add("TipoCliente", tipocliente);
                DataTable dt = DB.Select("RefaccionesMargenes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RefaccionesMargenes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RefaccionesMargenes(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["MargenUtilidad"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                w_params.Add("Refaccion", this.Refaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                w_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("MargenUtilidad", this.MargenUtilidad);

                return DB.UpdateRow("RefaccionesMargenes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", this.Refaccion);
                w_params.Add("TipoCliente", this.TipoCliente);

                return DB.DeleteRow("RefaccionesMargenes", w_params);
            } // End Delete

        } //End Class RefaccionesMargenes

        public class RefaccionesOrdenTrabajo
        {

            public RefaccionesOrdenTrabajo()
            {
            }

            public RefaccionesOrdenTrabajo(int ordentrabajo, int servicio, string refaccion, decimal preciounitario, int cantidad)
            {
                this.OrdenTrabajo = ordentrabajo;
                this.Servicio = servicio;
                this.Refaccion = refaccion;
                this.PrecioUnitario = preciounitario;
                this.Cantidad = cantidad;
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private string _Refaccion;
            public string Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private decimal _PrecioUnitario;
            public decimal PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.InsertRow("RefaccionesOrdenTrabajo", m_params);
            } // End Create

            public static List<RefaccionesOrdenTrabajo> Read()
            {
                List<RefaccionesOrdenTrabajo> list = new List<RefaccionesOrdenTrabajo>();
                DataTable dt = DB.Select("RefaccionesOrdenTrabajo");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesOrdenTrabajo(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Servicio"]), Convert.ToString(dr["Refaccion"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToInt32(dr["Cantidad"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.UpdateRow("RefaccionesOrdenTrabajo", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RefaccionesOrdenTrabajo", w_params);
            } // End Delete

        } //End Class RefaccionesOrdenTrabajo

        public class RefaccionesPrecios
        {

            public RefaccionesPrecios()
            {
            }

            public RefaccionesPrecios(int refaccion, int tipocliente, int marca, decimal precio)
            {
                this.Refaccion = refaccion;
                this.Refaccion = refaccion;
                this.TipoCliente = tipocliente;
                this.Marca = marca;
                this.Marca = marca;
                this.Precio = precio;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Precio", this.Precio);

                return DB.InsertRow("RefaccionesPrecios", m_params);
            } // End Create

            public static List<RefaccionesPrecios> Read()
            {
                List<RefaccionesPrecios> list = new List<RefaccionesPrecios>();
                DataTable dt = DB.Select("RefaccionesPrecios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesPrecios(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["Precio"])));
                }

                return list;
            } // End Read

            public static RefaccionesPrecios Read(int refaccion, int tipocliente, int marca)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", refaccion);
                w_params.Add("TipoCliente", tipocliente);
                w_params.Add("Marca", marca);
                DataTable dt = DB.Select("RefaccionesPrecios", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RefaccionesPrecios con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RefaccionesPrecios(Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["Precio"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                w_params.Add("Refaccion", this.Refaccion);
                w_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Marca", this.Marca);
                w_params.Add("Marca", this.Marca);
                m_params.Add("Precio", this.Precio);

                return DB.UpdateRow("RefaccionesPrecios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Refaccion", this.Refaccion);
                w_params.Add("TipoCliente", this.TipoCliente);
                w_params.Add("Marca", this.Marca);

                return DB.DeleteRow("RefaccionesPrecios", w_params);
            } // End Delete

        } //End Class RefaccionesPrecios

        public class RefaccionesTaller
        {

            public RefaccionesTaller()
            {
            }

            public RefaccionesTaller(int folio, int tipo, int modelo, int? año, string pasillo, string estante, string nivel, string seccion, DateTime fechaalta, string usuarioalta, string numerodeparte, decimal? costo, string descripcion, int? marca)
            {
                this.Folio = folio;
                this.Tipo = tipo;
                this.Modelo = modelo;
                this.Año = año;
                this.Pasillo = pasillo;
                this.Estante = estante;
                this.Nivel = nivel;
                this.Seccion = seccion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.NumeroDeParte = numerodeparte;
                this.Costo = costo;
                this.Descripcion = descripcion;
                this.Marca = marca;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _Modelo;
            public int Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private int? _Año;
            public int? Año
            {
                get { return _Año; }
                set { _Año = value; }
            }

            private string _Pasillo;
            public string Pasillo
            {
                get { return _Pasillo; }
                set { _Pasillo = value; }
            }

            private string _Estante;
            public string Estante
            {
                get { return _Estante; }
                set { _Estante = value; }
            }

            private string _Nivel;
            public string Nivel
            {
                get { return _Nivel; }
                set { _Nivel = value; }
            }

            private string _Seccion;
            public string Seccion
            {
                get { return _Seccion; }
                set { _Seccion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private string _NumeroDeParte;
            public string NumeroDeParte
            {
                get { return _NumeroDeParte; }
                set { _NumeroDeParte = value; }
            }

            private decimal? _Costo;
            public decimal? Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Modelo", this.Modelo);
                if (!AppHelper.IsNullOrEmpty(this.Año)) m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Pasillo)) m_params.Add("Pasillo", this.Pasillo);
                if (!AppHelper.IsNullOrEmpty(this.Estante)) m_params.Add("Estante", this.Estante);
                if (!AppHelper.IsNullOrEmpty(this.Nivel)) m_params.Add("Nivel", this.Nivel);
                if (!AppHelper.IsNullOrEmpty(this.Seccion)) m_params.Add("Seccion", this.Seccion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.NumeroDeParte)) m_params.Add("NumeroDeParte", this.NumeroDeParte);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);

                return DB.InsertRow("RefaccionesTaller", m_params);
            } // End Create

            public static List<RefaccionesTaller> Read()
            {
                List<RefaccionesTaller> list = new List<RefaccionesTaller>();
                DataTable dt = DB.Select("RefaccionesTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RefaccionesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["Modelo"]), DB.GetNullableInt32(dr["Año"]), Convert.ToString(dr["Pasillo"]), Convert.ToString(dr["Estante"]), Convert.ToString(dr["Nivel"]), Convert.ToString(dr["Seccion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["NumeroDeParte"]), DB.GetNullableDecimal(dr["Costo"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableInt32(dr["Marca"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("Modelo", this.Modelo);
                if (!AppHelper.IsNullOrEmpty(this.Año)) m_params.Add("Año", this.Año);
                if (!AppHelper.IsNullOrEmpty(this.Pasillo)) m_params.Add("Pasillo", this.Pasillo);
                if (!AppHelper.IsNullOrEmpty(this.Estante)) m_params.Add("Estante", this.Estante);
                if (!AppHelper.IsNullOrEmpty(this.Nivel)) m_params.Add("Nivel", this.Nivel);
                if (!AppHelper.IsNullOrEmpty(this.Seccion)) m_params.Add("Seccion", this.Seccion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.NumeroDeParte)) m_params.Add("NumeroDeParte", this.NumeroDeParte);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);

                return DB.UpdateRow("RefaccionesTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RefaccionesTaller", w_params);
            } // End Delete

        } //End Class RefaccionesTaller

        public class RegistroInsercionInventario
        {

            public RegistroInsercionInventario()
            {
            }

            public RegistroInsercionInventario(int? refaccion, int? proveedor, int? marca, int? tipo, int? cantidad, int? costo, string usuario, DateTime? fecha, string tipoactualizacion)
            {
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Tipo = tipo;
                this.Cantidad = cantidad;
                this.Costo = costo;
                this.Usuario = usuario;
                this.Fecha = fecha;
                this.TipoActualizacion = tipoactualizacion;
            }

            private int? _Refaccion;
            public int? Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int? _Proveedor;
            public int? Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int? _Marca;
            public int? Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private int? _Tipo;
            public int? Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int? _Cantidad;
            public int? Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private int? _Costo;
            public int? Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _TipoActualizacion;
            public string TipoActualizacion
            {
                get { return _TipoActualizacion; }
                set { _TipoActualizacion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.TipoActualizacion)) m_params.Add("TipoActualizacion", this.TipoActualizacion);

                return DB.InsertRow("RegistroInsercionInventario", m_params);
            } // End Create

            public static List<RegistroInsercionInventario> Read()
            {
                List<RegistroInsercionInventario> list = new List<RegistroInsercionInventario>();
                DataTable dt = DB.Select("RegistroInsercionInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RegistroInsercionInventario(DB.GetNullableInt32(dr["Refaccion"]), DB.GetNullableInt32(dr["Proveedor"]), DB.GetNullableInt32(dr["Marca"]), DB.GetNullableInt32(dr["Tipo"]), DB.GetNullableInt32(dr["Cantidad"]), DB.GetNullableInt32(dr["Costo"]), Convert.ToString(dr["Usuario"]), DB.GetNullableDateTime(dr["Fecha"]), Convert.ToString(dr["TipoActualizacion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Refaccion)) m_params.Add("Refaccion", this.Refaccion);
                if (!AppHelper.IsNullOrEmpty(this.Proveedor)) m_params.Add("Proveedor", this.Proveedor);
                if (!AppHelper.IsNullOrEmpty(this.Marca)) m_params.Add("Marca", this.Marca);
                if (!AppHelper.IsNullOrEmpty(this.Tipo)) m_params.Add("Tipo", this.Tipo);
                if (!AppHelper.IsNullOrEmpty(this.Cantidad)) m_params.Add("Cantidad", this.Cantidad);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.TipoActualizacion)) m_params.Add("TipoActualizacion", this.TipoActualizacion);

                return DB.UpdateRow("RegistroInsercionInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RegistroInsercionInventario", w_params);
            } // End Delete

        } //End Class RegistroInsercionInventario

        public class RegistroKilometrajesUnidades
        {

            public RegistroKilometrajesUnidades()
            {
            }

            public RegistroKilometrajesUnidades(int unidad, int conductoractual, int kilometraje, DateTime fecha)
            {
                this.Unidad = unidad;
                this.ConductorActual = conductoractual;
                this.Kilometraje = kilometraje;
                this.Fecha = fecha;
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _ConductorActual;
            public int ConductorActual
            {
                get { return _ConductorActual; }
                set { _ConductorActual = value; }
            }

            private int _Kilometraje;
            public int Kilometraje
            {
                get { return _Kilometraje; }
                set { _Kilometraje = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("ConductorActual", this.ConductorActual);
                m_params.Add("Kilometraje", this.Kilometraje);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("RegistroKilometrajesUnidades", m_params);
            } // End Create

            public static List<RegistroKilometrajesUnidades> Read()
            {
                List<RegistroKilometrajesUnidades> list = new List<RegistroKilometrajesUnidades>();
                DataTable dt = DB.Select("RegistroKilometrajesUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RegistroKilometrajesUnidades(Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["ConductorActual"]), Convert.ToInt32(dr["Kilometraje"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("ConductorActual", this.ConductorActual);
                m_params.Add("Kilometraje", this.Kilometraje);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("RegistroKilometrajesUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RegistroKilometrajesUnidades", w_params);
            } // End Delete

        } //End Class RegistroKilometrajesUnidades

        public class RegistroLocacionesUnidades
        {

            public RegistroLocacionesUnidades()
            {
            }

            public RegistroLocacionesUnidades(int unidad, int locacion, DateTime fecha, string usuario)
            {
                this.Unidad = unidad;
                this.Locacion = locacion;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Locacion;
            public int Locacion
            {
                get { return _Locacion; }
                set { _Locacion = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Locacion", this.Locacion);
                m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("RegistroLocacionesUnidades", m_params);
            } // End Create

            public static List<RegistroLocacionesUnidades> Read()
            {
                List<RegistroLocacionesUnidades> list = new List<RegistroLocacionesUnidades>();
                DataTable dt = DB.Select("RegistroLocacionesUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RegistroLocacionesUnidades(Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Locacion"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Locacion", this.Locacion);
                m_params.Add("Fecha", this.Fecha);
                if (!AppHelper.IsNullOrEmpty(this.Usuario)) m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("RegistroLocacionesUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RegistroLocacionesUnidades", w_params);
            } // End Delete

        } //End Class RegistroLocacionesUnidades

        public class RegistroPublicitario
        {

            public RegistroPublicitario()
            {
            }

            public RegistroPublicitario(int folio, int conductor, int mediopublicitario, bool cumplioperfil, bool interesado, int planempresarial, string comentarios, DateTime fechaalta, string usuarioalta, int? edad, string estadocivil, int? añosexperiencia)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.MedioPublicitario = mediopublicitario;
                this.CumplioPerfil = cumplioperfil;
                this.Interesado = interesado;
                this.PlanEmpresarial = planempresarial;
                this.Comentarios = comentarios;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.Edad = edad;
                this.EstadoCivil = estadocivil;
                this.AñosExperiencia = añosexperiencia;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _MedioPublicitario;
            public int MedioPublicitario
            {
                get { return _MedioPublicitario; }
                set { _MedioPublicitario = value; }
            }

            private bool _CumplioPerfil;
            public bool CumplioPerfil
            {
                get { return _CumplioPerfil; }
                set { _CumplioPerfil = value; }
            }

            private bool _Interesado;
            public bool Interesado
            {
                get { return _Interesado; }
                set { _Interesado = value; }
            }

            private int _PlanEmpresarial;
            public int PlanEmpresarial
            {
                get { return _PlanEmpresarial; }
                set { _PlanEmpresarial = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _Edad;
            public int? Edad
            {
                get { return _Edad; }
                set { _Edad = value; }
            }

            private string _EstadoCivil;
            public string EstadoCivil
            {
                get { return _EstadoCivil; }
                set { _EstadoCivil = value; }
            }

            private int? _AñosExperiencia;
            public int? AñosExperiencia
            {
                get { return _AñosExperiencia; }
                set { _AñosExperiencia = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("MedioPublicitario", this.MedioPublicitario);
                m_params.Add("CumplioPerfil", this.CumplioPerfil);
                m_params.Add("Interesado", this.Interesado);
                m_params.Add("PlanEmpresarial", this.PlanEmpresarial);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Edad)) m_params.Add("Edad", this.Edad);
                if (!AppHelper.IsNullOrEmpty(this.EstadoCivil)) m_params.Add("EstadoCivil", this.EstadoCivil);
                if (!AppHelper.IsNullOrEmpty(this.AñosExperiencia)) m_params.Add("AñosExperiencia", this.AñosExperiencia);

                return DB.InsertRow("RegistroPublicitario", m_params);
            } // End Create

            public static List<RegistroPublicitario> Read()
            {
                List<RegistroPublicitario> list = new List<RegistroPublicitario>();
                DataTable dt = DB.Select("RegistroPublicitario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RegistroPublicitario(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["MedioPublicitario"]), Convert.ToBoolean(dr["CumplioPerfil"]), Convert.ToBoolean(dr["Interesado"]), Convert.ToInt32(dr["PlanEmpresarial"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["Edad"]), Convert.ToString(dr["EstadoCivil"]), DB.GetNullableInt32(dr["AñosExperiencia"])));
                }

                return list;
            } // End Read

            public static RegistroPublicitario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("RegistroPublicitario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RegistroPublicitario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RegistroPublicitario(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["MedioPublicitario"]), Convert.ToBoolean(dr["CumplioPerfil"]), Convert.ToBoolean(dr["Interesado"]), Convert.ToInt32(dr["PlanEmpresarial"]), Convert.ToString(dr["Comentarios"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["Edad"]), Convert.ToString(dr["EstadoCivil"]), DB.GetNullableInt32(dr["AñosExperiencia"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("MedioPublicitario", this.MedioPublicitario);
                m_params.Add("CumplioPerfil", this.CumplioPerfil);
                m_params.Add("Interesado", this.Interesado);
                m_params.Add("PlanEmpresarial", this.PlanEmpresarial);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Edad)) m_params.Add("Edad", this.Edad);
                if (!AppHelper.IsNullOrEmpty(this.EstadoCivil)) m_params.Add("EstadoCivil", this.EstadoCivil);
                if (!AppHelper.IsNullOrEmpty(this.AñosExperiencia)) m_params.Add("AñosExperiencia", this.AñosExperiencia);

                return DB.UpdateRow("RegistroPublicitario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("RegistroPublicitario", w_params);
            } // End Delete

        } //End Class RegistroPublicitario

        public class RentasCausalidad
        {

            public RentasCausalidad()
            {
            }

            public RentasCausalidad(int folio, int causalidad, int conductor, int unidad, decimal monto, DateTime fecha, string usuarioalta)
            {
                this.Folio = folio;
                this.Causalidad = causalidad;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Monto = monto;
                this.Fecha = fecha;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Causalidad;
            public int Causalidad
            {
                get { return _Causalidad; }
                set { _Causalidad = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private decimal _Monto;
            public decimal Monto
            {
                get { return _Monto; }
                set { _Monto = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Causalidad", this.Causalidad);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("RentasCausalidad", m_params);
            } // End Create

            public static List<RentasCausalidad> Read()
            {
                List<RentasCausalidad> list = new List<RentasCausalidad>();
                DataTable dt = DB.Select("RentasCausalidad");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RentasCausalidad(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Causalidad"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static RentasCausalidad Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("RentasCausalidad", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RentasCausalidad con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RentasCausalidad(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Causalidad"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDecimal(dr["Monto"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Causalidad", this.Causalidad);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Monto", this.Monto);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("RentasCausalidad", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("RentasCausalidad", w_params);
            } // End Delete

        } //End Class RentasCausalidad

        public class RespuestasCreditoTaller
        {

            public RespuestasCreditoTaller()
            {
            }

            public RespuestasCreditoTaller(int ordentrabajo, bool procede, string motivo, string usuario, DateTime fecha, int status)
            {
                this.Ordentrabajo = ordentrabajo;
                this.Procede = procede;
                this.Motivo = motivo;
                this.Usuario = usuario;
                this.Fecha = fecha;
                this.Status = status;
            }

            private int _Ordentrabajo;
            public int Ordentrabajo
            {
                get { return _Ordentrabajo; }
                set { _Ordentrabajo = value; }
            }

            private bool _Procede;
            public bool Procede
            {
                get { return _Procede; }
                set { _Procede = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Ordentrabajo", this.Ordentrabajo);
                m_params.Add("Procede", this.Procede);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("RespuestasCreditoTaller", m_params);
            } // End Create

            public static List<RespuestasCreditoTaller> Read()
            {
                List<RespuestasCreditoTaller> list = new List<RespuestasCreditoTaller>();
                DataTable dt = DB.Select("RespuestasCreditoTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RespuestasCreditoTaller(Convert.ToInt32(dr["Ordentrabajo"]), Convert.ToBoolean(dr["Procede"]), Convert.ToString(dr["Motivo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public static RespuestasCreditoTaller Read(int ordentrabajo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Ordentrabajo", ordentrabajo);
                DataTable dt = DB.Select("RespuestasCreditoTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe RespuestasCreditoTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new RespuestasCreditoTaller(Convert.ToInt32(dr["Ordentrabajo"]), Convert.ToBoolean(dr["Procede"]), Convert.ToString(dr["Motivo"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToInt32(dr["Status"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Ordentrabajo", this.Ordentrabajo);
                m_params.Add("Procede", this.Procede);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("RespuestasCreditoTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Ordentrabajo", this.Ordentrabajo);

                return DB.DeleteRow("RespuestasCreditoTaller", w_params);
            } // End Delete

        } //End Class RespuestasCreditoTaller

        public class Retrabajos
        {

            public Retrabajos()
            {
            }

            public Retrabajos(int folio, int ordenservicio, int mecanico, int servicio, DateTime fecha, string comentarios, string usuarioalta)
            {
                this.Folio = folio;
                this.OrdenServicio = ordenservicio;
                this.Mecanico = mecanico;
                this.Servicio = servicio;
                this.Fecha = fecha;
                this.Comentarios = comentarios;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _OrdenServicio;
            public int OrdenServicio
            {
                get { return _OrdenServicio; }
                set { _OrdenServicio = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Comentarios;
            public string Comentarios
            {
                get { return _Comentarios; }
                set { _Comentarios = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Retrabajos", m_params);
            } // End Create

            public static List<Retrabajos> Read()
            {
                List<Retrabajos> list = new List<Retrabajos>();
                DataTable dt = DB.Select("Retrabajos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Retrabajos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToInt32(dr["Servicio"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Comentarios"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Retrabajos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Retrabajos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Retrabajos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Retrabajos(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Mecanico"]), Convert.ToInt32(dr["Servicio"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Comentarios"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Mecanico", this.Mecanico);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Comentarios", this.Comentarios);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Retrabajos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Retrabajos", w_params);
            } // End Delete

        } //End Class Retrabajos

        public class Roles
        {

            public Roles()
            {
            }

            public Roles(int folio, int sistema, string descripcion)
            {
                this.Folio = folio;
                this.Sistema = sistema;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Sistema;
            public int Sistema
            {
                get { return _Sistema; }
                set { _Sistema = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Sistema", this.Sistema);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Roles", m_params);
            } // End Create

            public static List<Roles> Read()
            {
                List<Roles> list = new List<Roles>();
                DataTable dt = DB.Select("Roles");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Roles(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Sistema"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static Roles Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Roles", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Roles con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Roles(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Sistema"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Sistema", this.Sistema);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Roles", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Roles", w_params);
            } // End Delete

        } //End Class Roles

        public class RolesUsuarios
        {

            public RolesUsuarios()
            {
            }

            public RolesUsuarios(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("RolesUsuarios", m_params);
            } // End Create

            public static List<RolesUsuarios> Read()
            {
                List<RolesUsuarios> list = new List<RolesUsuarios>();
                DataTable dt = DB.Select("RolesUsuarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new RolesUsuarios(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("RolesUsuarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("RolesUsuarios", w_params);
            } // End Delete

        } //End Class RolesUsuarios

        public class SegurosUnidades
        {

            public SegurosUnidades()
            {
            }

            public SegurosUnidades(int unidad, string numeropoliza, int aseguradora, string detalles, decimal deducible, DateTime fechainicial, DateTime fechafinal, DateTime fechaalta, string usuarioalta, string inciso, int? cobertura, int empresaestacion, int? numeroeconomico)
            {
                this.Unidad = unidad;
                this.NumeroPoliza = numeropoliza;
                this.Aseguradora = aseguradora;
                this.Detalles = detalles;
                this.Deducible = deducible;
                this.FechaInicial = fechainicial;
                this.FechaFinal = fechafinal;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.Inciso = inciso;
                this.Cobertura = cobertura;
                this.EmpresaEstacion = empresaestacion;
                this.EmpresaEstacion = empresaestacion;
                this.NumeroEconomico = numeroeconomico;
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private string _NumeroPoliza;
            public string NumeroPoliza
            {
                get { return _NumeroPoliza; }
                set { _NumeroPoliza = value; }
            }

            private int _Aseguradora;
            public int Aseguradora
            {
                get { return _Aseguradora; }
                set { _Aseguradora = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private decimal _Deducible;
            public decimal Deducible
            {
                get { return _Deducible; }
                set { _Deducible = value; }
            }

            private DateTime _FechaInicial;
            public DateTime FechaInicial
            {
                get { return _FechaInicial; }
                set { _FechaInicial = value; }
            }

            private DateTime _FechaFinal;
            public DateTime FechaFinal
            {
                get { return _FechaFinal; }
                set { _FechaFinal = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private string _Inciso;
            public string Inciso
            {
                get { return _Inciso; }
                set { _Inciso = value; }
            }

            private int? _Cobertura;
            public int? Cobertura
            {
                get { return _Cobertura; }
                set { _Cobertura = value; }
            }

            private int _EmpresaEstacion;
            public int EmpresaEstacion
            {
                get { return _EmpresaEstacion; }
                set { _EmpresaEstacion = value; }
            }

            private int? _NumeroEconomico;
            public int? NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroPoliza", this.NumeroPoliza);
                m_params.Add("Aseguradora", this.Aseguradora);
                m_params.Add("Detalles", this.Detalles);
                m_params.Add("Deducible", this.Deducible);
                m_params.Add("FechaInicial", this.FechaInicial);
                m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Inciso)) m_params.Add("Inciso", this.Inciso);
                if (!AppHelper.IsNullOrEmpty(this.Cobertura)) m_params.Add("Cobertura", this.Cobertura);
                m_params.Add("EmpresaEstacion", this.EmpresaEstacion);
                m_params.Add("EmpresaEstacion", this.EmpresaEstacion);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);

                return DB.InsertRow("SegurosUnidades", m_params);
            } // End Create

            public static List<SegurosUnidades> Read()
            {
                List<SegurosUnidades> list = new List<SegurosUnidades>();
                DataTable dt = DB.Select("SegurosUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new SegurosUnidades(Convert.ToInt32(dr["Unidad"]), Convert.ToString(dr["NumeroPoliza"]), Convert.ToInt32(dr["Aseguradora"]), Convert.ToString(dr["Detalles"]), Convert.ToDecimal(dr["Deducible"]), Convert.ToDateTime(dr["FechaInicial"]), Convert.ToDateTime(dr["FechaFinal"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Inciso"]), DB.GetNullableInt32(dr["Cobertura"]), Convert.ToInt32(dr["EmpresaEstacion"]), DB.GetNullableInt32(dr["NumeroEconomico"])));
                }

                return list;
            } // End Read

            public static SegurosUnidades Read(int unidad, int empresaestacion)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Unidad", unidad);
                w_params.Add("EmpresaEstacion", empresaestacion);
                DataTable dt = DB.Select("SegurosUnidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe SegurosUnidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new SegurosUnidades(Convert.ToInt32(dr["Unidad"]), Convert.ToString(dr["NumeroPoliza"]), Convert.ToInt32(dr["Aseguradora"]), Convert.ToString(dr["Detalles"]), Convert.ToDecimal(dr["Deducible"]), Convert.ToDateTime(dr["FechaInicial"]), Convert.ToDateTime(dr["FechaFinal"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), Convert.ToString(dr["Inciso"]), DB.GetNullableInt32(dr["Cobertura"]), Convert.ToInt32(dr["EmpresaEstacion"]), DB.GetNullableInt32(dr["NumeroEconomico"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Unidad", this.Unidad);
                m_params.Add("NumeroPoliza", this.NumeroPoliza);
                m_params.Add("Aseguradora", this.Aseguradora);
                m_params.Add("Detalles", this.Detalles);
                m_params.Add("Deducible", this.Deducible);
                m_params.Add("FechaInicial", this.FechaInicial);
                m_params.Add("FechaFinal", this.FechaFinal);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.Inciso)) m_params.Add("Inciso", this.Inciso);
                if (!AppHelper.IsNullOrEmpty(this.Cobertura)) m_params.Add("Cobertura", this.Cobertura);
                m_params.Add("EmpresaEstacion", this.EmpresaEstacion);
                w_params.Add("EmpresaEstacion", this.EmpresaEstacion);
                if (!AppHelper.IsNullOrEmpty(this.NumeroEconomico)) m_params.Add("NumeroEconomico", this.NumeroEconomico);

                return DB.UpdateRow("SegurosUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Unidad", this.Unidad);
                w_params.Add("EmpresaEstacion", this.EmpresaEstacion);

                return DB.DeleteRow("SegurosUnidades", w_params);
            } // End Delete

        } //End Class SegurosUnidades

        public class Servicios
        {

            public Servicios()
            {
            }

            public Servicios(int folio, int familia, string descripcion, DateTime fechaalta, string usuarioalta, int? minutosreales, decimal? costo)
            {
                this.Folio = folio;
                this.Familia = familia;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
                this.MinutosReales = minutosreales;
                this.Costo = costo;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Familia;
            public int Familia
            {
                get { return _Familia; }
                set { _Familia = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            private int? _MinutosReales;
            public int? MinutosReales
            {
                get { return _MinutosReales; }
                set { _MinutosReales = value; }
            }

            private decimal? _Costo;
            public decimal? Costo
            {
                get { return _Costo; }
                set { _Costo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.MinutosReales)) m_params.Add("MinutosReales", this.MinutosReales);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);

                return DB.InsertRow("Servicios", m_params);
            } // End Create

            public static List<Servicios> Read()
            {
                List<Servicios> list = new List<Servicios>();
                DataTable dt = DB.Select("Servicios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Servicios(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["MinutosReales"]), DB.GetNullableDecimal(dr["Costo"])));
                }

                return list;
            } // End Read

            public static Servicios Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Servicios", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Servicios con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Servicios(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]), DB.GetNullableInt32(dr["MinutosReales"]), DB.GetNullableDecimal(dr["Costo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);
                if (!AppHelper.IsNullOrEmpty(this.MinutosReales)) m_params.Add("MinutosReales", this.MinutosReales);
                if (!AppHelper.IsNullOrEmpty(this.Costo)) m_params.Add("Costo", this.Costo);

                return DB.UpdateRow("Servicios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Servicios", w_params);
            } // End Delete

        } //End Class Servicios

        public class ServiciosCotizacion
        {

            public ServiciosCotizacion()
            {
            }

            public ServiciosCotizacion(int cotizacion, int servicio, decimal costounitario, int cantidad, int mecanico)
            {
                this.Cotizacion = cotizacion;
                this.Servicio = servicio;
                this.CostoUnitario = costounitario;
                this.Cantidad = cantidad;
                this.Mecanico = mecanico;
            }

            private int _Cotizacion;
            public int Cotizacion
            {
                get { return _Cotizacion; }
                set { _Cotizacion = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Cotizacion", this.Cotizacion);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Mecanico", this.Mecanico);

                return DB.InsertRow("ServiciosCotizacion", m_params);
            } // End Create

            public static List<ServiciosCotizacion> Read()
            {
                List<ServiciosCotizacion> list = new List<ServiciosCotizacion>();
                DataTable dt = DB.Select("ServiciosCotizacion");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosCotizacion(Convert.ToInt32(dr["Cotizacion"]), Convert.ToInt32(dr["Servicio"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToInt32(dr["Mecanico"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Cotizacion", this.Cotizacion);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Mecanico", this.Mecanico);

                return DB.UpdateRow("ServiciosCotizacion", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ServiciosCotizacion", w_params);
            } // End Delete

        } //End Class ServiciosCotizacion

        public class ServiciosEspecificaciones
        {

            public ServiciosEspecificaciones()
            {
            }

            public ServiciosEspecificaciones(int servicio, int categoriamecanico, decimal porcentajecomision, int minutosreales, string usuario, DateTime fecha)
            {
                this.Servicio = servicio;
                this.CategoriaMecanico = categoriamecanico;
                this.PorcentajeComision = porcentajecomision;
                this.MinutosReales = minutosreales;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _CategoriaMecanico;
            public int CategoriaMecanico
            {
                get { return _CategoriaMecanico; }
                set { _CategoriaMecanico = value; }
            }

            private decimal _PorcentajeComision;
            public decimal PorcentajeComision
            {
                get { return _PorcentajeComision; }
                set { _PorcentajeComision = value; }
            }

            private int _MinutosReales;
            public int MinutosReales
            {
                get { return _MinutosReales; }
                set { _MinutosReales = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CategoriaMecanico", this.CategoriaMecanico);
                m_params.Add("PorcentajeComision", this.PorcentajeComision);
                m_params.Add("MinutosReales", this.MinutosReales);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("ServiciosEspecificaciones", m_params);
            } // End Create

            public static List<ServiciosEspecificaciones> Read()
            {
                List<ServiciosEspecificaciones> list = new List<ServiciosEspecificaciones>();
                DataTable dt = DB.Select("ServiciosEspecificaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosEspecificaciones(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["CategoriaMecanico"]), Convert.ToDecimal(dr["PorcentajeComision"]), Convert.ToInt32(dr["MinutosReales"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CategoriaMecanico", this.CategoriaMecanico);
                m_params.Add("PorcentajeComision", this.PorcentajeComision);
                m_params.Add("MinutosReales", this.MinutosReales);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("ServiciosEspecificaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ServiciosEspecificaciones", w_params);
            } // End Delete

        } //End Class ServiciosEspecificaciones

        public class ServiciosOrdenTrabajo
        {

            public ServiciosOrdenTrabajo()
            {
            }

            public ServiciosOrdenTrabajo(int ordentrabajo, int servicio, decimal costounitario, int cantidad, int mecanico)
            {
                this.OrdenTrabajo = ordentrabajo;
                this.Servicio = servicio;
                this.CostoUnitario = costounitario;
                this.Cantidad = cantidad;
                this.Mecanico = mecanico;
            }

            private int _OrdenTrabajo;
            public int OrdenTrabajo
            {
                get { return _OrdenTrabajo; }
                set { _OrdenTrabajo = value; }
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private decimal _CostoUnitario;
            public decimal CostoUnitario
            {
                get { return _CostoUnitario; }
                set { _CostoUnitario = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private int _Mecanico;
            public int Mecanico
            {
                get { return _Mecanico; }
                set { _Mecanico = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Mecanico", this.Mecanico);

                return DB.InsertRow("ServiciosOrdenTrabajo", m_params);
            } // End Create

            public static List<ServiciosOrdenTrabajo> Read()
            {
                List<ServiciosOrdenTrabajo> list = new List<ServiciosOrdenTrabajo>();
                DataTable dt = DB.Select("ServiciosOrdenTrabajo");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosOrdenTrabajo(Convert.ToInt32(dr["OrdenTrabajo"]), Convert.ToInt32(dr["Servicio"]), Convert.ToDecimal(dr["CostoUnitario"]), Convert.ToInt32(dr["Cantidad"]), Convert.ToInt32(dr["Mecanico"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("OrdenTrabajo", this.OrdenTrabajo);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("CostoUnitario", this.CostoUnitario);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("Mecanico", this.Mecanico);

                return DB.UpdateRow("ServiciosOrdenTrabajo", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ServiciosOrdenTrabajo", w_params);
            } // End Delete

        } //End Class ServiciosOrdenTrabajo

        public class ServiciosPreciosManoDeObra
        {

            public ServiciosPreciosManoDeObra()
            {
            }

            public ServiciosPreciosManoDeObra(int servicio, int tipocliente, decimal precio)
            {
                this.Servicio = servicio;
                this.TipoCliente = tipocliente;
                this.Precio = precio;
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _TipoCliente;
            public int TipoCliente
            {
                get { return _TipoCliente; }
                set { _TipoCliente = value; }
            }

            private decimal _Precio;
            public decimal Precio
            {
                get { return _Precio; }
                set { _Precio = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Precio", this.Precio);

                return DB.InsertRow("ServiciosPreciosManoDeObra", m_params);
            } // End Create

            public static List<ServiciosPreciosManoDeObra> Read()
            {
                List<ServiciosPreciosManoDeObra> list = new List<ServiciosPreciosManoDeObra>();
                DataTable dt = DB.Select("ServiciosPreciosManoDeObra");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosPreciosManoDeObra(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["TipoCliente"]), Convert.ToDecimal(dr["Precio"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("TipoCliente", this.TipoCliente);
                m_params.Add("Precio", this.Precio);

                return DB.UpdateRow("ServiciosPreciosManoDeObra", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ServiciosPreciosManoDeObra", w_params);
            } // End Delete

        } //End Class ServiciosPreciosManoDeObra

        public class ServiciosTiemposModelos
        {

            public ServiciosTiemposModelos()
            {
            }

            public ServiciosTiemposModelos(int servicio, int modelo, int minutos, DateTime fecha, string usuario)
            {
                this.Servicio = servicio;
                this.Modelo = modelo;
                this.Minutos = minutos;
                this.Fecha = fecha;
                this.Usuario = usuario;
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _Modelo;
            public int Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private int _Minutos;
            public int Minutos
            {
                get { return _Minutos; }
                set { _Minutos = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Modelo", this.Modelo);
                m_params.Add("Minutos", this.Minutos);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.InsertRow("ServiciosTiemposModelos", m_params);
            } // End Create

            public static List<ServiciosTiemposModelos> Read()
            {
                List<ServiciosTiemposModelos> list = new List<ServiciosTiemposModelos>();
                DataTable dt = DB.Select("ServiciosTiemposModelos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosTiemposModelos(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Modelo"]), Convert.ToInt32(dr["Minutos"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"])));
                }

                return list;
            } // End Read

            public static ServiciosTiemposModelos Read(int servicio, int modelo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Servicio", servicio);
                w_params.Add("Modelo", modelo);
                DataTable dt = DB.Select("ServiciosTiemposModelos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ServiciosTiemposModelos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ServiciosTiemposModelos(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["Modelo"]), Convert.ToInt32(dr["Minutos"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToString(dr["Usuario"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Servicio", this.Servicio);
                w_params.Add("Modelo", this.Modelo);
                m_params.Add("Minutos", this.Minutos);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Usuario", this.Usuario);

                return DB.UpdateRow("ServiciosTiemposModelos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Servicio", this.Servicio);
                w_params.Add("Modelo", this.Modelo);

                return DB.DeleteRow("ServiciosTiemposModelos", w_params);
            } // End Delete

        } //End Class ServiciosTiemposModelos

        public class ServiciosTiposRefacciones
        {

            public ServiciosTiposRefacciones()
            {
            }

            public ServiciosTiposRefacciones(int servicio, int tiporefaccion, int cantidad)
            {
                this.Servicio = servicio;
                this.Servicio = servicio;
                this.TipoRefaccion = tiporefaccion;
                this.TipoRefaccion = tiporefaccion;
                this.Cantidad = cantidad;
            }

            private int _Servicio;
            public int Servicio
            {
                get { return _Servicio; }
                set { _Servicio = value; }
            }

            private int _TipoRefaccion;
            public int TipoRefaccion
            {
                get { return _TipoRefaccion; }
                set { _TipoRefaccion = value; }
            }

            private int _Cantidad;
            public int Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("Servicio", this.Servicio);
                m_params.Add("TipoRefaccion", this.TipoRefaccion);
                m_params.Add("TipoRefaccion", this.TipoRefaccion);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.InsertRow("ServiciosTiposRefacciones", m_params);
            } // End Create

            public static List<ServiciosTiposRefacciones> Read()
            {
                List<ServiciosTiposRefacciones> list = new List<ServiciosTiposRefacciones>();
                DataTable dt = DB.Select("ServiciosTiposRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiciosTiposRefacciones(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["TipoRefaccion"]), Convert.ToInt32(dr["Cantidad"])));
                }

                return list;
            } // End Read

            public static ServiciosTiposRefacciones Read(int servicio, int tiporefaccion)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Servicio", servicio);
                w_params.Add("TipoRefaccion", tiporefaccion);
                DataTable dt = DB.Select("ServiciosTiposRefacciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ServiciosTiposRefacciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ServiciosTiposRefacciones(Convert.ToInt32(dr["Servicio"]), Convert.ToInt32(dr["TipoRefaccion"]), Convert.ToInt32(dr["Cantidad"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Servicio", this.Servicio);
                w_params.Add("Servicio", this.Servicio);
                m_params.Add("TipoRefaccion", this.TipoRefaccion);
                w_params.Add("TipoRefaccion", this.TipoRefaccion);
                m_params.Add("Cantidad", this.Cantidad);

                return DB.UpdateRow("ServiciosTiposRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Servicio", this.Servicio);
                w_params.Add("TipoRefaccion", this.TipoRefaccion);

                return DB.DeleteRow("ServiciosTiposRefacciones", w_params);
            } // End Delete

        } //End Class ServiciosTiposRefacciones

        public class Siniestros
        {

            public Siniestros()
            {
            }

            public Siniestros(int folio, int conductor, int unidad, DateTime fecha, int tipo, int tipoparticipacion, string detalles, int? referenciacobro, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.Fecha = fecha;
                this.Tipo = tipo;
                this.TipoParticipacion = tipoparticipacion;
                this.Detalles = detalles;
                this.ReferenciaCobro = referenciacobro;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Conductor;
            public int Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            private int _Tipo;
            public int Tipo
            {
                get { return _Tipo; }
                set { _Tipo = value; }
            }

            private int _TipoParticipacion;
            public int TipoParticipacion
            {
                get { return _TipoParticipacion; }
                set { _TipoParticipacion = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private int? _ReferenciaCobro;
            public int? ReferenciaCobro
            {
                get { return _ReferenciaCobro; }
                set { _ReferenciaCobro = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("TipoParticipacion", this.TipoParticipacion);
                m_params.Add("Detalles", this.Detalles);
                if (!AppHelper.IsNullOrEmpty(this.ReferenciaCobro)) m_params.Add("ReferenciaCobro", this.ReferenciaCobro);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Siniestros", m_params);
            } // End Create

            public static List<Siniestros> Read()
            {
                List<Siniestros> list = new List<Siniestros>();
                DataTable dt = DB.Select("Siniestros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Siniestros(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["TipoParticipacion"]), Convert.ToString(dr["Detalles"]), DB.GetNullableInt32(dr["ReferenciaCobro"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Siniestros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Siniestros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Siniestros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Siniestros(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToDateTime(dr["Fecha"]), Convert.ToInt32(dr["Tipo"]), Convert.ToInt32(dr["TipoParticipacion"]), Convert.ToString(dr["Detalles"]), DB.GetNullableInt32(dr["ReferenciaCobro"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Fecha", this.Fecha);
                m_params.Add("Tipo", this.Tipo);
                m_params.Add("TipoParticipacion", this.TipoParticipacion);
                m_params.Add("Detalles", this.Detalles);
                if (!AppHelper.IsNullOrEmpty(this.ReferenciaCobro)) m_params.Add("ReferenciaCobro", this.ReferenciaCobro);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Siniestros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Siniestros", w_params);
            } // End Delete

        } //End Class Siniestros

        public class Sobrantes
        {

            public Sobrantes()
            {
            }

            public Sobrantes(int folio, int ordenservicio, int refaccion, int proveedor, int marca, decimal cantidad, decimal preciounitario, decimal total)
            {
                this.Folio = folio;
                this.OrdenServicio = ordenservicio;
                this.Refaccion = refaccion;
                this.Proveedor = proveedor;
                this.Marca = marca;
                this.Cantidad = cantidad;
                this.PrecioUnitario = preciounitario;
                this.Total = total;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _OrdenServicio;
            public int OrdenServicio
            {
                get { return _OrdenServicio; }
                set { _OrdenServicio = value; }
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private int _Proveedor;
            public int Proveedor
            {
                get { return _Proveedor; }
                set { _Proveedor = value; }
            }

            private int _Marca;
            public int Marca
            {
                get { return _Marca; }
                set { _Marca = value; }
            }

            private decimal _Cantidad;
            public decimal Cantidad
            {
                get { return _Cantidad; }
                set { _Cantidad = value; }
            }

            private decimal _PrecioUnitario;
            public decimal PrecioUnitario
            {
                get { return _PrecioUnitario; }
                set { _PrecioUnitario = value; }
            }

            private decimal _Total;
            public decimal Total
            {
                get { return _Total; }
                set { _Total = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);

                return DB.InsertRow("Sobrantes", m_params);
            } // End Create

            public static List<Sobrantes> Read()
            {
                List<Sobrantes> list = new List<Sobrantes>();
                DataTable dt = DB.Select("Sobrantes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Sobrantes(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToDecimal(dr["Total"])));
                }

                return list;
            } // End Read

            public static Sobrantes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Sobrantes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Sobrantes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Sobrantes(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["OrdenServicio"]), Convert.ToInt32(dr["Refaccion"]), Convert.ToInt32(dr["Proveedor"]), Convert.ToInt32(dr["Marca"]), Convert.ToDecimal(dr["Cantidad"]), Convert.ToDecimal(dr["PrecioUnitario"]), Convert.ToDecimal(dr["Total"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("OrdenServicio", this.OrdenServicio);
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Proveedor", this.Proveedor);
                m_params.Add("Marca", this.Marca);
                m_params.Add("Cantidad", this.Cantidad);
                m_params.Add("PrecioUnitario", this.PrecioUnitario);
                m_params.Add("Total", this.Total);

                return DB.UpdateRow("Sobrantes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Sobrantes", w_params);
            } // End Delete

        } //End Class Sobrantes

        public class Status
        {

            public Status()
            {
            }

            public Status(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Status", m_params);
            } // End Create

            public static List<Status> Read()
            {
                List<Status> list = new List<Status>();
                DataTable dt = DB.Select("Status");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Status(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Status", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Status", w_params);
            } // End Delete

        } //End Class Status

        public class StatusCajas
        {

            public StatusCajas()
            {
            }

            public StatusCajas(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusCajas", m_params);
            } // End Create

            public static List<StatusCajas> Read()
            {
                List<StatusCajas> list = new List<StatusCajas>();
                DataTable dt = DB.Select("StatusCajas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusCajas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusCajas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusCajas", w_params);
            } // End Delete

        } //End Class StatusCajas

        public class StatusClientes
        {

            public StatusClientes()
            {
            }

            public StatusClientes(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusClientes", m_params);
            } // End Create

            public static List<StatusClientes> Read()
            {
                List<StatusClientes> list = new List<StatusClientes>();
                DataTable dt = DB.Select("StatusClientes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusClientes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusClientes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusClientes", w_params);
            } // End Delete

        } //End Class StatusClientes

        public class StatusConcesiones
        {

            public StatusConcesiones()
            {
            }

            public StatusConcesiones(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusConcesiones", m_params);
            } // End Create

            public static List<StatusConcesiones> Read()
            {
                List<StatusConcesiones> list = new List<StatusConcesiones>();
                DataTable dt = DB.Select("StatusConcesiones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusConcesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusConcesiones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusConcesiones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusConcesiones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusConcesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusConcesiones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusConcesiones", w_params);
            } // End Delete

        } //End Class StatusConcesiones

        public class StatusContratos
        {

            public StatusContratos()
            {
            }

            public StatusContratos(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusContratos", m_params);
            } // End Create

            public static List<StatusContratos> Read()
            {
                List<StatusContratos> list = new List<StatusContratos>();
                DataTable dt = DB.Select("StatusContratos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusContratos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusContratos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusContratos", w_params);
            } // End Delete

        } //End Class StatusContratos

        public class StatusEmpresasClientesTaller
        {

            public StatusEmpresasClientesTaller()
            {
            }

            public StatusEmpresasClientesTaller(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusEmpresasClientesTaller", m_params);
            } // End Create

            public static List<StatusEmpresasClientesTaller> Read()
            {
                List<StatusEmpresasClientesTaller> list = new List<StatusEmpresasClientesTaller>();
                DataTable dt = DB.Select("StatusEmpresasClientesTaller");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusEmpresasClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusEmpresasClientesTaller Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusEmpresasClientesTaller", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusEmpresasClientesTaller con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusEmpresasClientesTaller(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusEmpresasClientesTaller", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusEmpresasClientesTaller", w_params);
            } // End Delete

        } //End Class StatusEmpresasClientesTaller

        public class StatusEstaciones
        {

            public StatusEstaciones()
            {
            }

            public StatusEstaciones(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusEstaciones", m_params);
            } // End Create

            public static List<StatusEstaciones> Read()
            {
                List<StatusEstaciones> list = new List<StatusEstaciones>();
                DataTable dt = DB.Select("StatusEstaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusEstaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusEstaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusEstaciones", w_params);
            } // End Delete

        } //End Class StatusEstaciones

        public class StatusFinancieros
        {

            public StatusFinancieros()
            {
            }

            public StatusFinancieros(int folio, string descripcion, string detalles, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Detalles = detalles;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("StatusFinancieros", m_params);
            } // End Create

            public static List<StatusFinancieros> Read()
            {
                List<StatusFinancieros> list = new List<StatusFinancieros>();
                DataTable dt = DB.Select("StatusFinancieros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusFinancieros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static StatusFinancieros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusFinancieros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusFinancieros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusFinancieros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("StatusFinancieros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusFinancieros", w_params);
            } // End Delete

        } //End Class StatusFinancieros

        public class StatusMecanicos
        {

            public StatusMecanicos()
            {
            }

            public StatusMecanicos(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusMecanicos", m_params);
            } // End Create

            public static List<StatusMecanicos> Read()
            {
                List<StatusMecanicos> list = new List<StatusMecanicos>();
                DataTable dt = DB.Select("StatusMecanicos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusMecanicos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusMecanicos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusMecanicos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusMecanicos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusMecanicos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusMecanicos", w_params);
            } // End Delete

        } //End Class StatusMecanicos

        public class StatusModelos
        {

            public StatusModelos()
            {
            }

            public StatusModelos(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusModelos", m_params);
            } // End Create

            public static List<StatusModelos> Read()
            {
                List<StatusModelos> list = new List<StatusModelos>();
                DataTable dt = DB.Select("StatusModelos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusModelos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusModelos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusModelos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusModelos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusModelos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusModelos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusModelos", w_params);
            } // End Delete

        } //End Class StatusModelos

        public class StatusOrdenesCompra
        {

            public StatusOrdenesCompra()
            {
            }

            public StatusOrdenesCompra(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusOrdenesCompra", m_params);
            } // End Create

            public static List<StatusOrdenesCompra> Read()
            {
                List<StatusOrdenesCompra> list = new List<StatusOrdenesCompra>();
                DataTable dt = DB.Select("StatusOrdenesCompra");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusOrdenesCompra(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusOrdenesCompra Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusOrdenesCompra", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusOrdenesCompra con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusOrdenesCompra(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusOrdenesCompra", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusOrdenesCompra", w_params);
            } // End Delete

        } //End Class StatusOrdenesCompra

        public class StatusOrdenesServicio
        {

            public StatusOrdenesServicio()
            {
            }

            public StatusOrdenesServicio(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusOrdenesServicio", m_params);
            } // End Create

            public static List<StatusOrdenesServicio> Read()
            {
                List<StatusOrdenesServicio> list = new List<StatusOrdenesServicio>();
                DataTable dt = DB.Select("StatusOrdenesServicio");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusOrdenesServicio(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusOrdenesServicio Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusOrdenesServicio", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusOrdenesServicio con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusOrdenesServicio(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusOrdenesServicio", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusOrdenesServicio", w_params);
            } // End Delete

        } //End Class StatusOrdenesServicio

        public class StatusOrdenesTrabajo
        {

            public StatusOrdenesTrabajo()
            {
            }

            public StatusOrdenesTrabajo(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusOrdenesTrabajo", m_params);
            } // End Create

            public static List<StatusOrdenesTrabajo> Read()
            {
                List<StatusOrdenesTrabajo> list = new List<StatusOrdenesTrabajo>();
                DataTable dt = DB.Select("StatusOrdenesTrabajo");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusOrdenesTrabajo(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusOrdenesTrabajo Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusOrdenesTrabajo", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusOrdenesTrabajo con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusOrdenesTrabajo(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusOrdenesTrabajo", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusOrdenesTrabajo", w_params);
            } // End Delete

        } //End Class StatusOrdenesTrabajo

        public class StatusPlanes
        {

            public StatusPlanes()
            {
            }

            public StatusPlanes(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusPlanes", m_params);
            } // End Create

            public static List<StatusPlanes> Read()
            {
                List<StatusPlanes> list = new List<StatusPlanes>();
                DataTable dt = DB.Select("StatusPlanes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusPlanes(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusPlanes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusPlanes", w_params);
            } // End Delete

        } //End Class StatusPlanes

        public class StatusPlanillasFiscales
        {

            public StatusPlanillasFiscales()
            {
            }

            public StatusPlanillasFiscales(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusPlanillasFiscales", m_params);
            } // End Create

            public static List<StatusPlanillasFiscales> Read()
            {
                List<StatusPlanillasFiscales> list = new List<StatusPlanillasFiscales>();
                DataTable dt = DB.Select("StatusPlanillasFiscales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusPlanillasFiscales(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusPlanillasFiscales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusPlanillasFiscales", w_params);
            } // End Delete

        } //End Class StatusPlanillasFiscales

        public class StatusProveedores
        {

            public StatusProveedores()
            {
            }

            public StatusProveedores(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("StatusProveedores", m_params);
            } // End Create

            public static List<StatusProveedores> Read()
            {
                List<StatusProveedores> list = new List<StatusProveedores>();
                DataTable dt = DB.Select("StatusProveedores");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusProveedores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static StatusProveedores Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusProveedores", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusProveedores con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusProveedores(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("StatusProveedores", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusProveedores", w_params);
            } // End Delete

        } //End Class StatusProveedores

        public class StatusUnidades
        {

            public StatusUnidades()
            {
            }

            public StatusUnidades(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusUnidades", m_params);
            } // End Create

            public static List<StatusUnidades> Read()
            {
                List<StatusUnidades> list = new List<StatusUnidades>();
                DataTable dt = DB.Select("StatusUnidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static StatusUnidades Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("StatusUnidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe StatusUnidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new StatusUnidades(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusUnidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("StatusUnidades", w_params);
            } // End Delete

        } //End Class StatusUnidades

        public class StatusUsuarios
        {

            public StatusUsuarios()
            {
            }

            public StatusUsuarios(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusUsuarios", m_params);
            } // End Create

            public static List<StatusUsuarios> Read()
            {
                List<StatusUsuarios> list = new List<StatusUsuarios>();
                DataTable dt = DB.Select("StatusUsuarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusUsuarios(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusUsuarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusUsuarios", w_params);
            } // End Delete

        } //End Class StatusUsuarios

        public class StatusValesPrepagados
        {

            public StatusValesPrepagados()
            {
            }

            public StatusValesPrepagados(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("StatusValesPrepagados", m_params);
            } // End Create

            public static List<StatusValesPrepagados> Read()
            {
                List<StatusValesPrepagados> list = new List<StatusValesPrepagados>();
                DataTable dt = DB.Select("StatusValesPrepagados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new StatusValesPrepagados(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("StatusValesPrepagados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("StatusValesPrepagados", w_params);
            } // End Delete

        } //End Class StatusValesPrepagados

        public class Stocks
        {

            public Stocks()
            {
            }

            public Stocks(int refaccion, decimal maximo, decimal minimo)
            {
                this.Refaccion = refaccion;
                this.Maximo = maximo;
                this.Minimo = minimo;
            }

            private int _Refaccion;
            public int Refaccion
            {
                get { return _Refaccion; }
                set { _Refaccion = value; }
            }

            private decimal _Maximo;
            public decimal Maximo
            {
                get { return _Maximo; }
                set { _Maximo = value; }
            }

            private decimal _Minimo;
            public decimal Minimo
            {
                get { return _Minimo; }
                set { _Minimo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Maximo", this.Maximo);
                m_params.Add("Minimo", this.Minimo);

                return DB.InsertRow("Stocks", m_params);
            } // End Create

            public static List<Stocks> Read()
            {
                List<Stocks> list = new List<Stocks>();
                DataTable dt = DB.Select("Stocks");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Stocks(Convert.ToInt32(dr["Refaccion"]), Convert.ToDecimal(dr["Maximo"]), Convert.ToDecimal(dr["Minimo"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Refaccion", this.Refaccion);
                m_params.Add("Maximo", this.Maximo);
                m_params.Add("Minimo", this.Minimo);

                return DB.UpdateRow("Stocks", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Stocks", w_params);
            } // End Delete

        } //End Class Stocks

        public class Subsistemas
        {

            public Subsistemas()
            {
            }

            public Subsistemas(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("Subsistemas", m_params);
            } // End Create

            public static List<Subsistemas> Read()
            {
                List<Subsistemas> list = new List<Subsistemas>();
                DataTable dt = DB.Select("Subsistemas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Subsistemas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static Subsistemas Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Subsistemas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Subsistemas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Subsistemas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("Subsistemas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Subsistemas", w_params);
            } // End Delete

        } //End Class Subsistemas

        public class Tenencias
        {

            public Tenencias()
            {
            }

            public Tenencias(int unidad, int año, string referencia, DateTime fechaalta, string usuarioalta)
            {
                this.Unidad = unidad;
                this.Año = año;
                this.Referencia = referencia;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _Año;
            public int Año
            {
                get { return _Año; }
                set { _Año = value; }
            }

            private string _Referencia;
            public string Referencia
            {
                get { return _Referencia; }
                set { _Referencia = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Año", this.Año);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Tenencias", m_params);
            } // End Create

            public static List<Tenencias> Read()
            {
                List<Tenencias> list = new List<Tenencias>();
                DataTable dt = DB.Select("Tenencias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Tenencias(Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["Año"]), Convert.ToString(dr["Referencia"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("Año", this.Año);
                m_params.Add("Referencia", this.Referencia);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Tenencias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Tenencias", w_params);
            } // End Delete

        } //End Class Tenencias

        public class TiposClientes
        {

            public TiposClientes()
            {
            }

            public TiposClientes(int folio, int clase, string descripcion)
            {
                this.Folio = folio;
                this.Clase = clase;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Clase;
            public int Clase
            {
                get { return _Clase; }
                set { _Clase = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Clase", this.Clase);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposClientes", m_params);
            } // End Create

            public static List<TiposClientes> Read()
            {
                List<TiposClientes> list = new List<TiposClientes>();
                DataTable dt = DB.Select("TiposClientes");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposClientes(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Clase"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposClientes Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposClientes", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposClientes con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposClientes(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Clase"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Clase", this.Clase);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposClientes", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposClientes", w_params);
            } // End Delete

        } //End Class TiposClientes

        public class TiposCobros
        {

            public TiposCobros()
            {
            }

            public TiposCobros(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposCobros", m_params);
            } // End Create

            public static List<TiposCobros> Read()
            {
                List<TiposCobros> list = new List<TiposCobros>();
                DataTable dt = DB.Select("TiposCobros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposCobros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposCobros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposCobros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposCobros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposCobros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposCobros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposCobros", w_params);
            } // End Delete

        } //End Class TiposCobros

        public class TiposConceptos
        {

            public TiposConceptos()
            {
            }

            public TiposConceptos(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposConceptos", m_params);
            } // End Create

            public static List<TiposConceptos> Read()
            {
                List<TiposConceptos> list = new List<TiposConceptos>();
                DataTable dt = DB.Select("TiposConceptos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposConceptos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposConceptos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposConceptos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposConceptos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposConceptos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposConceptos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposConceptos", w_params);
            } // End Delete

        } //End Class TiposConceptos

        public class TiposConcesiones
        {

            public TiposConcesiones()
            {
            }

            public TiposConcesiones(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposConcesiones", m_params);
            } // End Create

            public static List<TiposConcesiones> Read()
            {
                List<TiposConcesiones> list = new List<TiposConcesiones>();
                DataTable dt = DB.Select("TiposConcesiones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposConcesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposConcesiones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposConcesiones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposConcesiones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposConcesiones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposConcesiones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposConcesiones", w_params);
            } // End Delete

        } //End Class TiposConcesiones

        public class TiposContratos
        {

            public TiposContratos()
            {
            }

            public TiposContratos(int folio, string descripcion, DateTime? fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime? _FechaAlta;
            public DateTime? FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.FechaAlta)) m_params.Add("FechaAlta", this.FechaAlta);
                if (!AppHelper.IsNullOrEmpty(this.UsuarioAlta)) m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposContratos", m_params);
            } // End Create

            public static List<TiposContratos> Read()
            {
                List<TiposContratos> list = new List<TiposContratos>();
                DataTable dt = DB.Select("TiposContratos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposContratos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TiposContratos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposContratos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposContratos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposContratos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), DB.GetNullableDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Descripcion)) m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.FechaAlta)) m_params.Add("FechaAlta", this.FechaAlta);
                if (!AppHelper.IsNullOrEmpty(this.UsuarioAlta)) m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposContratos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposContratos", w_params);
            } // End Delete

        } //End Class TiposContratos

        public class TiposDeCredito
        {

            public TiposDeCredito()
            {
            }

            public TiposDeCredito(int folio, string descripcion, string detalles, string usuario, DateTime fecha)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Detalles = detalles;
                this.Usuario = usuario;
                this.Fecha = fecha;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _Detalles;
            public string Detalles
            {
                get { return _Detalles; }
                set { _Detalles = value; }
            }

            private string _Usuario;
            public string Usuario
            {
                get { return _Usuario; }
                set { _Usuario = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("TiposDeCredito", m_params);
            } // End Create

            public static List<TiposDeCredito> Read()
            {
                List<TiposDeCredito> list = new List<TiposDeCredito>();
                DataTable dt = DB.Select("TiposDeCredito");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposDeCredito(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public static TiposDeCredito Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposDeCredito", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposDeCredito con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposDeCredito(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalles"]), Convert.ToString(dr["Usuario"]), Convert.ToDateTime(dr["Fecha"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                if (!AppHelper.IsNullOrEmpty(this.Detalles)) m_params.Add("Detalles", this.Detalles);
                m_params.Add("Usuario", this.Usuario);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("TiposDeCredito", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposDeCredito", w_params);
            } // End Delete

        } //End Class TiposDeCredito

        public class TiposInventario
        {

            public TiposInventario()
            {
            }

            public TiposInventario(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposInventario", m_params);
            } // End Create

            public static List<TiposInventario> Read()
            {
                List<TiposInventario> list = new List<TiposInventario>();
                DataTable dt = DB.Select("TiposInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposInventario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposInventario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposInventario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposInventario", w_params);
            } // End Delete

        } //End Class TiposInventario

        public class TiposInversionistas
        {

            public TiposInversionistas()
            {
            }

            public TiposInversionistas(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposInversionistas", m_params);
            } // End Create

            public static List<TiposInversionistas> Read()
            {
                List<TiposInversionistas> list = new List<TiposInversionistas>();
                DataTable dt = DB.Select("TiposInversionistas");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposInversionistas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposInversionistas Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposInversionistas", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposInversionistas con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposInversionistas(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposInversionistas", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposInversionistas", w_params);
            } // End Delete

        } //End Class TiposInversionistas

        public class TiposLicencias
        {

            public TiposLicencias()
            {
            }

            public TiposLicencias(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposLicencias", m_params);
            } // End Create

            public static List<TiposLicencias> Read()
            {
                List<TiposLicencias> list = new List<TiposLicencias>();
                DataTable dt = DB.Select("TiposLicencias");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposLicencias(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposLicencias", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("TiposLicencias", w_params);
            } // End Delete

        } //End Class TiposLicencias

        public class TiposMantenimientos
        {

            public TiposMantenimientos()
            {
            }

            public TiposMantenimientos(int folio, string descripcion, string detalle, bool? activo)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.Detalle = detalle;
                this.Activo = activo;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private string _Detalle;
            public string Detalle
            {
                get { return _Detalle; }
                set { _Detalle = value; }
            }

            private bool? _Activo;
            public bool? Activo
            {
                get { return _Activo; }
                set { _Activo = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Detalle", this.Detalle);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);

                return DB.InsertRow("TiposMantenimientos", m_params);
            } // End Create

            public static List<TiposMantenimientos> Read()
            {
                List<TiposMantenimientos> list = new List<TiposMantenimientos>();
                DataTable dt = DB.Select("TiposMantenimientos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposMantenimientos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalle"]), DB.GetNullableBoolean(dr["Activo"])));
                }

                return list;
            } // End Read

            public static TiposMantenimientos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposMantenimientos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposMantenimientos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposMantenimientos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToString(dr["Detalle"]), DB.GetNullableBoolean(dr["Activo"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("Detalle", this.Detalle);
                if (!AppHelper.IsNullOrEmpty(this.Activo)) m_params.Add("Activo", this.Activo);

                return DB.UpdateRow("TiposMantenimientos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposMantenimientos", w_params);
            } // End Delete

        } //End Class TiposMantenimientos

        public class TiposMovimientosInventario
        {

            public TiposMovimientosInventario()
            {
            }

            public TiposMovimientosInventario(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposMovimientosInventario", m_params);
            } // End Create

            public static List<TiposMovimientosInventario> Read()
            {
                List<TiposMovimientosInventario> list = new List<TiposMovimientosInventario>();
                DataTable dt = DB.Select("TiposMovimientosInventario");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposMovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TiposMovimientosInventario Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposMovimientosInventario", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposMovimientosInventario con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposMovimientosInventario(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposMovimientosInventario", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposMovimientosInventario", w_params);
            } // End Delete

        } //End Class TiposMovimientosInventario

        public class TiposPagos
        {

            public TiposPagos()
            {
            }

            public TiposPagos(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposPagos", m_params);
            } // End Create

            public static List<TiposPagos> Read()
            {
                List<TiposPagos> list = new List<TiposPagos>();
                DataTable dt = DB.Select("TiposPagos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposPagos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposPagos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposPagos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposPagos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposPagos(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposPagos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposPagos", w_params);
            } // End Delete

        } //End Class TiposPagos

        public class TiposParticipaciones
        {

            public TiposParticipaciones()
            {
            }

            public TiposParticipaciones(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposParticipaciones", m_params);
            } // End Create

            public static List<TiposParticipaciones> Read()
            {
                List<TiposParticipaciones> list = new List<TiposParticipaciones>();
                DataTable dt = DB.Select("TiposParticipaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposParticipaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposParticipaciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposParticipaciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposParticipaciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposParticipaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposParticipaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposParticipaciones", w_params);
            } // End Delete

        } //End Class TiposParticipaciones

        public class TiposReasignaciones
        {

            public TiposReasignaciones()
            {
            }

            public TiposReasignaciones(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposReasignaciones", m_params);
            } // End Create

            public static List<TiposReasignaciones> Read()
            {
                List<TiposReasignaciones> list = new List<TiposReasignaciones>();
                DataTable dt = DB.Select("TiposReasignaciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposReasignaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TiposReasignaciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposReasignaciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposReasignaciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposReasignaciones(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposReasignaciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposReasignaciones", w_params);
            } // End Delete

        } //End Class TiposReasignaciones

        public class TiposRefacciones
        {

            public TiposRefacciones()
            {
            }

            public TiposRefacciones(int folio, int familia, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Familia = familia;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _Familia;
            public int Familia
            {
                get { return _Familia; }
                set { _Familia = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposRefacciones", m_params);
            } // End Create

            public static List<TiposRefacciones> Read()
            {
                List<TiposRefacciones> list = new List<TiposRefacciones>();
                DataTable dt = DB.Select("TiposRefacciones");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposRefacciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TiposRefacciones Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposRefacciones", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposRefacciones con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposRefacciones(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["Familia"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Familia", this.Familia);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposRefacciones", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposRefacciones", w_params);
            } // End Delete

        } //End Class TiposRefacciones

        public class TiposReferenciasInventarios
        {

            public TiposReferenciasInventarios()
            {
            }

            public TiposReferenciasInventarios(int folio, string descripcion)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);

                return DB.InsertRow("TiposReferenciasInventarios", m_params);
            } // End Create

            public static List<TiposReferenciasInventarios> Read()
            {
                List<TiposReferenciasInventarios> list = new List<TiposReferenciasInventarios>();
                DataTable dt = DB.Select("TiposReferenciasInventarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposReferenciasInventarios(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"])));
                }

                return list;
            } // End Read

            public static TiposReferenciasInventarios Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposReferenciasInventarios", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposReferenciasInventarios con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposReferenciasInventarios(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);

                return DB.UpdateRow("TiposReferenciasInventarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposReferenciasInventarios", w_params);
            } // End Delete

        } //End Class TiposReferenciasInventarios

        public class TiposSiniestros
        {

            public TiposSiniestros()
            {
            }

            public TiposSiniestros(int folio, string descripcion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Descripcion = descripcion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Descripcion;
            public string Descripcion
            {
                get { return _Descripcion; }
                set { _Descripcion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TiposSiniestros", m_params);
            } // End Create

            public static List<TiposSiniestros> Read()
            {
                List<TiposSiniestros> list = new List<TiposSiniestros>();
                DataTable dt = DB.Select("TiposSiniestros");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TiposSiniestros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TiposSiniestros Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TiposSiniestros", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TiposSiniestros con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TiposSiniestros(Convert.ToInt32(dr["Folio"]), Convert.ToString(dr["Descripcion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("Descripcion", this.Descripcion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TiposSiniestros", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TiposSiniestros", w_params);
            } // End Delete

        } //End Class TiposSiniestros

        public class TraspasoVehiculos
        {

            public TraspasoVehiculos()
            {
            }

            public TraspasoVehiculos(int folio, int? conductor, int unidad, int estacionanterior, int estacionactual, string motivo, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.Conductor = conductor;
                this.Unidad = unidad;
                this.EstacionAnterior = estacionanterior;
                this.EstacionActual = estacionactual;
                this.Motivo = motivo;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int? _Conductor;
            public int? Conductor
            {
                get { return _Conductor; }
                set { _Conductor = value; }
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _EstacionAnterior;
            public int EstacionAnterior
            {
                get { return _EstacionAnterior; }
                set { _EstacionAnterior = value; }
            }

            private int _EstacionActual;
            public int EstacionActual
            {
                get { return _EstacionActual; }
                set { _EstacionActual = value; }
            }

            private string _Motivo;
            public string Motivo
            {
                get { return _Motivo; }
                set { _Motivo = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Conductor)) m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("EstacionAnterior", this.EstacionAnterior);
                m_params.Add("EstacionActual", this.EstacionActual);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("TraspasoVehiculos", m_params);
            } // End Create

            public static List<TraspasoVehiculos> Read()
            {
                List<TraspasoVehiculos> list = new List<TraspasoVehiculos>();
                DataTable dt = DB.Select("TraspasoVehiculos");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new TraspasoVehiculos(Convert.ToInt32(dr["Folio"]), DB.GetNullableInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["EstacionAnterior"]), Convert.ToInt32(dr["EstacionActual"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static TraspasoVehiculos Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("TraspasoVehiculos", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe TraspasoVehiculos con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new TraspasoVehiculos(Convert.ToInt32(dr["Folio"]), DB.GetNullableInt32(dr["Conductor"]), Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["EstacionAnterior"]), Convert.ToInt32(dr["EstacionActual"]), Convert.ToString(dr["Motivo"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Conductor)) m_params.Add("Conductor", this.Conductor);
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("EstacionAnterior", this.EstacionAnterior);
                m_params.Add("EstacionActual", this.EstacionActual);
                m_params.Add("Motivo", this.Motivo);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("TraspasoVehiculos", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("TraspasoVehiculos", w_params);
            } // End Delete

        } //End Class TraspasoVehiculos

        public class Unidades
        {

            public Unidades()
            {
            }

            public Unidades(int folio, int numeroeconomico, int estacion, int modelo, decimal preciolista, string numeroserie, string numeroseriemotor, string tarjetacirculacion, int status, int locacion, DateTime fechaalta, string usuarioalta)
            {
                this.Folio = folio;
                this.NumeroEconomico = numeroeconomico;
                this.Estacion = estacion;
                this.Modelo = modelo;
                this.PrecioLista = preciolista;
                this.NumeroSerie = numeroserie;
                this.NumeroSerieMotor = numeroseriemotor;
                this.TarjetaCirculacion = tarjetacirculacion;
                this.Status = status;
                this.Locacion = locacion;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private int _Folio;
            public int Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private int _NumeroEconomico;
            public int NumeroEconomico
            {
                get { return _NumeroEconomico; }
                set { _NumeroEconomico = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private int _Modelo;
            public int Modelo
            {
                get { return _Modelo; }
                set { _Modelo = value; }
            }

            private decimal _PrecioLista;
            public decimal PrecioLista
            {
                get { return _PrecioLista; }
                set { _PrecioLista = value; }
            }

            private string _NumeroSerie;
            public string NumeroSerie
            {
                get { return _NumeroSerie; }
                set { _NumeroSerie = value; }
            }

            private string _NumeroSerieMotor;
            public string NumeroSerieMotor
            {
                get { return _NumeroSerieMotor; }
                set { _NumeroSerieMotor = value; }
            }

            private string _TarjetaCirculacion;
            public string TarjetaCirculacion
            {
                get { return _TarjetaCirculacion; }
                set { _TarjetaCirculacion = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private int _Locacion;
            public int Locacion
            {
                get { return _Locacion; }
                set { _Locacion = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Modelo", this.Modelo);
                m_params.Add("PrecioLista", this.PrecioLista);
                m_params.Add("NumeroSerie", this.NumeroSerie);
                m_params.Add("NumeroSerieMotor", this.NumeroSerieMotor);
                m_params.Add("TarjetaCirculacion", this.TarjetaCirculacion);
                m_params.Add("Status", this.Status);
                m_params.Add("Locacion", this.Locacion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Unidades", m_params);
            } // End Create

            public static List<Unidades> Read()
            {
                List<Unidades> list = new List<Unidades>();
                DataTable dt = DB.Select("Unidades");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Unidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Modelo"]), Convert.ToDecimal(dr["PrecioLista"]), Convert.ToString(dr["NumeroSerie"]), Convert.ToString(dr["NumeroSerieMotor"]), Convert.ToString(dr["TarjetaCirculacion"]), Convert.ToInt32(dr["Status"]), Convert.ToInt32(dr["Locacion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public static Unidades Read(int folio)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", folio);
                DataTable dt = DB.Select("Unidades", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe Unidades con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new Unidades(Convert.ToInt32(dr["Folio"]), Convert.ToInt32(dr["NumeroEconomico"]), Convert.ToInt32(dr["Estacion"]), Convert.ToInt32(dr["Modelo"]), Convert.ToDecimal(dr["PrecioLista"]), Convert.ToString(dr["NumeroSerie"]), Convert.ToString(dr["NumeroSerieMotor"]), Convert.ToString(dr["TarjetaCirculacion"]), Convert.ToInt32(dr["Status"]), Convert.ToInt32(dr["Locacion"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);
                m_params.Add("NumeroEconomico", this.NumeroEconomico);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("Modelo", this.Modelo);
                m_params.Add("PrecioLista", this.PrecioLista);
                m_params.Add("NumeroSerie", this.NumeroSerie);
                m_params.Add("NumeroSerieMotor", this.NumeroSerieMotor);
                m_params.Add("TarjetaCirculacion", this.TarjetaCirculacion);
                m_params.Add("Status", this.Status);
                m_params.Add("Locacion", this.Locacion);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Unidades", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Folio", this.Folio);

                return DB.DeleteRow("Unidades", w_params);
            } // End Delete

        } //End Class Unidades

        public class UnidadesConductoresActuales
        {

            public UnidadesConductoresActuales()
            {
            }

            public UnidadesConductoresActuales(int unidad, int conductoractual, DateTime fecha)
            {
                this.Unidad = unidad;
                this.ConductorActual = conductoractual;
                this.Fecha = fecha;
            }

            private int _Unidad;
            public int Unidad
            {
                get { return _Unidad; }
                set { _Unidad = value; }
            }

            private int _ConductorActual;
            public int ConductorActual
            {
                get { return _ConductorActual; }
                set { _ConductorActual = value; }
            }

            private DateTime _Fecha;
            public DateTime Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("ConductorActual", this.ConductorActual);
                m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("UnidadesConductoresActuales", m_params);
            } // End Create

            public static List<UnidadesConductoresActuales> Read()
            {
                List<UnidadesConductoresActuales> list = new List<UnidadesConductoresActuales>();
                DataTable dt = DB.Select("UnidadesConductoresActuales");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new UnidadesConductoresActuales(Convert.ToInt32(dr["Unidad"]), Convert.ToInt32(dr["ConductorActual"]), Convert.ToDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Unidad", this.Unidad);
                m_params.Add("ConductorActual", this.ConductorActual);
                m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("UnidadesConductoresActuales", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("UnidadesConductoresActuales", w_params);
            } // End Delete

        } //End Class UnidadesConductoresActuales

        public class Usuarios
        {

            public Usuarios()
            {
            }

            public Usuarios(string clave, string pwd, int estacion, string apellidopaterno, string apellidomaterno, string nombre, int rol, int status, DateTime fechaalta, string usuarioalta)
            {
                this.Clave = clave;
                this.Pwd = pwd;
                this.Estacion = estacion;
                this.ApellidoPaterno = apellidopaterno;
                this.ApellidoMaterno = apellidomaterno;
                this.Nombre = nombre;
                this.Rol = rol;
                this.Status = status;
                this.FechaAlta = fechaalta;
                this.UsuarioAlta = usuarioalta;
            }

            private string _Clave;
            public string Clave
            {
                get { return _Clave; }
                set { _Clave = value; }
            }

            private string _Pwd;
            public string Pwd
            {
                get { return _Pwd; }
                set { _Pwd = value; }
            }

            private int _Estacion;
            public int Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            private string _ApellidoPaterno;
            public string ApellidoPaterno
            {
                get { return _ApellidoPaterno; }
                set { _ApellidoPaterno = value; }
            }

            private string _ApellidoMaterno;
            public string ApellidoMaterno
            {
                get { return _ApellidoMaterno; }
                set { _ApellidoMaterno = value; }
            }

            private string _Nombre;
            public string Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private int _Rol;
            public int Rol
            {
                get { return _Rol; }
                set { _Rol = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            private DateTime _FechaAlta;
            public DateTime FechaAlta
            {
                get { return _FechaAlta; }
                set { _FechaAlta = value; }
            }

            private string _UsuarioAlta;
            public string UsuarioAlta
            {
                get { return _UsuarioAlta; }
                set { _UsuarioAlta = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Clave", this.Clave);
                m_params.Add("Pwd", this.Pwd);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Rol", this.Rol);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.InsertRow("Usuarios", m_params);
            } // End Create

            public static List<Usuarios> Read()
            {
                List<Usuarios> list = new List<Usuarios>();
                DataTable dt = DB.Select("Usuarios");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new Usuarios(Convert.ToString(dr["Clave"]), Convert.ToString(dr["Pwd"]), Convert.ToInt32(dr["Estacion"]), Convert.ToString(dr["ApellidoPaterno"]), Convert.ToString(dr["ApellidoMaterno"]), Convert.ToString(dr["Nombre"]), Convert.ToInt32(dr["Rol"]), Convert.ToInt32(dr["Status"]), Convert.ToDateTime(dr["FechaAlta"]), Convert.ToString(dr["UsuarioAlta"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Clave", this.Clave);
                m_params.Add("Pwd", this.Pwd);
                m_params.Add("Estacion", this.Estacion);
                m_params.Add("ApellidoPaterno", this.ApellidoPaterno);
                m_params.Add("ApellidoMaterno", this.ApellidoMaterno);
                m_params.Add("Nombre", this.Nombre);
                m_params.Add("Rol", this.Rol);
                m_params.Add("Status", this.Status);
                m_params.Add("FechaAlta", this.FechaAlta);
                m_params.Add("UsuarioAlta", this.UsuarioAlta);

                return DB.UpdateRow("Usuarios", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("Usuarios", w_params);
            } // End Delete

        } //End Class Usuarios

        public class UsuariosSarec
        {

            public UsuariosSarec()
            {
            }

            public UsuariosSarec(char usr, char pwd, char nombre, bool? chgpwd, char nomina, char horaini, char horafin, char accesos1, char accesos2, char accesos3, char accesos4, char accesos5, char accesos6, char accesos7, char accesos8, char accesos9, char accesos10, char accesos11, char accesos12, char accesos13, char accesos14, char accesos15, char altafecha, char altahora, char altausr, char? modiffecha, char? modifhora, char? modifusr, char estacion)
            {
                this.Usr = usr;
                this.Pwd = pwd;
                this.Nombre = nombre;
                this.ChgPwd = chgpwd;
                this.Nomina = nomina;
                this.HoraIni = horaini;
                this.HoraFin = horafin;
                this.Accesos1 = accesos1;
                this.Accesos2 = accesos2;
                this.Accesos3 = accesos3;
                this.Accesos4 = accesos4;
                this.Accesos5 = accesos5;
                this.Accesos6 = accesos6;
                this.Accesos7 = accesos7;
                this.Accesos8 = accesos8;
                this.Accesos9 = accesos9;
                this.Accesos10 = accesos10;
                this.Accesos11 = accesos11;
                this.Accesos12 = accesos12;
                this.Accesos13 = accesos13;
                this.Accesos14 = accesos14;
                this.Accesos15 = accesos15;
                this.AltaFecha = altafecha;
                this.AltaHora = altahora;
                this.AltaUsr = altausr;
                this.ModifFecha = modiffecha;
                this.ModifHora = modifhora;
                this.ModifUsr = modifusr;
                this.Estacion = estacion;
            }

            private char _Usr;
            public char Usr
            {
                get { return _Usr; }
                set { _Usr = value; }
            }

            private char _Pwd;
            public char Pwd
            {
                get { return _Pwd; }
                set { _Pwd = value; }
            }

            private char _Nombre;
            public char Nombre
            {
                get { return _Nombre; }
                set { _Nombre = value; }
            }

            private bool? _ChgPwd;
            public bool? ChgPwd
            {
                get { return _ChgPwd; }
                set { _ChgPwd = value; }
            }

            private char _Nomina;
            public char Nomina
            {
                get { return _Nomina; }
                set { _Nomina = value; }
            }

            private char _HoraIni;
            public char HoraIni
            {
                get { return _HoraIni; }
                set { _HoraIni = value; }
            }

            private char _HoraFin;
            public char HoraFin
            {
                get { return _HoraFin; }
                set { _HoraFin = value; }
            }

            private char _Accesos1;
            public char Accesos1
            {
                get { return _Accesos1; }
                set { _Accesos1 = value; }
            }

            private char _Accesos2;
            public char Accesos2
            {
                get { return _Accesos2; }
                set { _Accesos2 = value; }
            }

            private char _Accesos3;
            public char Accesos3
            {
                get { return _Accesos3; }
                set { _Accesos3 = value; }
            }

            private char _Accesos4;
            public char Accesos4
            {
                get { return _Accesos4; }
                set { _Accesos4 = value; }
            }

            private char _Accesos5;
            public char Accesos5
            {
                get { return _Accesos5; }
                set { _Accesos5 = value; }
            }

            private char _Accesos6;
            public char Accesos6
            {
                get { return _Accesos6; }
                set { _Accesos6 = value; }
            }

            private char _Accesos7;
            public char Accesos7
            {
                get { return _Accesos7; }
                set { _Accesos7 = value; }
            }

            private char _Accesos8;
            public char Accesos8
            {
                get { return _Accesos8; }
                set { _Accesos8 = value; }
            }

            private char _Accesos9;
            public char Accesos9
            {
                get { return _Accesos9; }
                set { _Accesos9 = value; }
            }

            private char _Accesos10;
            public char Accesos10
            {
                get { return _Accesos10; }
                set { _Accesos10 = value; }
            }

            private char _Accesos11;
            public char Accesos11
            {
                get { return _Accesos11; }
                set { _Accesos11 = value; }
            }

            private char _Accesos12;
            public char Accesos12
            {
                get { return _Accesos12; }
                set { _Accesos12 = value; }
            }

            private char _Accesos13;
            public char Accesos13
            {
                get { return _Accesos13; }
                set { _Accesos13 = value; }
            }

            private char _Accesos14;
            public char Accesos14
            {
                get { return _Accesos14; }
                set { _Accesos14 = value; }
            }

            private char _Accesos15;
            public char Accesos15
            {
                get { return _Accesos15; }
                set { _Accesos15 = value; }
            }

            private char _AltaFecha;
            public char AltaFecha
            {
                get { return _AltaFecha; }
                set { _AltaFecha = value; }
            }

            private char _AltaHora;
            public char AltaHora
            {
                get { return _AltaHora; }
                set { _AltaHora = value; }
            }

            private char _AltaUsr;
            public char AltaUsr
            {
                get { return _AltaUsr; }
                set { _AltaUsr = value; }
            }

            private char? _ModifFecha;
            public char? ModifFecha
            {
                get { return _ModifFecha; }
                set { _ModifFecha = value; }
            }

            private char? _ModifHora;
            public char? ModifHora
            {
                get { return _ModifHora; }
                set { _ModifHora = value; }
            }

            private char? _ModifUsr;
            public char? ModifUsr
            {
                get { return _ModifUsr; }
                set { _ModifUsr = value; }
            }

            private char _Estacion;
            public char Estacion
            {
                get { return _Estacion; }
                set { _Estacion = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Usr", this.Usr);
                m_params.Add("Pwd", this.Pwd);
                m_params.Add("Nombre", this.Nombre);
                if (!AppHelper.IsNullOrEmpty(this.ChgPwd)) m_params.Add("ChgPwd", this.ChgPwd);
                m_params.Add("Nomina", this.Nomina);
                m_params.Add("HoraIni", this.HoraIni);
                m_params.Add("HoraFin", this.HoraFin);
                m_params.Add("Accesos1", this.Accesos1);
                m_params.Add("Accesos2", this.Accesos2);
                m_params.Add("Accesos3", this.Accesos3);
                m_params.Add("Accesos4", this.Accesos4);
                m_params.Add("Accesos5", this.Accesos5);
                m_params.Add("Accesos6", this.Accesos6);
                m_params.Add("Accesos7", this.Accesos7);
                m_params.Add("Accesos8", this.Accesos8);
                m_params.Add("Accesos9", this.Accesos9);
                m_params.Add("Accesos10", this.Accesos10);
                m_params.Add("Accesos11", this.Accesos11);
                m_params.Add("Accesos12", this.Accesos12);
                m_params.Add("Accesos13", this.Accesos13);
                m_params.Add("Accesos14", this.Accesos14);
                m_params.Add("Accesos15", this.Accesos15);
                m_params.Add("AltaFecha", this.AltaFecha);
                m_params.Add("AltaHora", this.AltaHora);
                m_params.Add("AltaUsr", this.AltaUsr);
                if (!AppHelper.IsNullOrEmpty(this.ModifFecha)) m_params.Add("ModifFecha", this.ModifFecha);
                if (!AppHelper.IsNullOrEmpty(this.ModifHora)) m_params.Add("ModifHora", this.ModifHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifUsr)) m_params.Add("ModifUsr", this.ModifUsr);
                m_params.Add("Estacion", this.Estacion);

                return DB.InsertRow("UsuariosSarec", m_params);
            } // End Create

            public static List<UsuariosSarec> Read()
            {
                List<UsuariosSarec> list = new List<UsuariosSarec>();
                DataTable dt = DB.Select("UsuariosSarec");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new UsuariosSarec(Convert.ToChar(dr["Usr"]), Convert.ToChar(dr["Pwd"]), Convert.ToChar(dr["Nombre"]), DB.GetNullableBoolean(dr["ChgPwd"]), Convert.ToChar(dr["Nomina"]), Convert.ToChar(dr["HoraIni"]), Convert.ToChar(dr["HoraFin"]), Convert.ToChar(dr["Accesos1"]), Convert.ToChar(dr["Accesos2"]), Convert.ToChar(dr["Accesos3"]), Convert.ToChar(dr["Accesos4"]), Convert.ToChar(dr["Accesos5"]), Convert.ToChar(dr["Accesos6"]), Convert.ToChar(dr["Accesos7"]), Convert.ToChar(dr["Accesos8"]), Convert.ToChar(dr["Accesos9"]), Convert.ToChar(dr["Accesos10"]), Convert.ToChar(dr["Accesos11"]), Convert.ToChar(dr["Accesos12"]), Convert.ToChar(dr["Accesos13"]), Convert.ToChar(dr["Accesos14"]), Convert.ToChar(dr["Accesos15"]), Convert.ToChar(dr["AltaFecha"]), Convert.ToChar(dr["AltaHora"]), Convert.ToChar(dr["AltaUsr"]), DB.GetNullableChar(dr["ModifFecha"]), DB.GetNullableChar(dr["ModifHora"]), DB.GetNullableChar(dr["ModifUsr"]), Convert.ToChar(dr["Estacion"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Usr", this.Usr);
                m_params.Add("Pwd", this.Pwd);
                m_params.Add("Nombre", this.Nombre);
                if (!AppHelper.IsNullOrEmpty(this.ChgPwd)) m_params.Add("ChgPwd", this.ChgPwd);
                m_params.Add("Nomina", this.Nomina);
                m_params.Add("HoraIni", this.HoraIni);
                m_params.Add("HoraFin", this.HoraFin);
                m_params.Add("Accesos1", this.Accesos1);
                m_params.Add("Accesos2", this.Accesos2);
                m_params.Add("Accesos3", this.Accesos3);
                m_params.Add("Accesos4", this.Accesos4);
                m_params.Add("Accesos5", this.Accesos5);
                m_params.Add("Accesos6", this.Accesos6);
                m_params.Add("Accesos7", this.Accesos7);
                m_params.Add("Accesos8", this.Accesos8);
                m_params.Add("Accesos9", this.Accesos9);
                m_params.Add("Accesos10", this.Accesos10);
                m_params.Add("Accesos11", this.Accesos11);
                m_params.Add("Accesos12", this.Accesos12);
                m_params.Add("Accesos13", this.Accesos13);
                m_params.Add("Accesos14", this.Accesos14);
                m_params.Add("Accesos15", this.Accesos15);
                m_params.Add("AltaFecha", this.AltaFecha);
                m_params.Add("AltaHora", this.AltaHora);
                m_params.Add("AltaUsr", this.AltaUsr);
                if (!AppHelper.IsNullOrEmpty(this.ModifFecha)) m_params.Add("ModifFecha", this.ModifFecha);
                if (!AppHelper.IsNullOrEmpty(this.ModifHora)) m_params.Add("ModifHora", this.ModifHora);
                if (!AppHelper.IsNullOrEmpty(this.ModifUsr)) m_params.Add("ModifUsr", this.ModifUsr);
                m_params.Add("Estacion", this.Estacion);

                return DB.UpdateRow("UsuariosSarec", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("UsuariosSarec", w_params);
            } // End Delete

        } //End Class UsuariosSarec

        public class ValesAuditoria
        {

            public ValesAuditoria()
            {
            }

            public ValesAuditoria(int? folio, string vale, DateTime? fecha)
            {
                this.Folio = folio;
                this.Vale = vale;
                this.Fecha = fecha;
            }

            private int? _Folio;
            public int? Folio
            {
                get { return _Folio; }
                set { _Folio = value; }
            }

            private string _Vale;
            public string Vale
            {
                get { return _Vale; }
                set { _Vale = value; }
            }

            private DateTime? _Fecha;
            public DateTime? Fecha
            {
                get { return _Fecha; }
                set { _Fecha = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Vale)) m_params.Add("Vale", this.Vale);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.InsertRow("ValesAuditoria", m_params);
            } // End Create

            public static List<ValesAuditoria> Read()
            {
                List<ValesAuditoria> list = new List<ValesAuditoria>();
                DataTable dt = DB.Select("ValesAuditoria");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ValesAuditoria(DB.GetNullableInt32(dr["Folio"]), Convert.ToString(dr["Vale"]), DB.GetNullableDateTime(dr["Fecha"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                if (!AppHelper.IsNullOrEmpty(this.Folio)) m_params.Add("Folio", this.Folio);
                if (!AppHelper.IsNullOrEmpty(this.Vale)) m_params.Add("Vale", this.Vale);
                if (!AppHelper.IsNullOrEmpty(this.Fecha)) m_params.Add("Fecha", this.Fecha);

                return DB.UpdateRow("ValesAuditoria", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ValesAuditoria", w_params);
            } // End Delete

        } //End Class ValesAuditoria

        public class ValesPrepagados
        {

            public ValesPrepagados()
            {
            }

            public ValesPrepagados(string codigo, int foliodiario, decimal denominacion, int cliente, DateTime fechaemision, DateTime fechaexpiracion, string usuarioemision, int status)
            {
                this.Codigo = codigo;
                this.FolioDiario = foliodiario;
                this.Denominacion = denominacion;
                this.Cliente = cliente;
                this.FechaEmision = fechaemision;
                this.FechaExpiracion = fechaexpiracion;
                this.UsuarioEmision = usuarioemision;
                this.Status = status;
            }

            private string _Codigo;
            public string Codigo
            {
                get { return _Codigo; }
                set { _Codigo = value; }
            }

            private int _FolioDiario;
            public int FolioDiario
            {
                get { return _FolioDiario; }
                set { _FolioDiario = value; }
            }

            private decimal _Denominacion;
            public decimal Denominacion
            {
                get { return _Denominacion; }
                set { _Denominacion = value; }
            }

            private int _Cliente;
            public int Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private DateTime _FechaEmision;
            public DateTime FechaEmision
            {
                get { return _FechaEmision; }
                set { _FechaEmision = value; }
            }

            private DateTime _FechaExpiracion;
            public DateTime FechaExpiracion
            {
                get { return _FechaExpiracion; }
                set { _FechaExpiracion = value; }
            }

            private string _UsuarioEmision;
            public string UsuarioEmision
            {
                get { return _UsuarioEmision; }
                set { _UsuarioEmision = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("ValesPrepagados", m_params);
            } // End Create

            public static List<ValesPrepagados> Read()
            {
                List<ValesPrepagados> list = new List<ValesPrepagados>();
                DataTable dt = DB.Select("ValesPrepagados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ValesPrepagados(Convert.ToString(dr["Codigo"]), Convert.ToInt32(dr["FolioDiario"]), Convert.ToDecimal(dr["Denominacion"]), Convert.ToInt32(dr["Cliente"]), Convert.ToDateTime(dr["FechaEmision"]), Convert.ToDateTime(dr["FechaExpiracion"]), Convert.ToString(dr["UsuarioEmision"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public static ValesPrepagados Read(string codigo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", codigo);
                DataTable dt = DB.Select("ValesPrepagados", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ValesPrepagados con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ValesPrepagados(Convert.ToString(dr["Codigo"]), Convert.ToInt32(dr["FolioDiario"]), Convert.ToDecimal(dr["Denominacion"]), Convert.ToInt32(dr["Cliente"]), Convert.ToDateTime(dr["FechaEmision"]), Convert.ToDateTime(dr["FechaExpiracion"]), Convert.ToString(dr["UsuarioEmision"]), Convert.ToInt32(dr["Status"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("ValesPrepagados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", this.Codigo);

                return DB.DeleteRow("ValesPrepagados", w_params);
            } // End Delete

        } //End Class ValesPrepagados

        public class ValesPrepagados_5
        {

            public ValesPrepagados_5()
            {
            }

            public ValesPrepagados_5(string codigo, int foliodiario, decimal denominacion, int cliente, DateTime fechaemision, DateTime fechaexpiracion, string usuarioemision, int status)
            {
                this.Codigo = codigo;
                this.FolioDiario = foliodiario;
                this.Denominacion = denominacion;
                this.Cliente = cliente;
                this.FechaEmision = fechaemision;
                this.FechaExpiracion = fechaexpiracion;
                this.UsuarioEmision = usuarioemision;
                this.Status = status;
            }

            private string _Codigo;
            public string Codigo
            {
                get { return _Codigo; }
                set { _Codigo = value; }
            }

            private int _FolioDiario;
            public int FolioDiario
            {
                get { return _FolioDiario; }
                set { _FolioDiario = value; }
            }

            private decimal _Denominacion;
            public decimal Denominacion
            {
                get { return _Denominacion; }
                set { _Denominacion = value; }
            }

            private int _Cliente;
            public int Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private DateTime _FechaEmision;
            public DateTime FechaEmision
            {
                get { return _FechaEmision; }
                set { _FechaEmision = value; }
            }

            private DateTime _FechaExpiracion;
            public DateTime FechaExpiracion
            {
                get { return _FechaExpiracion; }
                set { _FechaExpiracion = value; }
            }

            private string _UsuarioEmision;
            public string UsuarioEmision
            {
                get { return _UsuarioEmision; }
                set { _UsuarioEmision = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("ValesPrepagados_5", m_params);
            } // End Create

            public static List<ValesPrepagados_5> Read()
            {
                List<ValesPrepagados_5> list = new List<ValesPrepagados_5>();
                DataTable dt = DB.Select("ValesPrepagados_5");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ValesPrepagados_5(Convert.ToString(dr["Codigo"]), Convert.ToInt32(dr["FolioDiario"]), Convert.ToDecimal(dr["Denominacion"]), Convert.ToInt32(dr["Cliente"]), Convert.ToDateTime(dr["FechaEmision"]), Convert.ToDateTime(dr["FechaExpiracion"]), Convert.ToString(dr["UsuarioEmision"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                m_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("ValesPrepagados_5", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();

                return DB.DeleteRow("ValesPrepagados_5", w_params);
            } // End Delete

        } //End Class ValesPrepagados_5

        public class ValesPrepagadosExportados
        {

            public ValesPrepagadosExportados()
            {
            }

            public ValesPrepagadosExportados(string codigo, int foliodiario, decimal denominacion, string cliente, DateTime fechaemision, DateTime fechaexpiracion, string usuarioemision, int status)
            {
                this.Codigo = codigo;
                this.FolioDiario = foliodiario;
                this.Denominacion = denominacion;
                this.Cliente = cliente;
                this.FechaEmision = fechaemision;
                this.FechaExpiracion = fechaexpiracion;
                this.UsuarioEmision = usuarioemision;
                this.Status = status;
            }

            private string _Codigo;
            public string Codigo
            {
                get { return _Codigo; }
                set { _Codigo = value; }
            }

            private int _FolioDiario;
            public int FolioDiario
            {
                get { return _FolioDiario; }
                set { _FolioDiario = value; }
            }

            private decimal _Denominacion;
            public decimal Denominacion
            {
                get { return _Denominacion; }
                set { _Denominacion = value; }
            }

            private string _Cliente;
            public string Cliente
            {
                get { return _Cliente; }
                set { _Cliente = value; }
            }

            private DateTime _FechaEmision;
            public DateTime FechaEmision
            {
                get { return _FechaEmision; }
                set { _FechaEmision = value; }
            }

            private DateTime _FechaExpiracion;
            public DateTime FechaExpiracion
            {
                get { return _FechaExpiracion; }
                set { _FechaExpiracion = value; }
            }

            private string _UsuarioEmision;
            public string UsuarioEmision
            {
                get { return _UsuarioEmision; }
                set { _UsuarioEmision = value; }
            }

            private int _Status;
            public int Status
            {
                get { return _Status; }
                set { _Status = value; }
            }

            public int Create()
            {
                Hashtable m_params = new Hashtable();
                m_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.InsertRow("ValesPrepagadosExportados", m_params);
            } // End Create

            public static List<ValesPrepagadosExportados> Read()
            {
                List<ValesPrepagadosExportados> list = new List<ValesPrepagadosExportados>();
                DataTable dt = DB.Select("ValesPrepagadosExportados");
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ValesPrepagadosExportados(Convert.ToString(dr["Codigo"]), Convert.ToInt32(dr["FolioDiario"]), Convert.ToDecimal(dr["Denominacion"]), Convert.ToString(dr["Cliente"]), Convert.ToDateTime(dr["FechaEmision"]), Convert.ToDateTime(dr["FechaExpiracion"]), Convert.ToString(dr["UsuarioEmision"]), Convert.ToInt32(dr["Status"])));
                }

                return list;
            } // End Read

            public static ValesPrepagadosExportados Read(string codigo)
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", codigo);
                DataTable dt = DB.Select("ValesPrepagadosExportados", w_params);
                if (dt.Rows.Count == 0)
                {
                    throw new Exception("No existe ValesPrepagadosExportados con los criterios de búsqueda especificados.");
                }
                DataRow dr = dt.Rows[0];
                return new ValesPrepagadosExportados(Convert.ToString(dr["Codigo"]), Convert.ToInt32(dr["FolioDiario"]), Convert.ToDecimal(dr["Denominacion"]), Convert.ToString(dr["Cliente"]), Convert.ToDateTime(dr["FechaEmision"]), Convert.ToDateTime(dr["FechaExpiracion"]), Convert.ToString(dr["UsuarioEmision"]), Convert.ToInt32(dr["Status"]));
            } // End Read

            public int Update()
            {
                Hashtable m_params = new Hashtable();
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", this.Codigo);
                m_params.Add("FolioDiario", this.FolioDiario);
                m_params.Add("Denominacion", this.Denominacion);
                m_params.Add("Cliente", this.Cliente);
                m_params.Add("FechaEmision", this.FechaEmision);
                m_params.Add("FechaExpiracion", this.FechaExpiracion);
                m_params.Add("UsuarioEmision", this.UsuarioEmision);
                m_params.Add("Status", this.Status);

                return DB.UpdateRow("ValesPrepagadosExportados", m_params, w_params);
            } // End Update

            public int Delete()
            {
                Hashtable w_params = new Hashtable();
                w_params.Add("Codigo", this.Codigo);

                return DB.DeleteRow("ValesPrepagadosExportados", w_params);
            } // End Delete

        } //End Class ValesPrepagadosExportados

    } // End namespace


} //    End Namespace
