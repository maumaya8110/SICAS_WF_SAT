﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SICASBot
{
    class Program
    {
        static void Main(string[] args)
        {
            Sync.Syncronization.SyncLA syncLA = new Sync.Syncronization.SyncLA();
            Sync.Syncronization.SyncApto syncApto = new Sync.Syncronization.SyncApto();

            //syncLA.DoSyncMetro();
            syncApto.DoSync();

            //Thread metroLAThread = new Thread(new ThreadStart(syncLA.DoSyncMetro));
            //metroLAThread.Start();

            //Thread aeroThread = new Thread(new ThreadStart(syncApto.DoSync));
            //aeroThread.Start();

            //Thread tallerThread = new Thread(new ThreadStart(syncLA.DoSyncTaller));
            //tallerThread.Start();

            //System.Threading.Thread.Sleep(System.Threading.Timeout.Infinite);

            //syncLA.DoSyncTaller();
            //Sync.Syncronization.SyncApto syncApto = new Sync.Syncronization.SyncApto();
            //syncApto.DoSync();

            /*
             * 1) Open thread SyncMetro
             * 2) Open thread SyncAero
             * 3) Open thread SyncTaller
             * 4) Do Infinite
            */
        }
    }
}
